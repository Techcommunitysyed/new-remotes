package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import java.util.List;

public class ForecastAdapter extends RecyclerView.Adapter<ForecastAdapter.ViewHolder> {
    Context context;
    private List<Forecast> data;
    /* access modifiers changed from: private */
    public RecyclerView parentRecycler;

    public ForecastAdapter(Context context2, List<Forecast> list) {
        this.context = context2;
        this.data = list;
    }

    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        this.parentRecycler = recyclerView;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_city_card, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        ContextCompat.getColor(viewHolder.itemView.getContext(), R.color.colorPrimary);
        viewHolder.textView.setText(this.data.get(i).getCityName());
    }

    public int getItemCount() {
        return this.data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        RelativeLayout container;
        /* access modifiers changed from: private */
        public ImageView imageView;
        /* access modifiers changed from: private */
        public TextView textView;

        public ViewHolder(View view) {
            super(view);
            this.imageView = (ImageView) view.findViewById(R.id.city_image);
            this.textView = (TextView) view.findViewById(R.id.city_name);
            this.container = (RelativeLayout) view.findViewById(R.id.container);
            view.findViewById(R.id.container).setOnClickListener(this);
        }

        public void showText() {
            float height = ((float) (((View) this.imageView.getParent()).getHeight() - this.textView.getHeight())) / ((float) this.imageView.getHeight());
            ImageView imageView2 = this.imageView;
            imageView2.setPivotX(((float) imageView2.getWidth()) * 0.5f);
            this.imageView.setPivotY(0.0f);
            this.imageView.animate().scaleX(height).withEndAction(new Runnable() {
                public void run() {
                    ViewHolder.this.textView.setVisibility(View.VISIBLE);
                    ViewHolder.this.imageView.setColorFilter(ViewCompat.MEASURED_STATE_MASK);
                    ViewHolder.this.textView.setTextColor(ForecastAdapter.this.context.getResources().getColor(R.color.colorPrimary));
                }
            }).scaleY(height).setDuration(200).start();
            this.container.setBackground(ForecastAdapter.this.context.getResources().getDrawable(R.drawable.pickerrr));
        }

        public void hideText() {
            ImageView imageView2 = this.imageView;
            imageView2.setColorFilter(ContextCompat.getColor(imageView2.getContext(), R.color.black));
            this.textView.setVisibility(View.VISIBLE);
            this.imageView.animate().scaleX(1.0f).scaleY(1.0f).setDuration(200).start();
            this.container.setBackground((Drawable) null);
            this.textView.setTextColor(ForecastAdapter.this.context.getResources().getColor(R.color.grey));
        }

        public void onClick(View view) {
            ForecastAdapter.this.parentRecycler.smoothScrollToPosition(getAdapterPosition());
        }
    }

    private static class TintOnLoad implements RequestListener<Drawable> {
        private ImageView imageView;
        private int tintColor;

        public boolean onLoadFailed(GlideException glideException, Object obj, Target<Drawable> target, boolean z) {
            return false;
        }

        public TintOnLoad(ImageView imageView2, int i) {
            this.imageView = imageView2;
            this.tintColor = i;
        }

        public boolean onResourceReady(Drawable drawable, Object obj, Target<Drawable> target, DataSource dataSource, boolean z) {
            this.imageView.setColorFilter(this.tintColor);
            return false;
        }
    }
}
