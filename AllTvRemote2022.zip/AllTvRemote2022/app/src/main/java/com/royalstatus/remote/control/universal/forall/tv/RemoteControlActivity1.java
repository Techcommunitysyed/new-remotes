package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class RemoteControlActivity1 extends AppCompatActivity implements View.OnClickListener {
    private Button btnLetsStart;
    private TextView textAppName;
    private TextView textTVBrand;
    private String tvName;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_remote_control1);
        this.tvName = getIntent().hasExtra("tvName") ? getIntent().getStringExtra("tvName") : "";
        initViews();
    }

    private void initViews() {
        findViewById(R.id.imgBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                RemoteControlActivity1.this.onBackPressed();
            }
        });
        TextView textView = (TextView) findViewById(R.id.textTVBrand);
        this.textTVBrand = textView;
        textView.setText("We found 4 remotes for your " + this.tvName + " Device needs some time to respond wait a moment after the action. \nPoint the remote at tv and tap the button. \nMake sure tv responds. \n Let's test one by one.");
        TextView textView2 = (TextView) findViewById(R.id.textAppName);
        this.textAppName = textView2;
        textView2.setText(this.tvName);
        Button button = (Button) findViewById(R.id.btnLetsStart);
        this.btnLetsStart = button;
        button.setOnClickListener(this);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.btnLetsStart) {
            initDialog();
        }
    }

    private void initDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.alert_dialog1);
        ((Button) dialog.findViewById(R.id.btnYes)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void onBackPressed() {
        RemoteControlActivity1.this.finish();
    }
}
