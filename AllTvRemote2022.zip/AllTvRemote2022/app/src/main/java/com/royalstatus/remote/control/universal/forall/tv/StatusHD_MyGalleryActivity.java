package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
//import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.databinding.ActivityGalleryBinding;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.newnativeads.NativeHelper;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_downloader.Status_FBDownloadedFragment;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_downloader.Status_InstaDownloadedFragment;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_downloader.status_util.Utils;
import com.royalstatus.remote.control.universal.forall.tv.databinding.ActivityGalleryBinding;

import java.util.ArrayList;
import java.util.List;

public class StatusHD_MyGalleryActivity extends AppCompatActivity {
    StatusHD_MyGalleryActivity activity;
    ActivityGalleryBinding binding;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
//        this.binding = (ActivityGalleryBinding) DataBindingUtil.setContentView(this, R.layout.activity_gallery);
        this.activity = this;
        initViews();
    }

    public void initViews() {
        setupViewPager(this.binding.viewpager);
        this.binding.tabs.setupWithViewPager(this.binding.viewpager);
        this.binding.imBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                StatusHD_MyGalleryActivity.this.onBackPressed();
            }
        });
        for (int i = 0; i < this.binding.tabs.getTabCount(); i++) {
            this.binding.tabs.getTabAt(i).setCustomView((View) (TextView) LayoutInflater.from(this.activity).inflate(R.layout.statushd_video_mediaplayer_allformat_custom_tab, (ViewGroup) null));
        }
        this.binding.viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            public void onPageScrollStateChanged(int i) {
            }

            public void onPageScrolled(int i, float f, int i2) {
            }

            public void onPageSelected(int i) {
            }
        });
        Utils.createFileFolder();
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(this.activity.getSupportFragmentManager(), 1);
//        viewPagerAdapter.addFragment(new Status_FBDownloadedFragment(), "Facebook");
//        viewPagerAdapter.addFragment(new Status_InstaDownloadedFragment(), "Instagram");
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.setOffscreenPageLimit(4);
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();

        ViewPagerAdapter(FragmentManager fragmentManager, int i) {
            super(fragmentManager, i);
        }

        public Fragment getItem(int i) {
            return this.mFragmentList.get(i);
        }

        public int getCount() {
            return this.mFragmentList.size();
        }

        /* access modifiers changed from: package-private */
        public void addFragment(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        public CharSequence getPageTitle(int i) {
            return this.mFragmentTitleList.get(i);
        }
    }

    public void onBackPressed() {
        StatusHD_MyGalleryActivity.this.finish();
    }
}
