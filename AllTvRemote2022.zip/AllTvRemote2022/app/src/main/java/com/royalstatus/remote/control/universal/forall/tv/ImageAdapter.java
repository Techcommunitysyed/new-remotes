package com.royalstatus.remote.control.universal.forall.tv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.MyViewHolder> {
    private ArrayList<String> imageArrayList;
    private Activity mActivity;
    /* access modifiers changed from: private */
    public ImageClickListener mImageClickListener;

    interface ImageClickListener {
        void onImageClick(int i);
    }

    public ImageAdapter(ArrayList<String> arrayList, Activity activity, ImageClickListener imageClickListener) {
        this.imageArrayList = arrayList;
        this.mActivity = activity;
        this.mImageClickListener = imageClickListener;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_image, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, @SuppressLint("RecyclerView") final int i) {
        Glide.with(this.mActivity).load(this.imageArrayList.get(i)).into(myViewHolder.imgItem);
        myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ImageAdapter.this.mImageClickListener.onImageClick(i);
            }
        });
    }

    public int getItemCount() {
        return this.imageArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        /* access modifiers changed from: private */
        public ImageView imgItem;

        public MyViewHolder(View view) {
            super(view);
            this.imgItem = (ImageView) view.findViewById(R.id.imgItem);
        }
    }
}
