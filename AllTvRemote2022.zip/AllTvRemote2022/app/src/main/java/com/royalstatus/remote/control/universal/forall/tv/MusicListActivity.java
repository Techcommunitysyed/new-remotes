package com.royalstatus.remote.control.universal.forall.tv;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.royalstatus.remote.control.universal.forall.tv.MusicAdapter;
import java.io.IOException;
import java.util.ArrayList;


public class MusicListActivity extends AppCompatActivity {
    private MusicAdapter mMusicAdapter;
    /* access modifiers changed from: private */
    public MediaPlayer mediaPlayer;
    private ArrayList<Song> musicArrayList = new ArrayList<>();
    private RecyclerView tvListView;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_music_list);
        initViews();
    }

    private void initViews() {
        this.mediaPlayer = new MediaPlayer();
        findViewById(R.id.imgBack).setOnClickListener(new MusicListActivity$$ExternalSyntheticLambda0(this));
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.tvListView);
        this.tvListView = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this, 1, false));
        this.tvListView.setItemAnimator(new DefaultItemAnimator());
        this.tvListView.setHasFixedSize(true);
        this.musicArrayList.clear();
        this.musicArrayList.addAll(Constant.getAllSongs(this));
        MusicAdapter musicAdapter = new MusicAdapter(this.musicArrayList, this, new MusicAdapter.MusicClickListener() {
            public void onMusicClick(int i) {
                MusicListActivity.this.initBottomSheetDialog(i);
            }
        });
        this.mMusicAdapter = musicAdapter;
        this.tvListView.setAdapter(musicAdapter);
        this.mMusicAdapter.notifyDataSetChanged();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$initViews$0$com-royalstatus-remote-control-universal-forall-tv-MusicListActivity  reason: not valid java name */
    public /* synthetic */ void m24lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvMusicListActivity(View view) {
        onBackPressed();
    }

    /* access modifiers changed from: private */
    public void initBottomSheetDialog(int i) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.CustomBottomSheetDialog);
        bottomSheetDialog.requestWindowFeature(1);
        bottomSheetDialog.setContentView((int) R.layout.bottomsheet_dialog);
        ((TextView) bottomSheetDialog.findViewById(R.id.textPath)).setText(this.musicArrayList.get(i).title);
        try {
            this.mediaPlayer.reset();
            this.mediaPlayer.setDataSource(this.musicArrayList.get(i).data);
            this.mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        final Button button = (Button) bottomSheetDialog.findViewById(R.id.btnPlay);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (MusicListActivity.this.mediaPlayer.isPlaying()) {
                    if (MusicListActivity.this.mediaPlayer != null) {
                        MusicListActivity.this.mediaPlayer.pause();
                        button.setText("PLAY");
                    }
                } else if (MusicListActivity.this.mediaPlayer != null) {
                    button.setText("PAUSE");
                    MusicListActivity.this.mediaPlayer.start();
                }
            }
        });
        bottomSheetDialog.show();
    }

    public void onBackPressed() {
        finish();
    }
}
