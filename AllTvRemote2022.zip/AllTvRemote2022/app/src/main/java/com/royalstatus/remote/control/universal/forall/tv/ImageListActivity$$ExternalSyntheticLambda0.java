package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;


public final  class ImageListActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final  ImageListActivity f$0;

    public  ImageListActivity$$ExternalSyntheticLambda0(ImageListActivity imageListActivity) {
        this.f$0 = imageListActivity;
    }

    public final void onClick(View view) {
        this.f$0.m23lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvImageListActivity(view);
    }
}
