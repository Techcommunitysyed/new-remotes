package com.royalstatus.remote.control.universal.forall.tv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.RelativeLayout;
import android.widget.SectionIndexer;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterRemoteName extends RecyclerView.Adapter<AdapterRemoteName.Holder> implements Filterable, SectionIndexer, Comparable {
    Activity activity;
    ArrayList<String> alldevice = new ArrayList<>();
    ArrayList<String> alldevicecopy;

    /* renamed from: cn  reason: collision with root package name */
    Context f6cn;
    ArrayList<Integer> mSectionPositions;
    Interface_MyItem onMyCommonItem;

    public int compareTo(Object obj) {
        return 0;
    }

    public int getSectionForPosition(int i) {
        return 0;
    }

    public Object[] getSections() {
        ArrayList arrayList = new ArrayList();
        this.mSectionPositions = new ArrayList<>();
        int size = this.alldevicecopy.size();
        for (int i = 0; i < size; i++) {
            String upperCase = String.valueOf(this.alldevicecopy.get(i).charAt(0)).toUpperCase();
            if (!arrayList.contains(upperCase)) {
                arrayList.add(upperCase);
                this.mSectionPositions.add(Integer.valueOf(i));
            }
        }
        return arrayList.toArray(new String[0]);
    }

    public int getPositionForSection(int i) {
        return this.mSectionPositions.get(i).intValue();
    }

    public class Holder extends RecyclerView.ViewHolder {
        RelativeLayout laymain;
        TextView setname;

        public Holder(View view) {
            super(view);
            this.laymain = (RelativeLayout) view.findViewById(R.id.view);
            this.setname = (TextView) view.findViewById(R.id.txtdata);
        }
    }

    public AdapterRemoteName(Context context, Activity activity2, ArrayList<String> arrayList, Interface_MyItem interface_MyItem) {
        ArrayList<String> arrayList2 = new ArrayList<>();
        this.alldevicecopy = arrayList2;
        this.f6cn = context;
        this.alldevice = arrayList;
        this.activity = activity2;
        arrayList2.addAll(arrayList);
        this.onMyCommonItem = interface_MyItem;
    }

    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(this.f6cn).inflate(R.layout.item_remote, viewGroup, false));
    }

    public void onBindViewHolder(Holder holder, @SuppressLint("RecyclerView") final int i) {
        holder.setname.setText(this.alldevicecopy.get(i));
        holder.laymain.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AdapterRemoteName.this.onMyCommonItem.OnMyClick1(i, AdapterRemoteName.this.alldevicecopy.get(i));

            }
        });
    }

    public int getItemCount() {
        return this.alldevicecopy.size();
    }

    public Filter getFilter() {
        return new Filter() {
            public FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                String lowerCase = charSequence.toString().toLowerCase();
                if (lowerCase.length() > 0) {
                    ArrayList arrayList = new ArrayList();
                    for (int i = 0; i < AdapterRemoteName.this.alldevice.size(); i++) {
                        String str = AdapterRemoteName.this.alldevice.get(i);
                        if (str.toLowerCase().contains(lowerCase)) {
                            arrayList.add(str);
                        }
                    }
                    filterResults.values = arrayList;
                } else {
                    filterResults.values = AdapterRemoteName.this.alldevice;
                }
                return filterResults;
            }

            public void publishResults(CharSequence charSequence, FilterResults filterResults) {
                AdapterRemoteName.this.alldevicecopy.clear();
                AdapterRemoteName.this.alldevicecopy.addAll((ArrayList) filterResults.values);
                AdapterRemoteName.this.notifyDataSetChanged();
            }
        };
    }
}
