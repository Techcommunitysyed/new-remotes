package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityTestingRemote extends AppCompatActivity {
    String Tv_Name;
    TextView chan;
    LinearLayout chan_bottom_text;
    RelativeLayout img_chan;
    TextView img_false;
    ImageView img_minus_chan;
    ImageView img_minus_power;
    ImageView img_minus_vol;
    ImageView img_plus_chan;
    ImageView img_plus_power;
    ImageView img_plus_vol;
    RelativeLayout img_power;
    TextView img_true;
    TextView img_tv_Video;
    TextView img_value;
    RelativeLayout img_volume;
    LinearLayout linchtxt;
    LinearLayout lintxt;
    TextView power;
    RelativeLayout power_bottom_text;
    RelativeLayout rela_tv_video;
    LinearLayout relative_check;
    TextView txt_counter_chan;
    TextView txt_counter_power;
    TextView txt_counter_vol;
    TextView txt_reset;
    Vibrator vibrator;
    TextView vol;
    LinearLayout vol_bottom_text;
    int which = 0;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_testingremote);
        Tv_Name = getIntent().getStringExtra("Tv_Name");
        Log.e("TAG==>>>@@@", "onCreate: " + Tv_Name);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vol_bottom_text = (LinearLayout) findViewById(R.id.vol_bottom_text);
        lintxt = (LinearLayout) findViewById(R.id.lintxt);
        txt_counter_vol = (TextView) findViewById(R.id.txt_counter_vol);
        img_plus_vol = (ImageView) findViewById(R.id.img_plus_vol);
        img_minus_vol = (ImageView) findViewById(R.id.img_minus_vol);
        txt_reset = (TextView) findViewById(R.id.txt_reset);
        img_chan = (RelativeLayout) findViewById(R.id.img_chan);
        img_volume = (RelativeLayout) findViewById(R.id.img_volume);
        img_power = (RelativeLayout) findViewById(R.id.img_power);
        rela_tv_video = (RelativeLayout) findViewById(R.id.rela_tv_video);
        relative_check = (LinearLayout) findViewById(R.id.relative_check);
        img_true = (TextView) findViewById(R.id.img_true);
        img_value = (TextView) findViewById(R.id.img_value);
        img_false = (TextView) findViewById(R.id.img_false);
        power_bottom_text = (RelativeLayout) findViewById(R.id.power_bottom_text);
        txt_counter_power = (TextView) findViewById(R.id.txt_counter_power);
        img_plus_power = (ImageView) findViewById(R.id.img_plus_power);
        img_minus_power = (ImageView) findViewById(R.id.img_minus_power);
        chan_bottom_text = (LinearLayout) findViewById(R.id.chan_bottom_text);
        linchtxt = (LinearLayout) findViewById(R.id.linchtxt);
        txt_counter_chan = (TextView) findViewById(R.id.txt_counter_chan);
        img_plus_chan = (ImageView) findViewById(R.id.img_plus_chan);
        img_minus_chan = (ImageView) findViewById(R.id.img_minus_chan);
        power = (TextView) findViewById(R.id.power);
        vol = (TextView) findViewById(R.id.vol);
        chan = (TextView) findViewById(R.id.chan);
        img_tv_Video = (TextView) findViewById(R.id.img_tv_Video);
        if (which == 0) {
            img_value.setText("CH+ ?");
        }
        img_true.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int i = which;
                if (i == 0) {
                    img_value.setText("CH+ ?");
                    which++;
                    power.setTextColor(getResources().getColor(R.color.text_color));
                    vol.setTextColor(getResources().getColor(R.color.black));
                    chan.setTextColor(getResources().getColor(R.color.black));
                    img_tv_Video.setTextColor(getResources().getColor(R.color.black));
                } else if (i == 1) {
                    img_value.setText("Vol+ ?");
                    which++;
                    power.setTextColor(getResources().getColor(R.color.text_color));
                    vol.setTextColor(getResources().getColor(R.color.text_color));
                    chan.setTextColor(getResources().getColor(R.color.black));
                    img_tv_Video.setTextColor(getResources().getColor(R.color.black));
                } else if (i == 2) {
                    img_value.setText("PLAY ?");
                    which++;
                    power.setTextColor(getResources().getColor(R.color.text_color));
                    vol.setTextColor(getResources().getColor(R.color.text_color));
                    chan.setTextColor(getResources().getColor(R.color.text_color));
                    img_tv_Video.setTextColor(getResources().getColor(R.color.black));
                } else if (i == 3) {
                    img_value.setText("TV VIDEO ?");
                    which++;
                    power.setTextColor(getResources().getColor(R.color.text_color));
                    vol.setTextColor(getResources().getColor(R.color.text_color));
                    chan.setTextColor(getResources().getColor(R.color.text_color));
                    img_tv_Video.setTextColor(getResources().getColor(R.color.text_color));
                } else if (i == 4) {
                    img_value.setText("GO?");
                    which++;
                    power.setTextColor(getResources().getColor(R.color.text_color));
                    vol.setTextColor(getResources().getColor(R.color.text_color));
                    chan.setTextColor(getResources().getColor(R.color.text_color));
                    img_tv_Video.setTextColor(getResources().getColor(R.color.text_color));
                } else if (i == 5) {
                    img_value.setText("GO?");
                    which = 0;
                    power.setTextColor(getResources().getColor(R.color.text_color));
                    vol.setTextColor(getResources().getColor(R.color.text_color));
                    chan.setTextColor(getResources().getColor(R.color.text_color));
                    img_tv_Video.setTextColor(getResources().getColor(R.color.text_color));
                    startActivity(new Intent(ActivityTestingRemote.this, ActivitySaveRemote.class).putExtra("Tv_Name", Tv_Name));
                    finish();
                }
            }
        });
        txt_reset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                power.setTextColor(getResources().getColor(R.color.text_color));
                vol.setTextColor(getResources().getColor(R.color.black));
                chan.setTextColor(getResources().getColor(R.color.black));
                img_tv_Video.setTextColor(getResources().getColor(R.color.black));
            }
        });
        findViewById(R.id.img_back).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onBackPressed();
            }
        });
        power.setTextColor(getResources().getColor(R.color.text_color));
        vol.setTextColor(getResources().getColor(R.color.black));
        chan.setTextColor(getResources().getColor(R.color.black));
        img_tv_Video.setTextColor(getResources().getColor(R.color.black));
        img_false.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                relative_check.setVisibility(View.VISIBLE);
            }
        });
    }

    public void onBackPressed() {
        finish();

    }
}
