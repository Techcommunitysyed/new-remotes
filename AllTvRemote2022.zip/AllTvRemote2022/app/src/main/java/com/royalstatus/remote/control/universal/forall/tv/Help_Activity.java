package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import com.tbuonomo.viewpagerdotsindicator.WormDotsIndicator;


public class Help_Activity extends AppCompatActivity {
    WormDotsIndicator dot3;
    ImageView ic_back;
    int[] images = {R.drawable.m_1, R.drawable.m_1, R.drawable.m_1, R.drawable.m_1, R.drawable.m_1, R.drawable.m_1};
    ViewPager mViewPager;
    ViewPagerAdapter mViewPagerAdapter;
    String[] subtitle = {"Allow All Permissions", "Allow Display over other Apps", "Turn On/Off Animation", "Select Animation", "Watch Animation Preview", "Device put on charge and show Animation"};

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_help);
        this.mViewPager = (ViewPager) findViewById(R.id.viewPagerMain);
        this.ic_back = (ImageView) findViewById(R.id.ic_back);
        this.dot3 = (WormDotsIndicator) findViewById(R.id.dot3);
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(this, this.images, this.subtitle);
        this.mViewPagerAdapter = viewPagerAdapter;
        this.mViewPager.setAdapter(viewPagerAdapter);
        this.dot3.setViewPager(this.mViewPager);
        this.ic_back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Help_Activity.this.onBackPressed();
            }
        });
    }
}
