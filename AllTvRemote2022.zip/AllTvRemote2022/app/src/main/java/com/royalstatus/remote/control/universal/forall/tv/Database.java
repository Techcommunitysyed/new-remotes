package com.royalstatus.remote.control.universal.forall.tv;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
//import com.two.dgbmapp.hdvideoprojector.OtherClass.Remote;
import java.util.ArrayList;
import java.util.List;

public class Database extends SQLiteOpenHelper {
    private static String CATEGORY = "category";
    private  final String CREATE_TABLE = ("CREATE TABLE " + TABLE_NAME + " (" + TV_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + REMOTE_NAME + " TEXT NOT NULL," + CATEGORY + " TEXT NOT NULL );");
    private static final String DATABASE_NAME = "LiveTv.db";
    private static String REMOTE_NAME = "remote_name";
    private static String TABLE_NAME = "livetv";
    private static String TV_ID = "tv_id";
    private static Context context;
    private final String TAG = "Database_helper";

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public Database(Context context2) {
        super(context2, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        SQLiteDatabase.CursorFactory cursorFactory = null;
        context = context2;
        Log.e("Database_helper", "Database_helper is Created");
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL(CREATE_TABLE);
    }

    public void onOpen(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.disableWriteAheadLogging();
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS livetv");
    }

    public void insert_remote(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(REMOTE_NAME, str);
        contentValues.put(CATEGORY, str2);
        writableDatabase.insert(TABLE_NAME, (String) null, contentValues);
    }

    public List<Remote> Get_Data() {
        ArrayList arrayList = new ArrayList();
        Cursor query = getReadableDatabase().query(TABLE_NAME, new String[]{TV_ID, REMOTE_NAME, CATEGORY}, (String) null, (String[]) null, (String) null, (String) null, (String) null, (String) null);
        while (query.moveToNext()) {
            @SuppressLint("Range") String string = query.getString(query.getColumnIndex(TV_ID));
            @SuppressLint("Range") String string2 = query.getString(query.getColumnIndex(REMOTE_NAME));
            @SuppressLint("Range") String string3 = query.getString(query.getColumnIndex(CATEGORY));
            Remote remote = new Remote();
            remote.setId(string);
            remote.setRemote(string2);
            remote.setCategory(string3);
            arrayList.add(remote);
        }
        return arrayList;
    }

    public Integer Delete(String str) {
        return Integer.valueOf(getWritableDatabase().delete(TABLE_NAME, "tv_id=?", new String[]{str}));
    }

    public boolean Update(String str, String str2) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TV_ID, str);
        contentValues.put(REMOTE_NAME, str2);
        writableDatabase.update(TABLE_NAME, contentValues, "tv_id = ?", new String[]{str});
        return true;
    }
}
