package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.MyViewHolder> {
    private ArrayList<Song> audioModelArrayList;
    private Activity mActivity;
    /* access modifiers changed from: private */
    public MusicClickListener musicClickListener;

    interface MusicClickListener {
        void onMusicClick(int i);
    }

    public MusicAdapter(ArrayList<Song> arrayList, Activity activity, MusicClickListener musicClickListener2) {
        this.audioModelArrayList = arrayList;
        this.mActivity = activity;
        this.musicClickListener = musicClickListener2;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_music, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
        myViewHolder.textName.setText(this.audioModelArrayList.get(i).title);
        myViewHolder.textArtist.setText(this.audioModelArrayList.get(i).artistName);
        myViewHolder.textDuration.setText(Constant.formateMilliSeccond(this.audioModelArrayList.get(i).duration));
        myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MusicAdapter.this.musicClickListener.onMusicClick(i);
            }
        });
    }

    public int getItemCount() {
        return this.audioModelArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        /* access modifiers changed from: private */
        public TextView textArtist;
        /* access modifiers changed from: private */
        public TextView textDuration;
        /* access modifiers changed from: private */
        public TextView textName;

        public MyViewHolder(View view) {
            super(view);
            this.textName = (TextView) view.findViewById(R.id.textName);
            this.textArtist = (TextView) view.findViewById(R.id.textArtist);
            this.textDuration = (TextView) view.findViewById(R.id.textDuration);
        }
    }
}
