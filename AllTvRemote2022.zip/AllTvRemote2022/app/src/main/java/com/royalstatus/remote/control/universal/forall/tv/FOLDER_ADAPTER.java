package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Activity.VIDEO_LIST_ACTIVITY;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.FOLDER_MODEL;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import java.util.List;

public class FOLDER_ADAPTER extends RecyclerView.Adapter<FOLDER_ADAPTER.MyFolder> {
    Activity activity;
    Context context;
    List<FOLDER_MODEL> modelList;

    public FOLDER_ADAPTER(Context context2, List<FOLDER_MODEL> list, Activity activity2) {
        this.context = context2;
        this.modelList = list;
        this.activity = activity2;
    }

    public MyFolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyFolder(LayoutInflater.from(this.context).inflate(R.layout.item_folder_list, viewGroup, false));
    }

    public void onBindViewHolder(MyFolder myFolder, int i) {
        final FOLDER_MODEL folder_model = this.modelList.get(i);
        myFolder.tvName.setText(folder_model.getBucket());
        if (folder_model.getVideoCount().equals("1")) {
            TextView textView = myFolder.tvCount;
            textView.setText(folder_model.getVideoCount() + " Video");
        } else {
            TextView textView2 = myFolder.tvCount;
            textView2.setText(folder_model.getVideoCount() + " Videos");
        }
        myFolder.tvSize.setText(folder_model.getDate());
        myFolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                FOLDER_ADAPTER.this.context.startActivity(new Intent(FOLDER_ADAPTER.this.context, VIDEO_LIST_ACTIVITY.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("Bucket", folder_model.getBid()).putExtra("name", folder_model.getBucket()));

            }
        });
    }

    public int getItemCount() {
        return this.modelList.size();
    }

    public class MyFolder extends RecyclerView.ViewHolder {
        TextView tvCount;
        TextView tvName;
        TextView tvSize;

        public MyFolder(View view) {
            super(view);
            this.tvName = (TextView) view.findViewById(R.id.tvName);
            this.tvCount = (TextView) view.findViewById(R.id.tvCount);
            this.tvSize = (TextView) view.findViewById(R.id.tvSize);
        }
    }
}
