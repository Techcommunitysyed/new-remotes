package com.royalstatus.remote.control.universal.forall.tv;

import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

class MyWebViewClient extends WebViewClient {
    MyWebViewClient() {
    }

    public boolean shouldOverrideUrlLoading(WebView webView, String str) {
        webView.loadUrl(str);
        CookieManager.getInstance().setAcceptCookie(true);
        return true;
    }
}
