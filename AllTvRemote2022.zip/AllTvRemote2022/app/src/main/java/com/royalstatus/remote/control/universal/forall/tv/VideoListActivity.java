package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.royalstatus.remote.control.universal.forall.tv.VideoAdapter;
import java.util.ArrayList;


public class VideoListActivity extends AppCompatActivity {
    private VideoAdapter mVideoAdapter;
    private RecyclerView tvListView;
    /* access modifiers changed from: private */
    public ArrayList<String> videosArrayList = new ArrayList<>();

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_video_list);
        initViews();
    }

    private void initViews() {
        findViewById(R.id.imgBack).setOnClickListener(new VideoListActivity$$ExternalSyntheticLambda0(this));
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.tvListView);
        this.tvListView = recyclerView;
        recyclerView.setLayoutManager(new GridLayoutManager((Context) this, 2, 1, false));
        this.tvListView.setItemAnimator(new DefaultItemAnimator());
        this.tvListView.setHasFixedSize(true);
        this.videosArrayList.clear();
        this.videosArrayList.addAll(Constant.getAllShownVideoPath(this));
        VideoAdapter videoAdapter = new VideoAdapter(this.videosArrayList, this, new VideoAdapter.VideoClickListener() {
            public void onVideoClick(int i) {
                VideoListActivity.this.startActivity(new Intent(VideoListActivity.this, PreviewActivity.class).putExtra("video", (String) VideoListActivity.this.videosArrayList.get(i)));
            }
        });
        this.mVideoAdapter = videoAdapter;
        this.tvListView.setAdapter(videoAdapter);
        this.mVideoAdapter.notifyDataSetChanged();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$initViews$0$com-royalstatus-remote-control-universal-forall-tv-VideoListActivity  reason: not valid java name */
    public /* synthetic */ void m27lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvVideoListActivity(View view) {
        onBackPressed();
    }

    public void onBackPressed() {
     finish();
    }
}
