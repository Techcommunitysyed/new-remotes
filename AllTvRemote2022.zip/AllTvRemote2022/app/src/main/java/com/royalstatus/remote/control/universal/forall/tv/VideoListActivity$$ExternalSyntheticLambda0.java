package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;


public final  class VideoListActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final  VideoListActivity f$0;

    public  VideoListActivity$$ExternalSyntheticLambda0(VideoListActivity videoListActivity) {
        this.f$0 = videoListActivity;
    }

    public final void onClick(View view) {
        this.f$0.m27lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvVideoListActivity(view);
    }
}
