package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.Adapter.HistoryCustomListAdapterDeleteRows;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.Model.HistoryMo;
import java.util.ArrayList;
import org.json.JSONException;

public class HistoryActivity extends AppCompatActivity {
    static HistoryCustomListAdapterDeleteRows deleteAdapter;
    LinearLayout datahis;
    ListView listView;
    ImageView sss;
    ArrayList<HistoryMo> users = new ArrayList<>();
    LinearLayout xtxt;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_history);
        ((ImageView) findViewById(R.id.clocc)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                HistoryActivity.this.finish();
            }
        });
        this.listView = (ListView) findViewById(R.id.listviewdeleteID);
        this.sss = (ImageView) findViewById(R.id.sss);
        this.xtxt = (LinearLayout) findViewById(R.id.xtxt);
        this.datahis = (LinearLayout) findViewById(R.id.datahis);
        datafatch();
        ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.setDisplayHomeAsUpEnabled(true);
            supportActionBar.setTitle((CharSequence) "History");
        }
        this.sss.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                UsersDatabaseAdapter.truncatehisTable();
                HistoryActivity.this.datafatch();
            }
        });
    }

    public void onResume() {
        datafatch();
        super.onResume();
    }

    /* access modifiers changed from: private */
    public void datafatch() {
        try {
            new UsersDatabaseAdapter(this);
            this.users = UsersDatabaseAdapter.getHisRows();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (this.users.isEmpty()) {
            this.xtxt.setVisibility(View.VISIBLE);
            this.datahis.setVisibility(View.GONE);
            return;
        }
        this.xtxt.setVisibility(View.GONE);
        this.datahis.setVisibility(View.VISIBLE);
        HistoryCustomListAdapterDeleteRows historyCustomListAdapterDeleteRows = new HistoryCustomListAdapterDeleteRows(this, this.users);
        deleteAdapter = historyCustomListAdapterDeleteRows;
        this.listView.setAdapter(historyCustomListAdapterDeleteRows);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finish();
        return true;
    }
}
