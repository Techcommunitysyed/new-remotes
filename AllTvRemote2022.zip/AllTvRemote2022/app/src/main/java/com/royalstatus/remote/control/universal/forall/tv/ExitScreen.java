package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class ExitScreen extends AppCompatActivity {
    ImageView txt_no;
    ImageView txt_rate;
    ImageView txt_yes;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.exit_screen);
        this.txt_rate = (ImageView) findViewById(R.id.txt_rate);
        this.txt_yes = (ImageView) findViewById(R.id.txt_yes);
        this.txt_no = (ImageView) findViewById(R.id.txt_no);
//        this.txt_rate.setOnClickListener(new ExitScreen$$ExternalSyntheticLambda0(this));
//        this.txt_yes.setOnClickListener(new ExitScreen$$ExternalSyntheticLambda1(this));
//        this.txt_no.setOnClickListener(new ExitScreen$$ExternalSyntheticLambda2(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$0$vocsy-google-ads-ExitScreen  reason: not valid java name */
    public /* synthetic */ void m1548lambda$onCreate$0$vocsygoogleadsExitScreen(View view) {

    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$1$vocsy-google-ads-ExitScreen  reason: not valid java name */
    public /* synthetic */ void m1549lambda$onCreate$1$vocsygoogleadsExitScreen(View view) {
        yes();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$2$vocsy-google-ads-ExitScreen  reason: not valid java name */
    public /* synthetic */ void m1550lambda$onCreate$2$vocsygoogleadsExitScreen(View view) {
        no();
    }


    private void yes() {
        finishAffinity();
        finishAndRemoveTask();
        System.exit(0);
    }

    private void no() {
        finish();
    }
}
