package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


public class SplashActivity extends AppCompatActivity {

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_splash);

        SplashActivity.this.startActivity(new Intent(SplashActivity.this, StartActivity.class));

    }
}
