package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.navigation.NavigationView;
//import com.two.dgbmapp.hdvideoprojector.Ads_class.Common;
//import com.two.dgbmapp.hdvideoprojector.Basic.More_Activity;
//import com.two.dgbmapp.hdvideoprojector.Basic.Start_Activity;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Adapter.IMAGE_FOLDER_ADAPTER;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.MODEL_GALLERY_ALBUM_MODEL;
//import com.two.dgbmapp.hdvideoprojector.part2.Utils.GetMedia;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.newnativeads.NativeHelper;
import java.util.List;

public class IMG_FOLDER_FRAGMENT extends AppCompatActivity {
    ImageView back;
    DrawerLayout drawer_layout;
    RelativeLayout gift;
    LinearLayout llImpty;
    GetMedia mGetMedia;
    NavigationView nav_view;
    SwipeRefreshLayout refershLayout;
    RecyclerView rvFolderList;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.fragment_all_folder);
        getIds();
        ImageView imageView = (ImageView) findViewById(R.id.back);
        this.back = imageView;
        imageView.setOnClickListener(new IMG_FOLDER_FRAGMENT$$ExternalSyntheticLambda0(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$0$com-two-dgbmapp-hdvideoprojector-part2-IMG_FOLDER_FRAGMENT  reason: not valid java name */
    public /* synthetic */ void m33lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart2IMG_FOLDER_FRAGMENT(View view) {
        onBackPressed();
    }

    public void getIds() {
        this.rvFolderList = (RecyclerView) findViewById(R.id.rvFolderList);
        this.refershLayout = (SwipeRefreshLayout) findViewById(R.id.refershLayout);
        this.llImpty = (LinearLayout) findViewById(R.id.llImpty);
        this.mGetMedia = new GetMedia(this);
        new loadVideos().execute(new String[0]);
        this.refershLayout.setRefreshing(true);
        this.refershLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            public void onRefresh() {
                new loadVideos().execute(new String[0]);
            }
        });
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
        this.gift = (RelativeLayout) findViewById(R.id.gift);
    }

    public void lambda$adsandnavigation$0$IMG_FOLDER_FRAGMENT(View view) {
        this.drawer_layout.openDrawer((int) GravityCompat.START);
    }

    public boolean lambda$adsandnavigation$1$IMG_FOLDER_FRAGMENT(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.home) {
            this.drawer_layout.closeDrawer((int) GravityCompat.START);
            Intent intent = new Intent(getApplicationContext(), Start_Activity.class);
            intent.putExtra("my_boolean_key", true);
            startActivity(intent);
            finish();
        } else if (itemId == R.id.rate) {
            Common.rateUs(this);
        } else if (itemId == R.id.share) {
            Common.ShareApp(this);
        } else if (itemId == R.id.privacy) {
            Common.privacypolicy(this);
        } else if (itemId == R.id.more) {
            startActivity(new Intent(this, More_Activity.class));
        }
        this.drawer_layout.closeDrawer((int) GravityCompat.START);
        return true;
    }

    public void onBackPressed() {
       finish();
    }

    public void onResume() {
        super.onResume();
    }

    public class loadVideos extends AsyncTask<String, String, List<MODEL_GALLERY_ALBUM_MODEL>> {
        loadVideos() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            IMG_FOLDER_FRAGMENT.this.llImpty.setVisibility(View.GONE);
        }

        public List<MODEL_GALLERY_ALBUM_MODEL> doInBackground(String... strArr) {
            return IMG_FOLDER_FRAGMENT.this.mGetMedia.getImageFolder(IMG_FOLDER_FRAGMENT.this);
        }

        public void onPostExecute(List<MODEL_GALLERY_ALBUM_MODEL> list) {
            super.onPostExecute(list);
            if (list.size() != 0) {
                IMG_FOLDER_FRAGMENT.this.rvFolderList.setLayoutManager(new GridLayoutManager(IMG_FOLDER_FRAGMENT.this, 1));
                IMG_FOLDER_FRAGMENT.this.rvFolderList.setAdapter(new IMAGE_FOLDER_ADAPTER(IMG_FOLDER_FRAGMENT.this, list));
            } else {
                IMG_FOLDER_FRAGMENT.this.llImpty.setVisibility(View.VISIBLE);
            }
            IMG_FOLDER_FRAGMENT.this.refershLayout.setRefreshing(false);
        }
    }
}
