package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.royalstatus.remote.control.universal.forall.tv.DevicesAdapter;
import java.util.ArrayList;
import java.util.Iterator;


public class SetUPBoxActivity extends AppCompatActivity implements TextWatcher {
    private EditText edtSearch;
    /* access modifiers changed from: private */
    public ArrayList<String> mDeviceArrayList = new ArrayList<>();
    private DevicesAdapter mDevicesAdapter;
    private RecyclerView tvListView;

    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_set_upbox);
        initViews();
    }

    private void initViews() {
        findViewById(R.id.imgBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SetUPBoxActivity.this.onBackPressed();
            }
        });
        EditText editText = (EditText) findViewById(R.id.edtSearch);
        this.edtSearch = editText;
        editText.addTextChangedListener(this);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.tvListView);
        this.tvListView = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this, 1, false));
        this.tvListView.setItemAnimator(new DefaultItemAnimator());
        this.tvListView.setHasFixedSize(true);
        this.mDeviceArrayList.clear();
        this.mDeviceArrayList.addAll(Constant.TVBrandsList3());
        DevicesAdapter devicesAdapter = new DevicesAdapter(this.mDeviceArrayList, this, new DevicesAdapter.onDeviceClickListener() {
            public void onDeviceClick(int i) {
                SetUPBoxActivity.this.startActivity(new Intent(SetUPBoxActivity.this, RemoteControlActivity1.class).putExtra("tvName", (String) SetUPBoxActivity.this.mDeviceArrayList.get(i)));
            }
        });
        this.mDevicesAdapter = devicesAdapter;
        this.tvListView.setAdapter(devicesAdapter);
        this.mDevicesAdapter.notifyDataSetChanged();
    }

    private void filter(String str) {
        ArrayList arrayList = new ArrayList();
        Iterator<String> it = this.mDeviceArrayList.iterator();
        while (it.hasNext()) {
            String next = it.next();
            if (next.toLowerCase().contains(str.toLowerCase())) {
                arrayList.add(next);
            }
        }
        this.mDevicesAdapter.filterList(arrayList);
    }

    public void afterTextChanged(Editable editable) {
        filter(editable.toString());
    }

    public void onBackPressed() {
        SetUPBoxActivity.this.finish();
    }
}
