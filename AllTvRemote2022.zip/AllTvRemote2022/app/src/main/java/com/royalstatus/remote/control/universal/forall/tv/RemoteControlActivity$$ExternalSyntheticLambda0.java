package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;


public final  class RemoteControlActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final  RemoteControlActivity f$0;

    public  RemoteControlActivity$$ExternalSyntheticLambda0(RemoteControlActivity remoteControlActivity) {
        this.f$0 = remoteControlActivity;
    }

    public  void onClick(View view) {
        this.f$0.m26lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvRemoteControlActivity(view);
    }
}
