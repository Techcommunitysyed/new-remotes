package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
//import com.two.dgbmapp.hdvideoprojector.Ads_class.Common;
//import com.two.dgbmapp.hdvideoprojector.Basic.More_Activity;
//import com.two.dgbmapp.hdvideoprojector.Basic.Start_Activity;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.bookwebbrowserfrag;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class webbrowserfrag extends AppCompatActivity {
    ImageButton back;
    ImageView backs;
    ImageView drawer;
    DrawerLayout drawer_layout;
    EditText editText;
    ImageView fb;
    ImageButton forward;
    RelativeLayout gift;
    ImageView google;
    ImageButton homeButton;
    ImageView imgcast;
    ImageView imgclosed;
    ImageView imgmore;
    ImageView insta;
    LinearLayout ll_all_layout;
    LinearLayout ll_buttons;
    NavigationView nav_view;
    ImageView playstore;
    ProgressBar progressBar;
    ImageButton refresh;
    ImageButton stop;
    LinearLayout toolbar2;
    RelativeLayout toolbar3;
    TextView txtlink;
    WebView webView;
    ImageView youtube;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.browserfra);
        adsandnavigation();
        this.editText = (EditText) findViewById(R.id.web_address_edit_text);
        this.back = (ImageButton) findViewById(R.id.back_arrow);
        this.forward = (ImageButton) findViewById(R.id.forward_arrow);
        this.stop = (ImageButton) findViewById(R.id.stop);
        this.imgclosed = (ImageView) findViewById(R.id.imgclosed);
        this.backs = (ImageView) findViewById(R.id.back);
        this.imgmore = (ImageView) findViewById(R.id.imgmore);
        this.imgcast = (ImageView) findViewById(R.id.imgcast);
        this.google = (ImageView) findViewById(R.id.google);
        this.youtube = (ImageView) findViewById(R.id.youtube);
        this.fb = (ImageView) findViewById(R.id.fb);
        this.playstore = (ImageView) findViewById(R.id.playstore);
        this.insta = (ImageView) findViewById(R.id.insta);
        this.imgcast.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    webbrowserfrag.this.startActivity(new Intent("android.settings.CAST_SETTINGS"));
                } catch (Exception unused) {
                    Toast.makeText(webbrowserfrag.this.getApplicationContext(), "Device not supported", Toast.LENGTH_LONG).show();
                }
            }
        });
        this.refresh = (ImageButton) findViewById(R.id.refresh);
        this.toolbar2 = (LinearLayout) findViewById(R.id.toolbar2);
        this.ll_buttons = (LinearLayout) findViewById(R.id.ll_buttons);
        this.ll_all_layout = (LinearLayout) findViewById(R.id.ll_all_layout);
        this.ll_buttons.setVisibility(View.VISIBLE);
        this.ll_all_layout.setVisibility(View.GONE);
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.toolbar3);
        this.toolbar3 = relativeLayout;
        relativeLayout.setVisibility(View.GONE);
        this.toolbar2.setVisibility(View.VISIBLE);
        this.homeButton = (ImageButton) findViewById(R.id.home);
        this.txtlink = (TextView) findViewById(R.id.txtlink);
        Glide.with((FragmentActivity) this).asGif().load(Integer.valueOf(R.drawable.cast)).into(this.imgcast);
        this.backs.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.toolbar3.setVisibility(View.VISIBLE);
                webbrowserfrag.this.toolbar2.setVisibility(View.GONE);
            }
        });
        this.imgmore.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag webbrowserfrag = webbrowserfrag.this;
                PopupMenu popupMenu = new PopupMenu(webbrowserfrag, webbrowserfrag.imgmore);
                popupMenu.inflate(R.menu.weboption);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        int itemId = menuItem.getItemId();
                        if (itemId == R.id.menu1) {
                            webbrowserfrag.this.startActivity(new Intent(webbrowserfrag.this, HistoryActivity.class));
                            return false;
                        } else if (itemId == R.id.menu2) {
                            webbrowserfrag.this.startActivity(new Intent(webbrowserfrag.this, Bookmarkactivity.class));
                            return false;
                        } else {
                            if (itemId == R.id.menu3) {
                                UsersDatabaseAdapter.insertEntry(webbrowserfrag.this.txtlink.getText().toString().trim(), "sachin", "sachinnnn");
                            }
                            return false;
                        }
                    }
                });
                popupMenu.show();
            }
        });
        ProgressBar progressBar2 = (ProgressBar) findViewById(R.id.progress_bar);
        this.progressBar = progressBar2;
        progressBar2.setMax(100);
        this.progressBar.setVisibility(View.VISIBLE);
        this.imgclosed.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(webbrowserfrag.this, R.style.traparentdialog);
                ViewGroup viewGroup = null;
                View inflate = LayoutInflater.from(webbrowserfrag.this).inflate(R.layout.exitdialog, (ViewGroup) null);
                builder.setView(inflate);
                final AlertDialog create = builder.create();
                create.show();
                ((TextView) inflate.findViewById(R.id.yes)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        webbrowserfrag.this.finish();
                    }
                });
                ((TextView) inflate.findViewById(R.id.no)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        create.dismiss();
                    }
                });
            }
        });
        this.editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i == 2) {
                    webbrowserfrag.this.ll_buttons.setVisibility(View.GONE);
                    webbrowserfrag.this.ll_all_layout.setVisibility(View.VISIBLE);
                    try {
                        if (!NetworkState.connectionAvailable(webbrowserfrag.this)) {
                            Toast.makeText(webbrowserfrag.this, "check connection", Toast.LENGTH_SHORT).show();
                        } else {
                            ((InputMethodManager) webbrowserfrag.this.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(webbrowserfrag.this.editText.getWindowToken(), 0);
                            webbrowserfrag.this.webView.setWebViewClient(new bookwebbrowserfrag.CustomWebClient());
                            webbrowserfrag webbrowserfrag = webbrowserfrag.this;
                            webbrowserfrag.search(webbrowserfrag.editText.getText().toString());
                            webbrowserfrag.this.toolbar3.setVisibility(View.VISIBLE);
                            webbrowserfrag.this.toolbar2.setVisibility(View.GONE);
                            webbrowserfrag.this.txtlink.setText(webbrowserfrag.this.editText.getText().toString());
                            PrintStream printStream = System.out;
                            printStream.println(">>>>>>>>>> originalUrl " + webbrowserfrag.this.webView.getOriginalUrl());
                            PrintStream printStream2 = System.out;
                            printStream2.println(">>>>>>>>>> getUrl " + webbrowserfrag.this.webView.getUrl());
                            UsersDatabaseAdapter.inserthistoryEntry(webbrowserfrag.this.editText.getText().toString().trim(), "Patel", "Patidar");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return false;
            }
        });
        WebView webView2 = (WebView) findViewById(R.id.web_view);
        this.webView = webView2;
        if (bundle != null) {
            webView2.restoreState(bundle);
        } else {
            webView2.getSettings().setJavaScriptEnabled(true);
            this.webView.getSettings().setUseWideViewPort(true);
            this.webView.getSettings().setLoadWithOverviewMode(true);
            this.webView.getSettings().setSupportZoom(true);
            this.webView.getSettings().setSupportMultipleWindows(true);
            this.webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
            this.webView.setBackgroundColor(-1);
            this.webView.setWebChromeClient(new WebChromeClient() {
                public void onProgressChanged(WebView webView, int i) {
                    super.onProgressChanged(webView, i);
                    webbrowserfrag.this.progressBar.setProgress(i);
                    if (i < 100 && webbrowserfrag.this.progressBar.getVisibility() == View.GONE) {
                        webbrowserfrag.this.progressBar.setVisibility(View.VISIBLE);
                    }
                    if (i == 100) {
                        webbrowserfrag.this.progressBar.setVisibility(View.GONE);
                    } else {
                        webbrowserfrag.this.progressBar.setVisibility(View.VISIBLE);
                    }
                }
            });
        }
        this.txtlink.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.toolbar2.setVisibility(View.VISIBLE);
                webbrowserfrag.this.toolbar3.setVisibility(View.GONE);
            }
        });
        this.webView.setWebViewClient(new MyWebViewClient());
        this.back.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                webbrowserfrag.this.lambda$onCreate$0$webbrowserfrag(view);
            }
        });
        this.forward.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                webbrowserfrag.this.lambda$onCreate$1$webbrowserfrag(view);
            }
        });
        this.stop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.webView.stopLoading();
            }
        });
        this.refresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.webView.reload();
            }
        });
        this.homeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.webView.loadUrl("http://google.com");
            }
        });
        this.google.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.ll_buttons.setVisibility(View.GONE);
                webbrowserfrag.this.ll_all_layout.setVisibility(View.VISIBLE);
                webbrowserfrag.this.webView.loadUrl("http://google.com");
            }
        });
        this.youtube.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.ll_buttons.setVisibility(View.GONE);
                webbrowserfrag.this.ll_all_layout.setVisibility(View.VISIBLE);
                webbrowserfrag.this.webView.loadUrl("http://youtube.com");
            }
        });
        this.fb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.ll_buttons.setVisibility(View.GONE);
                webbrowserfrag.this.ll_all_layout.setVisibility(View.VISIBLE);
                webbrowserfrag.this.webView.loadUrl("http://facebook.com");
            }
        });
        this.playstore.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.ll_buttons.setVisibility(View.GONE);
                webbrowserfrag.this.ll_all_layout.setVisibility(View.VISIBLE);
                webbrowserfrag.this.webView.loadUrl("http://play.google.com/");
            }
        });
        this.insta.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.ll_buttons.setVisibility(View.GONE);
                webbrowserfrag.this.ll_all_layout.setVisibility(View.VISIBLE);
                webbrowserfrag.this.webView.loadUrl("http://instagram.com");
            }
        });
    }

    public void lambda$onCreate$0$webbrowserfrag(View view) {
        if (this.webView.canGoBack()) {
            this.webView.goBack();
        }
    }

    public void lambda$onCreate$1$webbrowserfrag(View view) {
        if (this.webView.canGoForward()) {
            this.webView.goForward();
        }
    }

    public void search(String str) {
        String str2;
        try {
            str2 = URLEncoder.encode(str, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            str2 = null;
        }
        if (str2 != null) {
            WebView webView2 = this.webView;
            webView2.loadUrl("https://www.google.com/search?q=" + str2);
            return;
        }
        Toast.makeText(this, "Please Enter Valid URL!!", Toast.LENGTH_SHORT).show();
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
        this.gift = (RelativeLayout) findViewById(R.id.gift);
        this.drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        this.nav_view = (NavigationView) findViewById(R.id.nav_view);
        ImageView imageView = (ImageView) findViewById(R.id.drawer);
        this.drawer = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                webbrowserfrag.this.drawer_layout.openDrawer((int) GravityCompat.START);
            }
        });
        this.nav_view.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                int itemId = menuItem.getItemId();
                if (itemId == R.id.home) {
                    webbrowserfrag.this.drawer_layout.closeDrawer((int) GravityCompat.START);
                    Intent intent = new Intent(webbrowserfrag.this.getApplicationContext(), Start_Activity.class);
                    intent.putExtra("my_boolean_key", true);
                    webbrowserfrag.this.startActivity(intent);
                    webbrowserfrag.this.finish();
                } else if (itemId == R.id.rate) {
                    Common.rateUs(webbrowserfrag.this);
                } else if (itemId == R.id.share) {
                    Common.ShareApp(webbrowserfrag.this);
                } else if (itemId == R.id.privacy) {
                    Common.privacypolicy(webbrowserfrag.this);
                } else if (itemId == R.id.more) {
                    webbrowserfrag.this.startActivity(new Intent(webbrowserfrag.this, More_Activity.class));
                }
                webbrowserfrag.this.drawer_layout.closeDrawer((int) GravityCompat.START);
                return true;
            }
        });
    }

    public void onBackPressed() {
        if (this.drawer_layout.isDrawerOpen((int) GravityCompat.START)) {
            this.drawer_layout.closeDrawer((int) GravityCompat.START);
        }
        finish();
    }
}
