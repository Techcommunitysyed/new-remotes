package com.royalstatus.remote.control.universal.forall.tv;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.navigation.NavigationView;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Adapter.VIDEO_ADAPTER;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.VIDEO_MODEL;
//import com.two.dgbmapp.hdvideoprojector.part2.Utils.GetMedia;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.newnativeads.NativeHelper;
import java.util.ArrayList;
import java.util.List;

public class VIDEO_LIST_ACTIVITY extends AppCompatActivity {
    VIDEO_ADAPTER adapter;
    ImageView back;
    ImageView drawer;
    RelativeLayout gift;
    GetMedia mGetMedia;
    NavigationView nav_view;
    SwipeRefreshLayout refershLayout;
    RecyclerView rvFolderList;
//    TextView txtNoData;
    List<VIDEO_MODEL> videoModelList;

    private void getIds() {
        this.rvFolderList = (RecyclerView) findViewById(R.id.rvFolderList);
        this.refershLayout = (SwipeRefreshLayout) findViewById(R.id.refershLayout);
//        this.txtNoData = (TextView) findViewById(R.id.txtNoData);
        this.rvFolderList.setLayoutManager(new GridLayoutManager(this, 1));
        this.mGetMedia = new GetMedia(this);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_video_list);
        getIds();
        adsandnavigation();
        new loadVideos().execute(new String[0]);
        this.refershLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            public void onRefresh() {
                new loadVideos().execute(new String[0]);
            }
        });
       ImageView imageView = (ImageView) findViewById(R.id.back);
        this.back = imageView;
        imageView.setOnClickListener(new VIDEO_LIST_ACTIVITY$$ExternalSyntheticLambda0(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$0$com-two-dgbmapp-hdvideoprojector-part2-Activity-VIDEO_LIST_ACTIVITY  reason: not valid java name */
    public /* synthetic */ void m32lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart2ActivityVIDEO_LIST_ACTIVITY(View view) {
        onBackPressed();
    }

    class loadVideos extends AsyncTask<String, String, List<VIDEO_MODEL>> {
        loadVideos() {
        }

        public void onPreExecute() {
            super.onPreExecute();
//            VIDEO_LIST_ACTIVITY.this.txtNoData.setVisibility(View.GONE);
        }

        public List<VIDEO_MODEL> doInBackground(String... strArr) {
            VIDEO_LIST_ACTIVITY.this.videoModelList = new ArrayList();
            if (VIDEO_LIST_ACTIVITY.this.videoModelList != null) {
                VIDEO_LIST_ACTIVITY.this.videoModelList.clear();
            }
            VIDEO_LIST_ACTIVITY video_list_activity = VIDEO_LIST_ACTIVITY.this;
            video_list_activity.videoModelList = video_list_activity.mGetMedia.getVideoByFolder(VIDEO_LIST_ACTIVITY.this.getIntent().getStringExtra("Bucket"));
            return VIDEO_LIST_ACTIVITY.this.videoModelList;
        }

        public void onPostExecute(List<VIDEO_MODEL> list) {
            super.onPostExecute(list);
            if (VIDEO_LIST_ACTIVITY.this.videoModelList.size() != 0) {
                VIDEO_LIST_ACTIVITY.this.rvFolderList.setLayoutManager(new GridLayoutManager(VIDEO_LIST_ACTIVITY.this, 2));
                VIDEO_LIST_ACTIVITY video_list_activity = VIDEO_LIST_ACTIVITY.this;
                video_list_activity.adapter = new VIDEO_ADAPTER(video_list_activity, video_list_activity, video_list_activity.videoModelList);
                VIDEO_LIST_ACTIVITY.this.rvFolderList.setAdapter(VIDEO_LIST_ACTIVITY.this.adapter);
            } else {
//                VIDEO_LIST_ACTIVITY.this.txtNoData.setVisibility(View.VISIBLE);
            }
            VIDEO_LIST_ACTIVITY.this.refershLayout.setRefreshing(false);
        }
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
        this.gift = (RelativeLayout) findViewById(R.id.gift);
        this.nav_view = (NavigationView) findViewById(R.id.nav_view);
    }

    public void onBackPressed() {
       finish();
    }
}
