package com.royalstatus.remote.control.universal.forall.tv;

import android.content.ClipboardManager;

public abstract class StatusHD_ClipboardListener implements ClipboardManager.OnPrimaryClipChangedListener {
}
