package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;


public class PreviewActivity extends AppCompatActivity {
    private String imgPath;
    private ImageView imgPreview;
    private String videoPath;
    private VideoView videoPreview;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_image_preview);
        String str = "";
        this.imgPath = getIntent().hasExtra("image") ? getIntent().getStringExtra("image") : str;
        if (getIntent().hasExtra("video")) {
            str = getIntent().getStringExtra("video");
        }
        this.videoPath = str;
        initViews();
    }

    private void initViews() {
        findViewById(R.id.imgBack).setOnClickListener(new PreviewActivity$$ExternalSyntheticLambda0(this));
        this.imgPreview = (ImageView) findViewById(R.id.imgPreview);
        this.videoPreview = (VideoView) findViewById(R.id.videoPreview);
        if (this.videoPath.endsWith(".mp4")) {
            this.videoPreview.setVisibility(View.VISIBLE);
            this.videoPreview.setVideoPath(this.videoPath);
            this.videoPreview.setMediaController(new MediaController(this));
            this.videoPreview.start();
            return;
        }
        this.imgPreview.setVisibility(View.VISIBLE);
        Glide.with((FragmentActivity) this).load(this.imgPath).into(this.imgPreview);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$initViews$0$com-royalstatus-remote-control-universal-forall-tv-PreviewActivity  reason: not valid java name */
    public /* synthetic */ void m25lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvPreviewActivity(View view) {
        onBackPressed();
    }

    public void onBackPressed() {
        PreviewActivity.this.finish();
    }

}
