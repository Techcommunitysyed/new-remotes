package com.royalstatus.remote.control.universal.forall.tv;

public class Remote {
    String category;
    String f76id;
    String remote;

    public String getId() {
        return this.f76id;
    }

    public void setId(String str) {
        this.f76id = str;
    }

    public String getCategory() {
        return this.category;
    }

    public void setCategory(String str) {
        this.category = str;
    }

    public String getRemote() {
        return this.remote;
    }

    public void setRemote(String str) {
        this.remote = str;
    }
}
