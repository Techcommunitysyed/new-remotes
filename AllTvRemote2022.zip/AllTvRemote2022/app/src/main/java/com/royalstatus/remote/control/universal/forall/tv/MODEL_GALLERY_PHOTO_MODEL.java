package com.royalstatus.remote.control.universal.forall.tv;

import java.io.Serializable;

public class MODEL_GALLERY_PHOTO_MODEL implements Serializable {
    private String albumName;
    private int id;
    private String photoUri;

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getAlbumName() {
        return this.albumName;
    }

    public void setAlbumName(String str) {
        this.albumName = str;
    }

    public String getPhotoUri() {
        return this.photoUri;
    }

    public void setPhotoUri(String str) {
        this.photoUri = str;
    }
}
