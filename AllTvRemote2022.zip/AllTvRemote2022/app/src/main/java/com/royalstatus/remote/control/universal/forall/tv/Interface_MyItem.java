package com.royalstatus.remote.control.universal.forall.tv;

public interface Interface_MyItem {
    void OnMyClick1(int i, Object obj);
}
