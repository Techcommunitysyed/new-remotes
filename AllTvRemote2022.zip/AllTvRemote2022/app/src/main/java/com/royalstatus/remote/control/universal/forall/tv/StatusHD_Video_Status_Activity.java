package com.royalstatus.remote.control.universal.forall.tv;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.newnativeads.NativeHelper;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_downloader.Status_FacebookActivity;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_downloader.Status_InstagramActivity;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_downloader.status_util.Utils;
import java.util.ArrayList;
import java.util.Objects;

public class StatusHD_Video_Status_Activity extends AppCompatActivity {
    String CopyKey = "";
    String CopyValue = "";
    /* access modifiers changed from: private */
    public ClipboardManager clipBoard;
    String[] permissions = {"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    ImageView rvFB;
    ImageView rvGallery;
    ImageView rvInsta;

    public void initViews() {
        this.clipBoard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (getIntent().getExtras() != null) {
            for (String str : getIntent().getExtras().keySet()) {
                this.CopyKey = str;
                String string = getIntent().getExtras().getString(this.CopyKey);
                if (this.CopyKey.equals("android.intent.extra.TEXT")) {
                    this.CopyValue = getIntent().getExtras().getString(this.CopyKey);
                    callText(string);
                } else {
                    this.CopyValue = "";
                    callText(string);
                }
            }
        }
        ClipboardManager clipboardManager = this.clipBoard;
        if (clipboardManager != null) {
            clipboardManager.addPrimaryClipChangedListener(new StatusHD_ClipboardListener() {
                public void onPrimaryClipChanged() {
                    try {
                        StatusHD_Video_Status_Activity statusHD_Video_Status_Activity = StatusHD_Video_Status_Activity.this;
                        CharSequence text = statusHD_Video_Status_Activity.clipBoard.getPrimaryClip().getItemAt(0).getText();
                        Objects.requireNonNull(text);
                        CharSequence charSequence = text;
                        statusHD_Video_Status_Activity.showNotification(text.toString());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
        if (Build.VERSION.SDK_INT >= 23) {
            checkPermissions(0);
        }
        Utils.createFileFolder();
    }

    private void callText(String str) {
        try {
            if (str.contains("instagram.com")) {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(101);
                } else {
                    callInstaActivity();
                }
            } else if (!str.contains("facebook.com")) {
            } else {
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermissions(104);
                } else {
                    callFacebookActivity();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void callInstaActivity() {
//        Intent intent = new Intent(StatusHD_Video_Status_Activity.this, Status_InstagramActivity.class);
//        intent.putExtra("CopyIntent", StatusHD_Video_Status_Activity.this.CopyValue);
//        StatusHD_Video_Status_Activity.this.startActivity(intent);
    }

    public void callFacebookActivity() {
//        Intent intent = new Intent(StatusHD_Video_Status_Activity.this, Status_FacebookActivity.class);
//        intent.putExtra("CopyIntent", StatusHD_Video_Status_Activity.this.CopyValue);
//        StatusHD_Video_Status_Activity.this.startActivity(intent);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_status);
        ((ImageView) findViewById(R.id.im_close)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                StatusHD_Video_Status_Activity.this.onBackPressed();
            }
        });
        this.rvFB = (ImageView) findViewById(R.id.rvFB);
        this.rvInsta = (ImageView) findViewById(R.id.rvInsta);
        this.rvGallery = (ImageView) findViewById(R.id.rvGallery);
        initViews();
        this.rvInsta.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= 23) {
                    boolean unused = StatusHD_Video_Status_Activity.this.checkPermissions(101);
                } else {
                    StatusHD_Video_Status_Activity.this.callInstaActivity();
                }
            }
        });
        this.rvFB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= 23) {
                    boolean unused = StatusHD_Video_Status_Activity.this.checkPermissions(104);
                } else {
                    StatusHD_Video_Status_Activity.this.callFacebookActivity();
                }
            }
        });
        this.rvGallery.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                StatusHD_Video_Status_Activity.this.startActivity(new Intent(StatusHD_Video_Status_Activity.this, StatusHD_MyGalleryActivity.class));

            }
        });
    }

    public void showNotification(String str) {
        if (str.contains("instagram.com") || str.contains("facebook.com") || str.contains("tiktok.com") || str.contains("twitter.com") || str.contains("likee") || str.contains("sharechat") || str.contains("roposo") || str.contains("snackvideo") || str.contains("sck.io")) {
            Intent intent = new Intent(this, StatusHD_Video_Status_Activity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("Notification", str);
            PendingIntent activity = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel notificationChannel = new NotificationChannel(getResources().getString(R.string.app_name), getResources().getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
                notificationChannel.enableLights(true);
                notificationChannel.setLockscreenVisibility(1);
                notificationManager.createNotificationChannel(notificationChannel);
            }
            notificationManager.notify(1, new NotificationCompat.Builder((Context) this, getResources().getString(R.string.app_name)).setAutoCancel(true).setSmallIcon(R.drawable.ic_banner).setColor(getResources().getColor(R.color.black)).setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_banner)).setDefaults(-1).setPriority(1).setContentTitle("Copied text").setContentText(str).setChannelId(getResources().getString(R.string.app_name)).setFullScreenIntent(activity, true).build());
        }
    }

    /* access modifiers changed from: private */
    public boolean checkPermissions(int i) {
        ArrayList arrayList = new ArrayList();
        for (String str : this.permissions) {
            if (ContextCompat.checkSelfPermission(this, str) != 0) {
                arrayList.add(str);
            }
        }
        if (!arrayList.isEmpty()) {
            ActivityCompat.requestPermissions(this, (String[]) arrayList.toArray(new String[arrayList.size()]), i);
            return false;
        } else if (i == 100) {
            return true;
        } else {
            if (i == 101) {
                callInstaActivity();
                return true;
            } else if (i == 102) {
                return true;
            } else {
                if (i == 104) {
                    callFacebookActivity();
                    return true;
                } else if (i != 105) {
                    return true;
                } else {
                    callGalleryActivity();
                    return true;
                }
            }
        }
    }

    public void callGalleryActivity() {
        StatusHD_Video_Status_Activity.this.startActivity(new Intent(StatusHD_Video_Status_Activity.this, StatusHD_MyGalleryActivity.class));

    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 101) {
            if (iArr.length > 0 && iArr[0] == 0) {
                callInstaActivity();
            }
        } else if (i == 102) {
            if (iArr.length > 0) {
                int i2 = iArr[0];
            }
        } else if (i == 104) {
            if (iArr.length > 0 && iArr[0] == 0) {
                callFacebookActivity();
            }
        } else if (i == 105 && iArr.length > 0 && iArr[0] == 0) {
            callGalleryActivity();
        }
    }

    public void onBackPressed() {
        StatusHD_Video_Status_Activity.this.finish();

    }
}
