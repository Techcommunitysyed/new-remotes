package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.google.android.material.navigation.NavigationView;
//import com.two.dgbmapp.hdvideoprojector.Interface_MyItem;
//import com.two.dgbmapp.hdvideoprojector.OtherClass.Glob;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part3.Adapter.AdapterRemoteName;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.newnativeads.NativeHelper;
//import fastscroll.app.fastscrollalphabetindex.AlphabetIndexFastScrollRecyclerView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import fastscroll.app.fastscrollalphabetindex.AlphabetIndexFastScrollRecyclerView;


public class ActivityRemoteCompanyList extends AppCompatActivity {
    TextView No_txt;
    AdapterRemoteName adapter;
    AdapterRemoteName adapterRemoteName;
    ImageView back;
    String cate;
    AlphabetIndexFastScrollRecyclerView contacts_list;
    RelativeLayout gift;
    NavigationView nav_view;
    RecyclerView recyclercompanylist;
    EditText searchname;
    private ImageView setimage;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_remotecompany_list);
        adsandnavigation();
        setimage = (ImageView) findViewById(R.id.setimage);
        No_txt = (TextView) findViewById(R.id.No_txt);
        contacts_list = (AlphabetIndexFastScrollRecyclerView) findViewById(R.id.contacts_list);
        String lowerCase = getIntent().getStringExtra("cate").toLowerCase();
        cate = lowerCase;
        String lowerCase2 = lowerCase.toLowerCase();
        RequestManager with = Glide.with((FragmentActivity) this);
        with.load("file:///android_asset/images/" + lowerCase2 + ".png").into(setimage);
        try {
            AssetManager assets = getAssets();
            Glob.remotelist = new ArrayList<>(Arrays.asList(assets.list("remotes/" + cate)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.e("TAG===>>", "onCreate: " + Glob.remotelist.size());
        searchname = (EditText) findViewById(R.id.searchname);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclercompanylist);
        recyclercompanylist = recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        AdapterRemoteName adapterRemoteName2 = new AdapterRemoteName(this, this, Glob.remotelist, new Interface_MyItem() {
            public void OnMyClick1(int i, Object obj) {
                String str = "remotes/" + cate + "/" + ((String) obj);
                startActivity(new Intent(ActivityRemoteCompanyList.this, ActivityTestingRemote.class).putExtra("path", str));
                Log.e("AAA", "" + str);
            }
        });
        adapterRemoteName = adapterRemoteName2;
        recyclercompanylist.setAdapter(adapterRemoteName2);
        contacts_list.setLayoutManager(new LinearLayoutManager(this));
        AdapterRemoteName adapterRemoteName3 = new AdapterRemoteName(this, this, Glob.remotelist, new Interface_MyItem() {
            public void OnMyClick1(int i, Object obj) {
                StringBuilder sb = new StringBuilder();
                sb.append("remotes/");
                sb.append(cate);
                sb.append("/");
                sb.append((String) obj);
                startActivity(new Intent(ActivityRemoteCompanyList.this, ActivityTestingRemote.class).putExtra("path", sb.toString()));
                Log.e("AAA", "" + sb.toString());
            }
        });
        adapter = adapterRemoteName3;
        contacts_list.setAdapter(adapterRemoteName3);
        contacts_list.setIndexTextSize(14);
        contacts_list.setTypeface(Typeface.createFromAsset(getAssets(), "montserrat_medium.ttf"));
        contacts_list.setIndexbarHighLateTextColor("#F14762");
        contacts_list.setIndexBarHighLateTextVisibility(true);
        contacts_list.setIndexBarTransparentValue(1.0f);
        searchname.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                adapter.getFilter().filter(searchname.getText().toString());
                if (adapter.getItemCount() > 0) {
                    No_txt.setVisibility(View.GONE);
                    recyclercompanylist.setVisibility(View.VISIBLE);
                    return;
                }
                No_txt.setVisibility(View.VISIBLE);
                recyclercompanylist.setVisibility(View.GONE);
            }

            public void afterTextChanged(Editable editable) {
                recyclercompanylist.setVisibility(View.GONE);
            }
        });
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
        gift = (RelativeLayout) findViewById(R.id.gift);
        ImageView imageView = (ImageView) findViewById(R.id.back);
        back = imageView;
        imageView.setOnClickListener(new ActivityRemoteCompanyList$$ExternalSyntheticLambda0(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$adsandnavigation$0$com-two-dgbmapp-hdvideoprojector-part3-Activity-ActivityRemoteCompanyList  reason: not valid java name */
    public /* synthetic */ void m34lambda$adsandnavigation$0$comtwodgbmapphdvideoprojectorpart3ActivityActivityRemoteCompanyList(View view) {
        onBackPressed();
    }

    public void onBackPressed() {
        finish();

    }
}
