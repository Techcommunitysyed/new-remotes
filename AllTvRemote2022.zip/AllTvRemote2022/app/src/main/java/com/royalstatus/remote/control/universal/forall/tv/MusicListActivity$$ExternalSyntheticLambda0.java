package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;


public final  class MusicListActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final  MusicListActivity f$0;

    public  MusicListActivity$$ExternalSyntheticLambda0(MusicListActivity musicListActivity) {
        this.f$0 = musicListActivity;
    }

    public final void onClick(View view) {
        this.f$0.m24lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvMusicListActivity(view);
    }
}
