package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;
import android.widget.ProgressBar;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class InternetNotAvailableActivity$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ InternetNotAvailableActivity f$0;
    public final /* synthetic */ ProgressBar f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ InternetNotAvailableActivity$$ExternalSyntheticLambda1(InternetNotAvailableActivity internetNotAvailableActivity, ProgressBar progressBar, int i) {
        this.f$0 = internetNotAvailableActivity;
        this.f$1 = progressBar;
        this.f$2 = i;
    }

    public final void onClick(View view) {
        this.f$0.m1552lambda$onCreate$1$vocsygoogleadsInternetNotAvailableActivity(this.f$1, this.f$2, view);
    }
}
