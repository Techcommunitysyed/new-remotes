package com.royalstatus.remote.control.universal.forall.tv;

public class HistoryMo {
    String ID;
    String email;
    String phone;
    String username;

    public String getID() {
        return this.ID;
    }

    public void setID(String str) {
        this.ID = str;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String str) {
        this.username = str;
    }

    public String getUserphone() {
        return this.phone;
    }

    public void setUserphone(String str) {
        this.phone = str;
    }

    public String getUseremail() {
        return this.email;
    }

    public void setUseremail(String str) {
        this.email = str;
    }
}
