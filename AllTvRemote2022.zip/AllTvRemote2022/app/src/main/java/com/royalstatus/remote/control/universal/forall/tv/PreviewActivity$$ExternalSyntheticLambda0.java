package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;


public final  class PreviewActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final  PreviewActivity f$0;

    public  PreviewActivity$$ExternalSyntheticLambda0(PreviewActivity previewActivity) {
        this.f$0 = previewActivity;
    }

    public final void onClick(View view) {
        this.f$0.m25lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvPreviewActivity(view);
    }
}
