package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.android.material.navigation.NavigationView;
import com.royalstatus.remote.control.universal.forall.tv.databinding.ActivityMyRemoteSaveBinding;

public class MyRemoteSaveActivity extends AppCompatActivity {
    public static TextView textView;
    ImageView back;
    ActivityMyRemoteSaveBinding binding;
    RelativeLayout gift;
    Database helper;
    NavigationView nav_view;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActivityMyRemoteSaveBinding inflate = ActivityMyRemoteSaveBinding.inflate(getLayoutInflater());
        this.binding = inflate;
        setContentView((View) inflate.getRoot());
        adsandnavigation();
        Database database = new Database(this);
        this.helper = database;
        if (database.Get_Data().size() == 0) {
            this.binding.tvNotFound.setVisibility(0);
            return;
        }
        textView = (TextView) findViewById(R.id.tv_notFound);
        this.binding.recyclersavedlist.setLayoutManager(new LinearLayoutManager(this, 1, false));
        this.binding.recyclersavedlist.setAdapter(new AdapterRemoteSaved(this));
        this.binding.tvNotFound.setVisibility(View.GONE);
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
        this.gift = (RelativeLayout) findViewById(R.id.gift);
        ImageView imageView = (ImageView) findViewById(R.id.ic_back);
        this.back = imageView;
        imageView.setOnClickListener(new MyRemoteSaveActivity$$ExternalSyntheticLambda0(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$adsandnavigation$0$com-two-dgbmapp-hdvideoprojector-part3-Activity-MyRemoteSaveActivity  reason: not valid java name */
    public /* synthetic */ void m36lambda$adsandnavigation$0$comtwodgbmapphdvideoprojectorpart3ActivityMyRemoteSaveActivity(View view) {
        onBackPressed();
    }

    public void onBackPressed() {
        MyRemoteSaveActivity.this.finish();
    }

    public void onPostResume() {
        super.onPostResume();
    }
}
