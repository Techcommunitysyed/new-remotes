package com.royalstatus.remote.control.universal.forall.tv;

import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.VIDEO_MODEL;
import java.util.List;

public class VIDEO_PLAYER_ACTIVITY extends AppCompatActivity {
    private List<VIDEO_MODEL> list;
    private int position;
    private VideoView videoView;

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        if (z) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(3332);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_video_player);
        initView();
    }

    private void initView() {
        this.videoView = (VideoView) findViewById(R.id.player_view);
        ((TextView) findViewById(R.id.title)).setSelected(true);
        if (getIntent().getExtras() != null) {
            this.position = getIntent().getIntExtra("position", 0);
            List<VIDEO_MODEL> list2 = (List) getIntent().getSerializableExtra("list");
            this.list = list2;
            if (list2 == null || list2.isEmpty()) {
                ((TextView) findViewById(R.id.title)).setText("Sax Video Player HD");
                Toast.makeText(this, "Something is wrong..!!", Toast.LENGTH_SHORT).show();
                return;
            }
            ((TextView) findViewById(R.id.title)).setText(this.list.get(this.position).getDisplayName());
            MediaController mediaController = new MediaController(this);
            mediaController.setAnchorView(this.videoView);
            this.videoView.setMediaController(mediaController);
            this.videoView.setVideoURI(Uri.parse(this.list.get(this.position).getData()));
            this.videoView.requestFocus();
            this.videoView.start();
            return;
        }
        ((TextView) findViewById(R.id.title)).setText("Sax Video Player HD");
        Toast.makeText(this, "Something is wrong..!!", Toast.LENGTH_SHORT).show();
    }

    public void onBackPressed() {
        super.onBackPressed();
    }
}
