package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DevicesAdapter extends RecyclerView.Adapter<DevicesAdapter.MyViewHolder> {
    private Activity mActivity;
    /* access modifiers changed from: private */
    public onDeviceClickListener mDeviceClickListener;
    private ArrayList<String> mDevicesArrayList;

    interface onDeviceClickListener {
        void onDeviceClick(int i);
    }

    public DevicesAdapter(ArrayList<String> arrayList, Activity activity, onDeviceClickListener ondeviceclicklistener) {
        this.mDevicesArrayList = arrayList;
        this.mActivity = activity;
        this.mDeviceClickListener = ondeviceclicklistener;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.devices_item, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
        myViewHolder.textName.setText(this.mDevicesArrayList.get(i));
        myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DevicesAdapter.this.mDeviceClickListener.onDeviceClick(i);
            }
        });
    }

    public int getItemCount() {
        return this.mDevicesArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        /* access modifiers changed from: private */
        public TextView textName;

        public MyViewHolder(View view) {
            super(view);
            this.textName = (TextView) view.findViewById(R.id.textName);
        }
    }

    public void filterList(ArrayList<String> arrayList) {
        this.mDevicesArrayList = arrayList;
        notifyDataSetChanged();
    }
}
