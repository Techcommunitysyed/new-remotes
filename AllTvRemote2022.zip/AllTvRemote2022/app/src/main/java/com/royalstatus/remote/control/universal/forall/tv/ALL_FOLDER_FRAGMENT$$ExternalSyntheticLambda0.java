package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ALL_FOLDER_FRAGMENT$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ ALL_FOLDER_FRAGMENT f$0;

    public /* synthetic */ ALL_FOLDER_FRAGMENT$$ExternalSyntheticLambda0(ALL_FOLDER_FRAGMENT all_folder_fragment) {
        this.f$0 = all_folder_fragment;
    }

    public final void onClick(View view) {
        this.f$0.m29lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart2ALL_FOLDER_FRAGMENT(view);
    }
}
