package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ActivitySaveRemote$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ ActivitySaveRemote f$0;

    public /* synthetic */ ActivitySaveRemote$$ExternalSyntheticLambda0(ActivitySaveRemote activitySaveRemote) {
        this.f$0 = activitySaveRemote;
    }

    public final void onClick(View view) {
        this.f$0.m35lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart3ActivityActivitySaveRemote(view);
    }
}
