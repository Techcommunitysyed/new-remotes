package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
//import com.facebook.internal.logging.monitor.MonitorLogServerProtocol;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.newnativeads.NativeHelper;

public class ActivitySaveRemote extends AppCompatActivity {
    /* access modifiers changed from: private */
    public String Category;
    boolean SelectedItem = false;
    private String Tv_Name;
    ImageView back;
    ImageView bathroomimg;
    ImageView bedroomimg;
    ImageView defaultimgview;
    /* access modifiers changed from: private */
    public EditText edittext;
    ImageView homeimg;
    ImageView livingroomimg;
    ImageView officeimg;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_saveremote);
        this.Tv_Name = getIntent().getStringExtra("Tv_Name");
        this.edittext = (EditText) findViewById(R.id.edittext);
        this.defaultimgview = (ImageView) findViewById(R.id.defaultimg);
        this.bedroomimg = (ImageView) findViewById(R.id.bedroom);
        this.livingroomimg = (ImageView) findViewById(R.id.livingroom);
        this.bathroomimg = (ImageView) findViewById(R.id.bathroom);
        this.homeimg = (ImageView) findViewById(R.id.hometheater);
        this.officeimg = (ImageView) findViewById(R.id.office);
        ImageView imageView = (ImageView) findViewById(R.id.back);
        this.back = imageView;
        imageView.setOnClickListener(new ActivitySaveRemote$$ExternalSyntheticLambda0(this));
        this.SelectedItem = false;
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivitySaveRemote.this.onBackPressed();
            }
        });
        findViewById(R.id.rel_clear).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ActivitySaveRemote.this.edittext.setText("");
            }
        });
        findViewById(R.id.defaultimg).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String unused = ActivitySaveRemote.this.Category = "Default";
                ActivitySaveRemote.this.SelectedItem = true;
                ActivitySaveRemote.this.defaultimgview.setImageResource(R.drawable.tv1_sel);
                ActivitySaveRemote.this.bedroomimg.setImageResource(R.drawable.tv_2);
                ActivitySaveRemote.this.livingroomimg.setImageResource(R.drawable.tv_3);
                ActivitySaveRemote.this.bathroomimg.setImageResource(R.drawable.tv_4);
                ActivitySaveRemote.this.homeimg.setImageResource(R.drawable.tv_5);
                ActivitySaveRemote.this.officeimg.setImageResource(R.drawable.tv_6);
            }
        });
        findViewById(R.id.bedroom).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String unused = ActivitySaveRemote.this.Category = "Tv1";
                ActivitySaveRemote.this.SelectedItem = true;
                ActivitySaveRemote.this.defaultimgview.setImageResource(R.drawable.tv_1);
                ActivitySaveRemote.this.bedroomimg.setImageResource(R.drawable.tv2_sel);
                ActivitySaveRemote.this.livingroomimg.setImageResource(R.drawable.tv_3);
                ActivitySaveRemote.this.bathroomimg.setImageResource(R.drawable.tv_4);
                ActivitySaveRemote.this.homeimg.setImageResource(R.drawable.tv_5);
                ActivitySaveRemote.this.officeimg.setImageResource(R.drawable.tv_6);
            }
        });
        findViewById(R.id.livingroom).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String unused = ActivitySaveRemote.this.Category = "Living Room";
                ActivitySaveRemote.this.SelectedItem = true;
                ActivitySaveRemote.this.defaultimgview.setImageResource(R.drawable.tv_1);
                ActivitySaveRemote.this.bedroomimg.setImageResource(R.drawable.tv_2);
                ActivitySaveRemote.this.livingroomimg.setImageResource(R.drawable.tv3_sel);
                ActivitySaveRemote.this.bathroomimg.setImageResource(R.drawable.tv_4);
                ActivitySaveRemote.this.homeimg.setImageResource(R.drawable.tv_5);
                ActivitySaveRemote.this.officeimg.setImageResource(R.drawable.tv_6);
            }
        });
        findViewById(R.id.bathroom).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String unused = ActivitySaveRemote.this.Category = "Bathroom";
                ActivitySaveRemote.this.SelectedItem = true;
                ActivitySaveRemote.this.defaultimgview.setImageResource(R.drawable.tv_1);
                ActivitySaveRemote.this.bedroomimg.setImageResource(R.drawable.tv_2);
                ActivitySaveRemote.this.livingroomimg.setImageResource(R.drawable.tv_3);
                ActivitySaveRemote.this.bathroomimg.setImageResource(R.drawable.tv4_sel);
                ActivitySaveRemote.this.homeimg.setImageResource(R.drawable.tv_5);
                ActivitySaveRemote.this.officeimg.setImageResource(R.drawable.tv_6);
            }
        });
        findViewById(R.id.hometheater).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String unused = ActivitySaveRemote.this.Category = "Home Theater";
                ActivitySaveRemote.this.SelectedItem = true;
                ActivitySaveRemote.this.defaultimgview.setImageResource(R.drawable.tv_1);
                ActivitySaveRemote.this.bedroomimg.setImageResource(R.drawable.tv_2);
                ActivitySaveRemote.this.livingroomimg.setImageResource(R.drawable.tv_3);
                ActivitySaveRemote.this.bathroomimg.setImageResource(R.drawable.tv_4);
                ActivitySaveRemote.this.homeimg.setImageResource(R.drawable.tv5_sel);
                ActivitySaveRemote.this.officeimg.setImageResource(R.drawable.tv_6);
            }
        });
        findViewById(R.id.office).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String unused = ActivitySaveRemote.this.Category = "Office";
                ActivitySaveRemote.this.SelectedItem = true;
                ActivitySaveRemote.this.defaultimgview.setImageResource(R.drawable.tv_1);
                ActivitySaveRemote.this.bedroomimg.setImageResource(R.drawable.tv_2);
                ActivitySaveRemote.this.livingroomimg.setImageResource(R.drawable.tv_3);
                ActivitySaveRemote.this.bathroomimg.setImageResource(R.drawable.tv_4);
                ActivitySaveRemote.this.homeimg.setImageResource(R.drawable.tv_5);
                ActivitySaveRemote.this.officeimg.setImageResource(R.drawable.tv6_sel);
            }
        });
        findViewById(R.id.img_start).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.e("Value", "bb: " + ActivitySaveRemote.this.SelectedItem);
                Log.e("Value", "tt: " + ActivitySaveRemote.this.edittext.getText());
                if (ActivitySaveRemote.this.edittext.getText().toString().isEmpty()) {
                    Toast.makeText(ActivitySaveRemote.this, "Please Select Tv ..!!", Toast.LENGTH_SHORT).show();
                } else if (!ActivitySaveRemote.this.SelectedItem) {
                    Toast.makeText(ActivitySaveRemote.this, "Please Select Tv ..!!", Toast.LENGTH_SHORT).show();
                } else {
                    ActivitySaveRemote activitySaveRemote = ActivitySaveRemote.this;
                    Intent putExtra = new Intent(ActivitySaveRemote.this, RemoteControllerActivity.class).putExtra("isdirect", true).putExtra(null, ActivitySaveRemote.this.Category);
                    activitySaveRemote.startActivity(putExtra.putExtra("final_remote", ActivitySaveRemote.this.edittext.getText().toString().toUpperCase() + " TV"));
                    ActivitySaveRemote.this.finish();
                }
            }
        });
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$0$com-two-dgbmapp-hdvideoprojector-part3-Activity-ActivitySaveRemote  reason: not valid java name */
    public /* synthetic */ void m35lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart3ActivityActivitySaveRemote(View view) {
        onBackPressed();
    }

    public void onResume() {
        super.onResume();
        this.defaultimgview.setImageResource(R.drawable.tv_1);
        this.bedroomimg.setImageResource(R.drawable.tv_2);
        this.livingroomimg.setImageResource(R.drawable.tv_3);
        this.bathroomimg.setImageResource(R.drawable.tv_4);
        this.homeimg.setImageResource(R.drawable.tv_5);
        this.officeimg.setImageResource(R.drawable.tv_6);
    }

    public void onBackPressed() {
       finish();
    }
}
