package com.royalstatus.remote.control.universal.forall.tv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterRemoteSaved extends RecyclerView.Adapter<AdapterRemoteSaved.ViewHolder> {
    Activity activity;
    Database helper;

    public AdapterRemoteSaved(Activity activity2) {
        this.activity = activity2;
        this.helper = new Database(activity2);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(this.activity).inflate(R.layout.remotesave_item, viewGroup, false));
    }

    public void onBindViewHolder(final ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
        TextView textView = viewHolder.txt_category;
        textView.setText(this.helper.Get_Data().get(i).getCategory() + " TV");
        viewHolder.txt_remote.setText(this.helper.Get_Data().get(i).getRemote());
        if (this.helper.Get_Data().get(i).getCategory().equalsIgnoreCase("Default")) {
            viewHolder.img_category.setImageResource(R.drawable.tv_1_iv);
        } else if (this.helper.Get_Data().get(i).getCategory().equalsIgnoreCase("Living Room")) {
            viewHolder.img_category.setImageResource(R.drawable.tv_2_iv);
        } else if (this.helper.Get_Data().get(i).getCategory().equalsIgnoreCase("Bathroom")) {
            viewHolder.img_category.setImageResource(R.drawable.tv_3_iv);
        } else if (this.helper.Get_Data().get(i).getCategory().equalsIgnoreCase("Home Theater")) {
            viewHolder.img_category.setImageResource(R.drawable.tv_4_iv);
        } else if (this.helper.Get_Data().get(i).getCategory().equalsIgnoreCase("Office")) {
            viewHolder.img_category.setImageResource(R.drawable.tv_5_iv);
        } else if (this.helper.Get_Data().get(i).getCategory().equalsIgnoreCase("Bedroom")) {
            viewHolder.img_category.setImageResource(R.drawable.tv_6_iv);
        }
        viewHolder.relative_main.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AdapterRemoteSaved.this.activity.startActivity(new Intent(AdapterRemoteSaved.this.activity, RemoteControllerActivity.class).putExtra("isdirect", true).putExtra("final_remote", AdapterRemoteSaved.this.helper.Get_Data().get(i).getRemote()));
            }
        });
        viewHolder.img_dot.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                final Dialog dialog = new Dialog(AdapterRemoteSaved.this.activity);
                dialog.setContentView(R.layout.dialog_delete_aa);
                dialog.show();
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.findViewById(R.id.rela_edit).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        dialog.dismiss();
                        final Dialog dialog = new Dialog(AdapterRemoteSaved.this.activity);
                        dialog.setContentView(R.layout.layout_renameremote_name);
                        final EditText editText = (EditText) dialog.findViewById(R.id.edittext_rename);
                        editText.setText(AdapterRemoteSaved.this.helper.Get_Data().get(i).getRemote());
                        ((TextView) dialog.findViewById(R.id.txt_cancel)).setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                dialog.dismiss();
                            }
                        });
                        ((TextView) dialog.findViewById(R.id.txt_save)).setOnClickListener(new View.OnClickListener() {
                            public void onClick(View view) {
                                AdapterRemoteSaved.this.helper.Update(AdapterRemoteSaved.this.helper.Get_Data().get(i).getId(), editText.getText().toString());
                                AdapterRemoteSaved.this.notifyItemChanged(i);
                                dialog.dismiss();
                            }
                        });
                        dialog.show();
                    }
                });
                dialog.findViewById(R.id.rela_Delete).setOnClickListener(new View.OnClickListener() {
                    @SuppressLint("ResourceType")
                    public void onClick(View view) {
                        DialogInterface.OnClickListener onClickListener = null;
                        new AlertDialog.Builder(AdapterRemoteSaved.this.activity).setTitle((CharSequence) AdapterRemoteSaved.this.helper.Get_Data().get(i).getCategory() + " TV").setMessage((CharSequence) "Delete the remote " + AdapterRemoteSaved.this.helper.Get_Data().get(i).getRemote() + " ?").setPositiveButton((CharSequence) "Delete", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                try {
                                    AdapterRemoteSaved.this.helper.Delete(AdapterRemoteSaved.this.helper.Get_Data().get(i).getId());
                                    if (AdapterRemoteSaved.this.helper.Get_Data().size() == 0) {
                                        MyRemoteSaveActivity.textView.setVisibility(View.VISIBLE);
                                    }
                                    AdapterRemoteSaved.this.notifyDataSetChanged();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                dialog.dismiss();
                            }
                        }).setNegativeButton((CharSequence) "Cancel", (DialogInterface.OnClickListener) null).setIcon(17301543).show();
                    }
                });
            }
        });
        viewHolder.relative_cross.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                viewHolder.linear_main.setVisibility(View.GONE);
                viewHolder.relative_main.setVisibility(View.VISIBLE);
            }
        });
    }

    public int getItemCount() {
        return this.helper.Get_Data().size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final RelativeLayout delete;
        public final ImageView img_category;
        public final ImageView img_dot;
        public final LinearLayout linear_main;
        public final RelativeLayout relative_cross;
        public final RelativeLayout relative_main;
        public final RelativeLayout rename;
        public final TextView txt_category;
        public final TextView txt_remote;

        public ViewHolder(View view) {
            super(view);
            this.txt_category = (TextView) view.findViewById(R.id.txt_category);
            this.txt_remote = (TextView) view.findViewById(R.id.txt_remote);
            this.img_category = (ImageView) view.findViewById(R.id.img_category);
            this.img_dot = (ImageView) view.findViewById(R.id.img_dot);
            this.relative_cross = (RelativeLayout) view.findViewById(R.id.relative_cross);
            this.linear_main = (LinearLayout) view.findViewById(R.id.linear_main);
            this.relative_main = (RelativeLayout) view.findViewById(R.id.relative_main);
            this.rename = (RelativeLayout) view.findViewById(R.id.rename);
            this.delete = (RelativeLayout) view.findViewById(R.id.delete);
        }
    }
}
