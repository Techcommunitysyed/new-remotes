package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataBaseHelper extends SQLiteOpenHelper {
    public DataBaseHelper(Context context, String str, SQLiteDatabase.CursorFactory cursorFactory, int i) {
        super(context, str, cursorFactory, i);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        try {
            sQLiteDatabase.execSQL("create table USERS( ID integer primary key autoincrement,user_name  text,user_phone  text,user_email text); ");
            sQLiteDatabase.execSQL("create table HISTORY( ID integer primary key autoincrement,user_name  text,user_phone  text,user_email text); ");
        } catch (Exception unused) {
            Log.e("Error", "exceptioin");
        }
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS USERS");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS HISTORY");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS SEMESTER1");
        onCreate(sQLiteDatabase);
    }
}
