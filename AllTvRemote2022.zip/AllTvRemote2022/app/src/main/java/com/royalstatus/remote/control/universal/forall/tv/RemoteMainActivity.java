package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AppCompatActivity;

import com.royalstatus.remote.control.universal.forall.tv.databinding.ActivityRemoteMainBinding;

public class RemoteMainActivity extends AppCompatActivity {
    ActivityRemoteMainBinding remoteMainBinding;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActivityRemoteMainBinding inflate = ActivityRemoteMainBinding.inflate(getLayoutInflater());
        this.remoteMainBinding = inflate;
        setContentView((View) inflate.getRoot());
        adsandnavigation();
        this.remoteMainBinding.ivAddRemote.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                RemoteMainActivity.this.startActivity(new Intent(RemoteMainActivity.this, ActivityRemoteCompanyList.class).putExtra("cate", "Tv"));

            }
        });
        this.remoteMainBinding.ivSaveRemote.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                RemoteMainActivity.this.startActivity(new Intent(RemoteMainActivity.this, MyRemoteSaveActivity.class));

            }
        });
        this.remoteMainBinding.back.setOnClickListener(new RemoteMainActivity$$ExternalSyntheticLambda0(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$0$com-two-dgbmapp-hdvideoprojector-part3-Activity-RemoteMainActivity  reason: not valid java name */
    public /* synthetic */ void m38lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart3ActivityRemoteMainActivity(View view) {
        onBackPressed();
    }

    private void adsandnavigation() {
        this.remoteMainBinding.txNm.setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
    }

    public void onBackPressed() {
        RemoteMainActivity.this.finish();
    }
}
