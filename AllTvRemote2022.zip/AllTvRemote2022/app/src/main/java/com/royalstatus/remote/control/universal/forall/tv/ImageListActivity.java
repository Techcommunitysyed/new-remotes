package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.royalstatus.remote.control.universal.forall.tv.ImageAdapter;
import java.util.ArrayList;


public class ImageListActivity extends AppCompatActivity {
    public ArrayList<String> imagesArrayList = new ArrayList<>();
    private ImageAdapter mImageAdapter;
    private RecyclerView tvListView;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_image_list);
        initViews();
    }

    private void initViews() {
        findViewById(R.id.imgBack).setOnClickListener(new ImageListActivity$$ExternalSyntheticLambda0(this));
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.tvListView);
        this.tvListView = recyclerView;
        recyclerView.setLayoutManager(new GridLayoutManager((Context) this, 2, 1, false));
        this.tvListView.setItemAnimator(new DefaultItemAnimator());
        this.tvListView.setHasFixedSize(true);
        this.imagesArrayList.clear();
        this.imagesArrayList.addAll(Constant.getAllShownImagesPath(this));
        ImageAdapter imageAdapter = new ImageAdapter(this.imagesArrayList, this, new ImageAdapter.ImageClickListener() {
            public void onImageClick(int i) {
                ImageListActivity.this.startActivity(new Intent(ImageListActivity.this, PreviewActivity.class).putExtra("image", (String) ImageListActivity.this.imagesArrayList.get(i)));
            }
        });
        this.mImageAdapter = imageAdapter;
        this.tvListView.setAdapter(imageAdapter);
        this.mImageAdapter.notifyDataSetChanged();
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$initViews$0$com-royalstatus-remote-control-universal-forall-tv-ImageListActivity  reason: not valid java name */
    public /* synthetic */ void m23lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvImageListActivity(View view) {
        onBackPressed();
    }

    public void onBackPressed() {
        ImageListActivity.this.finish();
    }
}
