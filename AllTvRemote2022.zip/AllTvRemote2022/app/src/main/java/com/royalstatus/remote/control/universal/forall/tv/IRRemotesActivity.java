package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;


public class IRRemotesActivity extends AppCompatActivity implements View.OnClickListener {
    private LinearLayout btnAC;
    private LinearLayout btnAVReceiver;
    private LinearLayout btnCamera;
    private LinearLayout btnDVD;
    private LinearLayout btnFan;
    private LinearLayout btnProjector;
    private LinearLayout btnSetupBox;
    private LinearLayout btnTV;
    private LinearLayout btnWiFiDevice;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_irremotes);

        initViews();
    }

    private void initViews() {
        findViewById(R.id.imgBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                IRRemotesActivity.this.onBackPressed();
            }
        });
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.btnTV);
        this.btnTV = linearLayout;
        linearLayout.setOnClickListener(this);
        LinearLayout linearLayout2 = (LinearLayout) findViewById(R.id.btnSetupBox);
        this.btnSetupBox = linearLayout2;
        linearLayout2.setOnClickListener(this);
        LinearLayout linearLayout3 = (LinearLayout) findViewById(R.id.btnAC);
        this.btnAC = linearLayout3;
        linearLayout3.setOnClickListener(this);
        LinearLayout linearLayout4 = (LinearLayout) findViewById(R.id.btnCamera);
        this.btnCamera = linearLayout4;
        linearLayout4.setOnClickListener(this);
        LinearLayout linearLayout5 = (LinearLayout) findViewById(R.id.btnProjector);
        this.btnProjector = linearLayout5;
        linearLayout5.setOnClickListener(this);
        LinearLayout linearLayout6 = (LinearLayout) findViewById(R.id.btnAVReceiver);
        this.btnAVReceiver = linearLayout6;
        linearLayout6.setOnClickListener(this);
        LinearLayout linearLayout7 = (LinearLayout) findViewById(R.id.btnDVD);
        this.btnDVD = linearLayout7;
        linearLayout7.setOnClickListener(this);
        LinearLayout linearLayout8 = (LinearLayout) findViewById(R.id.btnFan);
        this.btnFan = linearLayout8;
        linearLayout8.setOnClickListener(this);
        LinearLayout linearLayout9 = (LinearLayout) findViewById(R.id.btnWiFiDevice);
        this.btnWiFiDevice = linearLayout9;
        linearLayout9.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnAC /*2131361970*/:
                IRRemotesActivity.this.startActivity(new Intent(IRRemotesActivity.this, AcBrandsActivity.class));

                return;
            case R.id.btnAVReceiver /*2131361971*/:
                IRRemotesActivity.this.startActivity(new Intent(IRRemotesActivity.this, AVReceiverActivity.class));

                return;
            case R.id.btnCamera /*2131361973*/:
                IRRemotesActivity.this.startActivity(new Intent(IRRemotesActivity.this, CamraActivity.class));

                return;
            case R.id.btnDVD /*2131361975*/:
                IRRemotesActivity.this.startActivity(new Intent(IRRemotesActivity.this, DVDPlayerActivity.class));

                return;
            case R.id.btnFan /*2131361976*/:
                IRRemotesActivity.this.startActivity(new Intent(IRRemotesActivity.this, FanActivity.class));

                return;
            case R.id.btnProjector /*2131361982*/:
                IRRemotesActivity.this.startActivity(new Intent(IRRemotesActivity.this, ProjectorActivity.class));

                return;
            case R.id.btnSetupBox /*2131361984*/:
                IRRemotesActivity.this.startActivity(new Intent(IRRemotesActivity.this, SetUPBoxActivity.class));

                return;
            case R.id.btnTV /*2131361986*/:
                IRRemotesActivity.this.startActivity(new Intent(IRRemotesActivity.this, TVBrandsActivity.class));

                return;
            case R.id.btnWiFiDevice /*2131361988*/:
                IRRemotesActivity.this.startActivity(new Intent(IRRemotesActivity.this, WiFiDeviceActivity.class));

                return;
            default:
                return;
        }
    }

    public void onBackPressed() {
        IRRemotesActivity.this.finish();

    }
}
