package com.royalstatus.remote.control.universal.forall.tv;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class VIDEO_MODEL implements Serializable, Comparable<VIDEO_MODEL> {
    public static Comparator<VIDEO_MODEL> sort_date = new Comparator<VIDEO_MODEL>() {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

        public int compare(VIDEO_MODEL video_model, VIDEO_MODEL video_model2) {
            try {
                return this.format.parse(VIDEO_MODEL.folderDate(video_model.getDate())).compareTo(this.format.parse(VIDEO_MODEL.folderDate(video_model2.getDate())));
            } catch (ParseException e) {
                throw new IllegalArgumentException(e);
            }
        }
    };
    public static Comparator<VIDEO_MODEL> sort_length = new Comparator<VIDEO_MODEL>() {
        SimpleDateFormat format1 = new SimpleDateFormat("hh:mm:ss");

        public int compare(VIDEO_MODEL video_model, VIDEO_MODEL video_model2) {
            try {
                return this.format1.parse(VIDEO_MODEL.duration(video_model.getDuartion())).compareTo(this.format1.parse(VIDEO_MODEL.duration(video_model2.getDuartion())));
            } catch (ParseException e) {
                throw new IllegalArgumentException(e);
            }
        }
    };
    public static Comparator<VIDEO_MODEL> sort_location = new Comparator<VIDEO_MODEL>() {
        public int compare(VIDEO_MODEL video_model, VIDEO_MODEL video_model2) {
            return video_model.getData().compareTo(video_model2.getData());
        }
    };
    public static Comparator<VIDEO_MODEL> sort_name = new Comparator<VIDEO_MODEL>() {
        public int compare(VIDEO_MODEL video_model, VIDEO_MODEL video_model2) {
            return video_model.getTitle().compareTo(video_model2.getTitle());
        }
    };
    public static Comparator<VIDEO_MODEL> sort_resolution = new Comparator<VIDEO_MODEL>() {
        public int compare(VIDEO_MODEL video_model, VIDEO_MODEL video_model2) {
            return video_model.getResolution().compareTo(video_model2.getResolution());
        }
    };
    public static Comparator<VIDEO_MODEL> sort_size = new Comparator<VIDEO_MODEL>() {
        public int compare(VIDEO_MODEL video_model, VIDEO_MODEL video_model2) {
            return video_model.getSize().compareTo(video_model2.getSize());
        }
    };
    private String data;
    public String date;
    public String displayName;
    private String duartion;
    public String id;
    private boolean isSelected = false;
    public String playlist_name;
    private String resolution;
    private String size;
    public String title;

    public String getPlaylist_name() {
        return this.playlist_name;
    }

    public void setPlaylist_name(String str) {
        this.playlist_name = str;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public void setDisplayName(String str) {
        this.displayName = str;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getData() {
        return this.data;
    }

    public void setData(String str) {
        this.data = str;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String str) {
        this.date = str;
    }

    public String getDuartion() {
        return this.duartion;
    }

    public void setDuartion(String str) {
        this.duartion = str;
    }

    public String getResolution() {
        return this.resolution;
    }

    public void setResolution(String str) {
        this.resolution = str;
    }

    public String getSize() {
        return this.size;
    }

    public void setSize(String str) {
        this.size = str;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public int compareTo(VIDEO_MODEL video_model) {
        return getId().compareTo(getId());
    }

    public static String folderDate(String str) {
        return new SimpleDateFormat("dd/MM/yyyy").format(new Date(Long.parseLong(str) * 1000));
    }

    public static String duration(String str) {
        try {
            long parseInt = (long) Integer.parseInt(str);
            return String.format("%02d:%02d:%02d", new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(parseInt)), Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(parseInt) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(parseInt))), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(parseInt) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(parseInt)))});
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}
