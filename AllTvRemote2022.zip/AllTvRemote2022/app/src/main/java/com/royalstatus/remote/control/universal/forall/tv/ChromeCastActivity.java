package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class ChromeCastActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int PERMISSION_REQUEST_CODE = 1;
    private LinearLayout btnAudios;
    private LinearLayout btnChromeCast;
    private LinearLayout btnPhotos;
    private LinearLayout btnVideos;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_chrome_cast);
        initViews();
    }

    private void initViews() {
        findViewById(R.id.imgBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ChromeCastActivity.this.onBackPressed();
            }
        });
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.btnChromeCast);
        this.btnChromeCast = linearLayout;
        linearLayout.setOnClickListener(this);
        LinearLayout linearLayout2 = (LinearLayout) findViewById(R.id.btnPhotos);
        this.btnPhotos = linearLayout2;
        linearLayout2.setOnClickListener(this);
        LinearLayout linearLayout3 = (LinearLayout) findViewById(R.id.btnVideos);
        this.btnVideos = linearLayout3;
        linearLayout3.setOnClickListener(this);
        LinearLayout linearLayout4 = (LinearLayout) findViewById(R.id.btnAudios);
        this.btnAudios = linearLayout4;
        linearLayout4.setOnClickListener(this);
    }
    public void onClick(View view) {
        switch (view.getId()) {
            default: {
                return;
            }
            case 2131361987: {
                if (this.checkPermission()) {
//                    AllInOneAds.getInstance().showInter((Activity)this, (AllInOneAds.AllInOneAdsInterface)new 3(this));
                    return;
                }
                this.requestPermission();
                return;
            }
            case 2131361980: {
                if (this.checkPermission()) {
//                    AllInOneAds.getInstance().showInter((Activity)this, (AllInOneAds.AllInOneAdsInterface)new 2(this));
                    return;
                }
                this.requestPermission();
                return;
            }
            case 2131361974: {
                try {
                    this.startActivityForResult(new Intent("android.settings.WIFI_DISPLAY_SETTINGS"), 200);
                    Log.d((String)"TAGgg", (String)"open WiFi display settings in HTC");
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    try {
                        this.startActivityForResult(new Intent("com.samsung.wfd.LAUNCH_WFD_PICKER_DLG"), 200);
                        Log.d((String)"TAGgg", (String)"open WiFi display settings in samsung");
                        return;
                    }
                    catch (Exception exception2) {
                        try {
                            Toast.makeText((Context)this.getApplicationContext(), (CharSequence)"Device not supported", (int)1).show();
                            return;
                        }
                        catch (Exception exception3) {
                            this.startActivityForResult(new Intent("android.settings.CAST_SETTINGS"), 200);
                            Log.d((String)"TAGgg", (String)"open WiFi display settings in other");
                            return;
                        }
                    }
                }
            }
            case 2131361972:
        }
        if (this.checkPermission()) {
//            AllInOneAds.getInstance().showInter((Activity)this, (AllInOneAds.AllInOneAdsInterface)new 4(this));
            return;
        }
        this.requestPermission();
    }

 /*   public void onClick(View r5) {
        *//*
            r4 = this;
            java.lang.String r0 = "TAGgg"
            int r5 = r5.getId()
            switch(r5) {
                case 2131361972: goto L_0x0080;
                case 2131361974: goto L_0x003b;
                case 2131361980: goto L_0x0024;
                case 2131361987: goto L_0x000b;
                default: goto L_0x0009;
            }
        L_0x0009:
            goto L_0x0096
        L_0x000b:
            boolean r5 = r4.checkPermission()
            if (r5 == 0) goto L_0x001f
            vocsy.google.ads.AllInOneAds r5 = vocsy.google.ads.AllInOneAds.getInstance()
            com.royalstatus.remote.control.universal.forall.tv.ChromeCastActivity$3 r0 = new com.royalstatus.remote.control.universal.forall.tv.ChromeCastActivity$3
            r0.<init>()
            r5.showInter(r4, r0)
            goto L_0x0096
        L_0x001f:
            r4.requestPermission()
            goto L_0x0096
        L_0x0024:
            boolean r5 = r4.checkPermission()
            if (r5 == 0) goto L_0x0037
            vocsy.google.ads.AllInOneAds r5 = vocsy.google.ads.AllInOneAds.getInstance()
            com.royalstatus.remote.control.universal.forall.tv.ChromeCastActivity$2 r0 = new com.royalstatus.remote.control.universal.forall.tv.ChromeCastActivity$2
            r0.<init>()
            r5.showInter(r4, r0)
            goto L_0x0096
        L_0x0037:
            r4.requestPermission()
            goto L_0x0096
        L_0x003b:
            r5 = 200(0xc8, float:2.8E-43)
            android.content.Intent r1 = new android.content.Intent     // Catch:{ Exception -> 0x004d }
            java.lang.String r2 = "android.settings.WIFI_DISPLAY_SETTINGS"
            r1.<init>(r2)     // Catch:{ Exception -> 0x004d }
            r4.startActivityForResult(r1, r5)     // Catch:{ Exception -> 0x004d }
            java.lang.String r1 = "open WiFi display settings in HTC"
            android.util.Log.d(r0, r1)     // Catch:{ Exception -> 0x004d }
            goto L_0x0096
        L_0x004d:
            r1 = move-exception
            r1.printStackTrace()
            android.content.Intent r1 = new android.content.Intent     // Catch:{ Exception -> 0x0061 }
            java.lang.String r2 = "com.samsung.wfd.LAUNCH_WFD_PICKER_DLG"
            r1.<init>(r2)     // Catch:{ Exception -> 0x0061 }
            r4.startActivityForResult(r1, r5)     // Catch:{ Exception -> 0x0061 }
            java.lang.String r1 = "open WiFi display settings in samsung"
            android.util.Log.d(r0, r1)     // Catch:{ Exception -> 0x0061 }
            goto L_0x0096
        L_0x0061:
            android.content.Context r1 = r4.getApplicationContext()     // Catch:{ Exception -> 0x0070 }
            java.lang.String r2 = "Device not supported"
            r3 = 1
            android.widget.Toast r1 = android.widget.Toast.makeText(r1, r2, r3)     // Catch:{ Exception -> 0x0070 }
            r1.show()     // Catch:{ Exception -> 0x0070 }
            goto L_0x0096
        L_0x0070:
            android.content.Intent r1 = new android.content.Intent
            java.lang.String r2 = "android.settings.CAST_SETTINGS"
            r1.<init>(r2)
            r4.startActivityForResult(r1, r5)
            java.lang.String r5 = "open WiFi display settings in other"
            android.util.Log.d(r0, r5)
            goto L_0x0096
        L_0x0080:
            boolean r5 = r4.checkPermission()
            if (r5 == 0) goto L_0x0093
            vocsy.google.ads.AllInOneAds r5 = vocsy.google.ads.AllInOneAds.getInstance()
            com.royalstatus.remote.control.universal.forall.tv.ChromeCastActivity$4 r0 = new com.royalstatus.remote.control.universal.forall.tv.ChromeCastActivity$4
            r0.<init>()
            r5.showInter(r4, r0)
            goto L_0x0096
        L_0x0093:
            r4.requestPermission()
        L_0x0096:
            return
        *//*
        throw new UnsupportedOperationException("Method not decompiled: com.royalstatus.remote.control.universal.forall.tv.ChromeCastActivity.onClick(android.view.View):void");
    }*/

    private boolean checkPermission() {
        return ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0 && ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") == 0;
    }

    private void requestPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            Toast.makeText(this, "Write External Storage permission allows us to do store images. Please allow this permission in App Settings.", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, 1);
        }
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 1) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                Log.e("value", "Permission Denied, You cannot use local drive .");
            } else {
                startActivity(new Intent(this, ImageListActivity.class));
            }
        }
    }


}
