package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;


public final  class ScreenMirroringActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final  ScreenMirroringActivity f$0;

    public  ScreenMirroringActivity$$ExternalSyntheticLambda0(ScreenMirroringActivity screenMirroringActivity) {
        this.f$0 = screenMirroringActivity;
    }

    public final void onClick(View view) {
        this.f$0.m28lambda$onCreate$0$comtwodgbmapphdvideoprojectorScreenMirroringActivity(view);
    }
}
