package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ActivityRemoteCompanyList$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ ActivityRemoteCompanyList f$0;

    public /* synthetic */ ActivityRemoteCompanyList$$ExternalSyntheticLambda0(ActivityRemoteCompanyList activityRemoteCompanyList) {
        this.f$0 = activityRemoteCompanyList;
    }

    public final void onClick(View view) {
        this.f$0.m34lambda$adsandnavigation$0$comtwodgbmapphdvideoprojectorpart3ActivityActivityRemoteCompanyList(view);
    }
}
