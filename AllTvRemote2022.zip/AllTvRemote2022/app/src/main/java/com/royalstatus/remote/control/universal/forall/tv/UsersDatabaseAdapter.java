package com.royalstatus.remote.control.universal.forall.tv;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.Model.HistoryMo;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.Model.UserModel;
import java.util.ArrayList;
import org.json.JSONException;

public class UsersDatabaseAdapter {
    static final String DATABASE_CREATE = "create table USERS( ID integer primary key autoincrement,user_name  text,user_phone  text,user_email text); ";
    static final String DATABASE_CREATEHIS = "create table HISTORY( ID integer primary key autoincrement,user_name  text,user_phone  text,user_email text); ";
    static final String DATABASE_NAME = "UsersDatabase.db";
    static final int DATABASE_VERSION = 1;
    static final String HISTORYTABLE_NAME = "HISTORY";
    static final String TABLE_NAME = "USERS";
    private static final String TAG = "UsersDatabaseAdapter:";
    public static SQLiteDatabase db;
    private static DataBaseHelper dbHelper;
    static ArrayList<UserModel> users = new ArrayList<>();
    static ArrayList<HistoryMo> usershius = new ArrayList<>();
    private final Context context;

    public UsersDatabaseAdapter(Context context2) {
        this.context = context2;
        dbHelper = new DataBaseHelper(context2, DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
    }

    public UsersDatabaseAdapter open() throws SQLException {
        db = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        db.close();
    }

    public SQLiteDatabase getDatabaseInstance() {
        return db;
    }

    public static String insertEntry(String str, String str2, String str3) {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("user_name", str);
            contentValues.put("user_phone", str2);
            contentValues.put("user_email", str3);
            SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
            db = writableDatabase;
            Log.i("Row Insert Result ", String.valueOf(writableDatabase.insert(TABLE_NAME, (String) null, contentValues)));
            db.close();
        } catch (Exception unused) {
        }
        return "ok";
    }

    public static String inserthistoryEntry(String str, String str2, String str3) {
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("user_name", str);
            contentValues.put("user_phone", str2);
            contentValues.put("user_email", str3);
            SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
            db = writableDatabase;
            Log.i("Row Insert Result ", String.valueOf(writableDatabase.insert(HISTORYTABLE_NAME, (String) null, contentValues)));
            db.close();
        } catch (Exception unused) {
        }
        return "ok";
    }

    public static ArrayList<HistoryMo> getHisRows() throws JSONException {
        usershius.clear();
        SQLiteDatabase readableDatabase = dbHelper.getReadableDatabase();
        db = readableDatabase;
        Cursor query = readableDatabase.query(HISTORYTABLE_NAME, (String[]) null, (String) null, (String[]) null, (String) null, (String) null, (String) null, (String) null);
        while (query.moveToNext()) {
            HistoryMo historyMo = new HistoryMo();
            historyMo.setID(query.getString(query.getColumnIndex("ID")));
            historyMo.setUsername(query.getString(query.getColumnIndex("user_name")));
            historyMo.setUserphone(query.getString(query.getColumnIndex("user_phone")));
            historyMo.setUseremail(query.getString(query.getColumnIndex("user_email")));
            usershius.add(historyMo);
        }
        query.close();
        return usershius;
    }

    public static ArrayList<UserModel> getRows() throws JSONException {
        users.clear();
        SQLiteDatabase readableDatabase = dbHelper.getReadableDatabase();
        db = readableDatabase;
        Cursor query = readableDatabase.query(TABLE_NAME, (String[]) null, (String) null, (String[]) null, (String) null, (String) null, (String) null, (String) null);
        while (query.moveToNext()) {
            UserModel userModel = new UserModel();
            userModel.setID(query.getString(query.getColumnIndex("ID")));
            userModel.setUsername(query.getString(query.getColumnIndex("user_name")));
            userModel.setUserphone(query.getString(query.getColumnIndex("user_phone")));
            userModel.setUseremail(query.getString(query.getColumnIndex("user_email")));
            users.add(userModel);
        }
        query.close();
        return users;
    }

    public static int deleteEntry(String str) {
        return db.delete(TABLE_NAME, "ID=?", new String[]{str});
    }

    public static int deletehisEntry(String str) {
        return db.delete(HISTORYTABLE_NAME, "ID=?", new String[]{str});
    }

    public static int getRowCount() {
        SQLiteDatabase readableDatabase = dbHelper.getReadableDatabase();
        db = readableDatabase;
        Cursor query = readableDatabase.query(TABLE_NAME, (String[]) null, (String) null, (String[]) null, (String) null, (String) null, (String) null);
        db.close();
        return query.getCount();
    }

    public static void truncateTable() {
        SQLiteDatabase readableDatabase = dbHelper.getReadableDatabase();
        db = readableDatabase;
        readableDatabase.delete(TABLE_NAME, "1", (String[]) null);
        db.close();
    }

    public static void truncatehisTable() {
        SQLiteDatabase readableDatabase = dbHelper.getReadableDatabase();
        db = readableDatabase;
        readableDatabase.delete(HISTORYTABLE_NAME, "1", (String[]) null);
        db.close();
    }

    public static void updateEntry(String str, String str2, String str3, String str4) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("user_name", str2);
        contentValues.put("user_phone", str3);
        contentValues.put("user_email", str4);
        SQLiteDatabase readableDatabase = dbHelper.getReadableDatabase();
        db = readableDatabase;
        readableDatabase.update(TABLE_NAME, contentValues, "ID = ?", new String[]{str});
        db.close();
    }
}
