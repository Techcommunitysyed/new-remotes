package com.royalstatus.remote.control.universal.forall.tv;

public class Forecast {
    private final String cityName;

    public Forecast(String str) {
        this.cityName = str;
    }

    public String getCityName() {
        return this.cityName;
    }
}
