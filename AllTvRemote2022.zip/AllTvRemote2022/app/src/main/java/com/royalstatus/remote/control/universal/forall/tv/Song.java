package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Parcel;
import android.os.Parcelable;

public class Song implements Parcelable {
    public static final Creator<Song> CREATOR = new Creator<Song>() {
        public Song createFromParcel(Parcel parcel) {
            return new Song(parcel);
        }

        public Song[] newArray(int i) {
            return new Song[i];
        }
    };
    public static final Song EMPTY_SONG = new Song(-1, "", -1, -1, -1, "", -1, -1, "", -1, "");
    public final int albumId;
    public final String albumName;
    public final int artistId;
    public final String artistName;
    public final String data;
    public final long dateModified;
    public final long duration;
    public final int id;
    public final String title;
    public final int trackNumber;
    public final int year;

    public int describeContents() {
        return 0;
    }

    public Song(int i, String str, int i2, int i3, long j, String str2, long j2, int i4, String str3, int i5, String str4) {
        this.id = i;
        this.title = str;
        this.trackNumber = i2;
        this.year = i3;
        this.duration = j;
        this.data = str2;
        this.dateModified = j2;
        this.albumId = i4;
        this.albumName = str3;
        this.artistId = i5;
        this.artistName = str4;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Song song = (Song) obj;
        if (this.id != song.id || this.trackNumber != song.trackNumber || this.year != song.year || this.duration != song.duration || this.dateModified != song.dateModified || this.albumId != song.albumId || this.artistId != song.artistId) {
            return false;
        }
        String str = this.title;
        if (str == null ? song.title != null : !str.equals(song.title)) {
            return false;
        }
        String str2 = this.data;
        if (str2 == null ? song.data != null : !str2.equals(song.data)) {
            return false;
        }
        String str3 = this.albumName;
        if (str3 == null ? song.albumName != null : !str3.equals(song.albumName)) {
            return false;
        }
        String str4 = this.artistName;
        String str5 = song.artistName;
        if (str4 != null) {
            return str4.equals(str5);
        }
        if (str5 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        int i = this.id * 31;
        String str = this.title;
        int i2 = 0;
        int hashCode = str != null ? str.hashCode() : 0;
        long j = this.duration;
        int i3 = (((((((i + hashCode) * 31) + this.trackNumber) * 31) + this.year) * 31) + ((int) (j ^ (j >>> 32)))) * 31;
        String str2 = this.data;
        int hashCode2 = str2 != null ? str2.hashCode() : 0;
        long j2 = this.dateModified;
        int i4 = (((((i3 + hashCode2) * 31) + ((int) (j2 ^ (j2 >>> 32)))) * 31) + this.albumId) * 31;
        String str3 = this.albumName;
        int hashCode3 = (((i4 + (str3 != null ? str3.hashCode() : 0)) * 31) + this.artistId) * 31;
        String str4 = this.artistName;
        if (str4 != null) {
            i2 = str4.hashCode();
        }
        return hashCode3 + i2;
    }

    public String toString() {
        return "Song{id=" + this.id + ", title='" + this.title + '\'' + ", trackNumber=" + this.trackNumber + ", year=" + this.year + ", duration=" + this.duration + ", data='" + this.data + '\'' + ", dateModified=" + this.dateModified + ", albumId=" + this.albumId + ", albumName='" + this.albumName + '\'' + ", artistId=" + this.artistId + ", artistName='" + this.artistName + '\'' + '}';
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.id);
        parcel.writeString(this.title);
        parcel.writeInt(this.trackNumber);
        parcel.writeInt(this.year);
        parcel.writeLong(this.duration);
        parcel.writeString(this.data);
        parcel.writeLong(this.dateModified);
        parcel.writeInt(this.albumId);
        parcel.writeString(this.albumName);
        parcel.writeInt(this.artistId);
        parcel.writeString(this.artistName);
    }

    protected Song(Parcel parcel) {
        this.id = parcel.readInt();
        this.title = parcel.readString();
        this.trackNumber = parcel.readInt();
        this.year = parcel.readInt();
        this.duration = parcel.readLong();
        this.data = parcel.readString();
        this.dateModified = parcel.readLong();
        this.albumId = parcel.readInt();
        this.albumName = parcel.readString();
        this.artistId = parcel.readInt();
        this.artistName = parcel.readString();
    }
}
