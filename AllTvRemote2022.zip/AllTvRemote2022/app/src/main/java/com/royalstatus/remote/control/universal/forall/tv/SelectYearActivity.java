package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.aigestudio.wheelpicker.WheelPicker;
//import com.two.dgbmapp.hdvideoprojector.ForecastAdapter;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
import com.yarolegovich.discretescrollview.DiscreteScrollView;
import com.yarolegovich.discretescrollview.transform.ScaleTransformer;
import java.util.ArrayList;
import java.util.List;


public class SelectYearActivity extends AppCompatActivity implements DiscreteScrollView.ScrollStateChangeListener<ForecastAdapter.ViewHolder>, DiscreteScrollView.OnItemChangedListener<ForecastAdapter.ViewHolder>, View.OnClickListener {
    private DiscreteScrollView cityPicker;
    private List<Forecast> forecasts;
    WheelPicker main_wheel_left;
    Button next;

    public void onScrollEnd(ForecastAdapter.ViewHolder viewHolder, int i) {
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_select_year);

        ((ImageView) findViewById(R.id.imgBack)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SelectYearActivity.this.onBackPressed();
            }
        });
        Button button = (Button) findViewById(R.id.next);
        this.next = button;
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SelectYearActivity.this.startActivity(new Intent(SelectYearActivity.this.getApplicationContext(), ProgressActivity.class));

            }
        });
        ArrayList arrayList = new ArrayList();
        arrayList.add("2001-2005");
        arrayList.add("2006-2010");
        arrayList.add("2011-2015");
        arrayList.add("2016-2020");
        arrayList.add("2021-2025");
        WheelPicker wheelPicker = (WheelPicker) findViewById(R.id.main_wheel_left);
        this.main_wheel_left = wheelPicker;
        wheelPicker.setData(arrayList);
        this.main_wheel_left.setCurved(true);
        this.main_wheel_left.setCyclic(true);
        this.main_wheel_left.setItemTextSize(65);
        this.main_wheel_left.setSelectedItemTextColor(getResources().getColor(R.color.appBar));
        this.main_wheel_left.setOnItemSelectedListener(new WheelPicker.OnItemSelectedListener() {
            public void onItemSelected(WheelPicker wheelPicker, Object obj, int i) {
            }
        });
        this.forecasts = WeatherStation.get().getForecasts();
        DiscreteScrollView discreteScrollView = (DiscreteScrollView) findViewById(R.id.forecast_city_picker);
        this.cityPicker = discreteScrollView;
        discreteScrollView.setSlideOnFling(true);
        this.cityPicker.setAdapter(new ForecastAdapter(this, this.forecasts));
        this.cityPicker.addOnItemChangedListener(this);
        this.cityPicker.addScrollStateChangeListener(this);
        this.cityPicker.scrollToPosition(2);
        this.cityPicker.setItemTransformer(new ScaleTransformer.Builder().setMinScale(0.8f).build());
    }

    public void onCurrentItemChanged(ForecastAdapter.ViewHolder viewHolder, int i) {
        if (viewHolder != null) {
            viewHolder.showText();
        }
    }

    public void onScrollStart(ForecastAdapter.ViewHolder viewHolder, int i) {
        viewHolder.hideText();
    }

    public void onScroll(float f, int i, int i2, ForecastAdapter.ViewHolder viewHolder, ForecastAdapter.ViewHolder viewHolder2) {
        this.forecasts.get(i);
        RecyclerView.Adapter adapter = this.cityPicker.getAdapter();
        int itemCount = adapter != null ? adapter.getItemCount() : 0;
        if (i2 >= 0 && i2 < itemCount) {
            this.forecasts.get(i2);
        }
    }

    public void onClick(View view) {
        if (view.getId() == R.id.home) {
            finish();
        }
    }

    public void onBackPressed() {
      finish();
    }
}
