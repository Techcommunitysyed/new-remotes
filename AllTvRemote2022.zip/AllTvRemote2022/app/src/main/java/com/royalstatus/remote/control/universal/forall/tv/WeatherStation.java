package com.royalstatus.remote.control.universal.forall.tv;

import java.util.Arrays;
import java.util.List;

public class WeatherStation {
    public static WeatherStation get() {
        return new WeatherStation();
    }

    private WeatherStation() {
    }

    public List<Forecast> getForecasts() {
        return Arrays.asList(new Forecast[]{new Forecast("2001 - 2005"), new Forecast("2006 - 2010"), new Forecast("2011 - 2015"), new Forecast("2016 - 2020"), new Forecast("2021 - 2025")});
    }
}
