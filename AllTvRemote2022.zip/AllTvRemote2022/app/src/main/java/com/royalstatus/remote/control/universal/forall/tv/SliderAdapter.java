package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.smarteist.autoimageslider.SliderViewAdapter;
import java.util.ArrayList;
import java.util.List;

public class SliderAdapter extends SliderViewAdapter<SliderAdapter.SliderAdapterViewHolder> {
    private final List<SliderData> mSliderItems;

    public SliderAdapter(Context context, ArrayList<SliderData> arrayList) {
        this.mSliderItems = arrayList;
    }

    public SliderAdapterViewHolder onCreateViewHolder(ViewGroup viewGroup) {
        return new SliderAdapterViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.slider_layout, (ViewGroup) null));
    }

    public void onBindViewHolder(SliderAdapterViewHolder sliderAdapterViewHolder, int i) {
        ((RequestBuilder) Glide.with(sliderAdapterViewHolder.itemView).load(this.mSliderItems.get(i).getImgUrl()).fitCenter()).into(sliderAdapterViewHolder.imageViewBackground);
    }

    public int getCount() {
        return this.mSliderItems.size();
    }

    static class SliderAdapterViewHolder extends ViewHolder {
        ImageView imageViewBackground;
        View itemView;

        public SliderAdapterViewHolder(View view) {
            super(view);
            this.imageViewBackground = (ImageView) view.findViewById(R.id.myimage);
            this.itemView = view;
        }
    }
}
