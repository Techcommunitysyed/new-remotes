package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import androidx.constraintlayout.core.motion.utils.TypedValues;
//import com.facebook.appevents.internal.ViewHierarchyConstants;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.AUDIO_MODEL;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.FOLDER_MODEL;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.MODEL_GALLERY_ALBUM_MODEL;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.MODEL_GALLERY_PHOTO_MODEL;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.VIDEO_MODEL;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class GetMedia {
    public static String mainFolder = "MxVideoPlayer";
    public static String parentFolder = ".mx_private";
    Context context;

    public GetMedia(Context context2) {
        this.context = context2;
    }

    public ArrayList<FOLDER_MODEL> getfolderList() {
        Cursor query = this.context.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, new String[]{"bucket_id"}, (String) null, (String[]) null, (String) null);
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        linkedHashSet.clear();
        while (query.moveToNext()) {
            linkedHashSet.add(query.getString(0));
        }
        ArrayList arrayList = new ArrayList(linkedHashSet);
        String[] strArr = {"bucket_display_name", "_data", "bucket_id", "date_modified", "_size"};
        ArrayList<FOLDER_MODEL> arrayList2 = new ArrayList<>();
        arrayList2.clear();
        for (int i = 0; i < arrayList.size(); i++) {
            Cursor query2 = this.context.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, strArr, "bucket_id =?", new String[]{(String) arrayList.get(i)}, "date_modified DESC");
            if (query2.moveToNext()) {
                FOLDER_MODEL folder_model = new FOLDER_MODEL();
                folder_model.setBucket(query2.getString(0));
                folder_model.setData(query2.getString(1));
                folder_model.setBid(query2.getString(2));
                folder_model.setVideoCount(String.valueOf(query2.getCount()));
                folder_model.setDate(folderDate(query2.getString(3)));
                folder_model.setSize(size(query2.getString(4)));
                Log.e("folder_path", "path: " + query2.getString(1));
                arrayList2.add(folder_model);
            }
        }
        return arrayList2;
    }

    public List<VIDEO_MODEL> getVideoByFolder(String str) {
        String[] strArr = {"_id", "title", "_display_name", "_data", "date_modified", TypedValues.TransitionType.S_DURATION, "resolution", "_size"};
        Cursor query = this.context.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, strArr, "bucket_id =?", new String[]{str}, "date_modified DESC");
        ArrayList arrayList = new ArrayList();
        arrayList.clear();
        while (query.moveToNext()) {
            VIDEO_MODEL video_model = new VIDEO_MODEL();
            video_model.setId(query.getString(0));
            video_model.setTitle(query.getString(1));
            video_model.setDisplayName(query.getString(2));
            video_model.setData(query.getString(3));
            video_model.setDate(videoDate(query.getString(4)));
            video_model.setDuartion(duration(query.getString(5)));
            video_model.setResolution(query.getString(6));
            video_model.setSize(size(query.getString(7)));
            Log.e("folder_path", "path: " + query.getString(3));
            arrayList.add(video_model);
        }
        return arrayList;
    }

    public List<AUDIO_MODEL> getAllMusic() {
        ArrayList arrayList = new ArrayList();
        Cursor query = this.context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, new String[]{"_data", "album", "artist"}, (String) null, (String[]) null, (String) null);
        if (query != null) {
            while (query.moveToNext()) {
                AUDIO_MODEL audio_model = new AUDIO_MODEL();
                String string = query.getString(0);
                String string2 = query.getString(1);
                String string3 = query.getString(2);
                audio_model.setaName(string.substring(string.lastIndexOf("/") + 1));
                audio_model.setaAlbum(string2);
                audio_model.setaArtist(string3);
                audio_model.setaPath(string);
                arrayList.add(audio_model);
            }
            query.close();
        }
        return arrayList;
    }

    public List<MODEL_GALLERY_ALBUM_MODEL> getImageFolder(Activity activity) {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        arrayList.clear();
        arrayList2.clear();
        Cursor query = activity.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{"bucket_display_name", "_data", "_id"}, (String) null, (String[]) null, (String) null);
        if (query != null && query.getCount() > 0) {
            if (query.moveToFirst()) {
                int columnIndex = query.getColumnIndex("bucket_display_name");
                int columnIndex2 = query.getColumnIndex("_data");
                int columnIndex3 = query.getColumnIndex("_id");
                do {
                    String string = query.getString(columnIndex);
                    String string2 = query.getString(columnIndex2);
                    String string3 = query.getString(columnIndex3);
                    MODEL_GALLERY_PHOTO_MODEL model_gallery_photo_model = new MODEL_GALLERY_PHOTO_MODEL();
                    model_gallery_photo_model.setAlbumName(string);
                    model_gallery_photo_model.setPhotoUri(string2);
                    model_gallery_photo_model.setId(Integer.valueOf(string3).intValue());
                    if (arrayList2.contains(string)) {
                        Iterator it = arrayList.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                MODEL_GALLERY_ALBUM_MODEL model_gallery_album_model = (MODEL_GALLERY_ALBUM_MODEL) it.next();
                                if (model_gallery_album_model.getName().equals(string)) {
                                    model_gallery_album_model.getAlbumPhotos().add(model_gallery_photo_model);
                                    Log.i("DeviceImageManager", "A photo was added to album => " + string);
                                    break;
                                }
                            } else {
                                break;
                            }
                        }
                    } else {
                        MODEL_GALLERY_ALBUM_MODEL model_gallery_album_model2 = new MODEL_GALLERY_ALBUM_MODEL();
                        Log.i("DeviceImageManager", "A new album was created => " + string);
                        model_gallery_album_model2.setId(model_gallery_photo_model.getId());
                        model_gallery_album_model2.setName(string);
                        model_gallery_album_model2.setCoverUri(model_gallery_photo_model.getPhotoUri());
                        model_gallery_album_model2.getAlbumPhotos().add(model_gallery_photo_model);
                        Log.i("DeviceImageManager", "A photo was added to album => " + string);
                        arrayList.add(model_gallery_album_model2);
                        arrayList2.add(string);
                    }
                } while (query.moveToNext());
            }
            query.close();
        }
        return arrayList;
    }

    public static String duration(String str) {
        try {
            long parseInt = (long) Integer.parseInt(str);
            long hours = TimeUnit.MILLISECONDS.toHours(parseInt);
            long minutes = TimeUnit.MILLISECONDS.toMinutes(parseInt) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(parseInt));
            long seconds = TimeUnit.MILLISECONDS.toSeconds(parseInt) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(parseInt));
            if (hours >= 1) {
                return String.format("%02d:%02d:%02d", new Object[]{Long.valueOf(hours), Long.valueOf(minutes), Long.valueOf(seconds)});
            }
            return String.format("%02d:%02d", new Object[]{Long.valueOf(minutes), Long.valueOf(seconds)});
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private String folderDate(String str) {
        return new SimpleDateFormat("yyyy-MMM-dd").format(new Date(Long.parseLong(str) * 1000));
    }

    private String videoDate(String str) {
        return new SimpleDateFormat("dd MMM").format(new Date(Long.parseLong(str) * 1000));
    }

    private String size(String str) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        decimalFormat.setRoundingMode(RoundingMode.FLOOR);
        double parseDouble = Double.parseDouble(str) / 1024.0d;
        if (parseDouble < 1024.0d) {
            return decimalFormat.format(parseDouble) + " KB";
        }
        double d = parseDouble / 1024.0d;
        if (d < 1024.0d) {
            return decimalFormat.format(d) + " MB";
        }
        return decimalFormat.format(d / 1024.0d) + " GB";
    }

    public static String detailVideoDate(String str) {
        return new SimpleDateFormat("dd MMM yyyy, HH:mm a").format(new Date(Long.parseLong(str) * 1000));
    }

    public static void shareVideo(final Context context2, String str, String str2) {
        try {
            MediaScannerConnection.scanFile(context2, new String[]{str2}, (String[]) null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String str, Uri uri) {
                    Intent intent = new Intent("android.intent.action.SEND");
                    intent.setType("video/*");
                    intent.putExtra("android.intent.extra.SUBJECT", str);
                    intent.putExtra("android.intent.extra.STREAM", uri);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    context2.startActivity(Intent.createChooser(intent, "share via:"));
                }
            });
        } catch (Exception unused) {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("video/*");
            intent.putExtra("android.intent.extra.SUBJECT", str);
            intent.putExtra("android.intent.extra.STREAM", Uri.parse(str2));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context2.startActivity(Intent.createChooser(intent, "share via:"));
        }
    }

    public static void moveToPrivate(Context context2, String str, String str2) {
        try {
            File file = new File(Environment.getExternalStorageDirectory() + "/" + parentFolder);
            if (!file.mkdirs()) {
                file.mkdirs();
            }
            FileInputStream fileInputStream = new FileInputStream(str);
            FileOutputStream fileOutputStream = new FileOutputStream(Environment.getExternalStorageDirectory() + "/" + parentFolder + "/" + str2);
            MediaScannerConnection.scanFile(context2, new String[]{Environment.getExternalStorageDirectory() + "/" + parentFolder + "/" + str2}, (String[]) null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String str, Uri uri) {
                }
            });
            byte[] bArr = new byte[1024];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read != -1) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    fileInputStream.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    new File(str).delete();
                    return;
                }
            }
        } catch (FileNotFoundException e) {
//            Log.e(ViewHierarchyConstants.TAG_KEY, e.getMessage());
        } catch (Exception e2) {
//            Log.e(ViewHierarchyConstants.TAG_KEY, e2.getMessage());
        }
    }

    public static void reMoveToPrivate(Context context2, String str, String str2) {
        try {
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), mainFolder);
            if (!file.mkdirs()) {
                file.mkdirs();
            }
            FileInputStream fileInputStream = new FileInputStream(str);
            FileOutputStream fileOutputStream = new FileOutputStream(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/" + mainFolder + "/" + str2);
            MediaScannerConnection.scanFile(context2, new String[]{Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/" + mainFolder + "/" + str2}, (String[]) null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String str, Uri uri) {
                }
            });
            byte[] bArr = new byte[1024];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read != -1) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    fileInputStream.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    new File(str).delete();
                    return;
                }
            }
        } catch (FileNotFoundException e) {
//            Log.e(ViewHierarchyConstants.TAG_KEY, e.getMessage());
        } catch (Exception e2) {
//            Log.e(ViewHierarchyConstants.TAG_KEY, e2.getMessage());
        }
    }

    public static void copyFile(Context context2, String str, String str2) {
        try {
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/" + mainFolder + "/Status Saver");
            if (!file.mkdirs()) {
                file.mkdirs();
            }
            FileInputStream fileInputStream = new FileInputStream(str);
            FileOutputStream fileOutputStream = new FileOutputStream(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/" + mainFolder + "/Status Saver/" + str2);
            MediaScannerConnection.scanFile(context2, new String[]{Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + "/" + mainFolder + "/Status Saver/" + str2}, (String[]) null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String str, Uri uri) {
                }
            });
            byte[] bArr = new byte[1024];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read != -1) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    fileInputStream.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    return;
                }
            }
        } catch (FileNotFoundException e) {
//            Log.e(ViewHierarchyConstants.TAG_KEY, e.getMessage());
        } catch (Exception e2) {
//            Log.e(ViewHierarchyConstants.TAG_KEY, e2.getMessage());
        }
    }
}
