package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.Model.HistoryMo;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.UsersDatabaseAdapter;
//import java.util.ArrayList;

public class HistoryCustomListAdapterDeleteRows extends BaseAdapter {
    Context co;
    HistoryMo user;
    ArrayList<HistoryMo> users;

    /* access modifiers changed from: private */
    public void next() {
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public HistoryCustomListAdapterDeleteRows(Context context, ArrayList<HistoryMo> arrayList) {
        this.co = context;
        this.users = arrayList;
    }

    public int getCount() {
        return this.users.size();
    }

    public Object getItem(int i) {
        return this.users.get(i);
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(this.co).inflate(R.layout.listviewdelete_row, viewGroup, false);
        }
        HistoryMo historyMo = (HistoryMo) getItem(i);
        this.user = historyMo;
        ((TextView) view.findViewById(R.id.textView1)).setText(historyMo.getUsername());
        ((ImageView) view.findViewById(R.id.button1)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                UsersDatabaseAdapter.deletehisEntry(HistoryCustomListAdapterDeleteRows.this.user.getID());
                HistoryCustomListAdapterDeleteRows.this.users.remove(i);
                HistoryCustomListAdapterDeleteRows.this.notifyDataSetChanged();
            }
        });
        ((RelativeLayout) view.findViewById(R.id.rel)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                HistoryCustomListAdapterDeleteRows.this.next();
            }
        });
        return view;
    }
}
