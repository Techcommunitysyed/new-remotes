package com.royalstatus.remote.control.universal.forall.tv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.google.android.material.bottomsheet.BottomSheetDialog;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Activity.VIDEO_PLAYER_ACTIVITY;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.VIDEO_MODEL;
//import com.two.dgbmapp.hdvideoprojector.part2.Utils.GetMedia;
//import com.two.dgbmapp.hdvideoprojector.part2.Utils.VideoDetailsDialog;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
import java.io.File;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class VIDEO_ADAPTER extends RecyclerView.Adapter<VIDEO_ADAPTER.MyFolder> {
    Activity activity;
    Context context;
    LinearLayout llAddPlaylist;
    LinearLayout llDelete;
    LinearLayout llLockVideo;
    LinearLayout llMxSearchSub;
    LinearLayout llMxShare;
    LinearLayout llProperties;
    LinearLayout llRename;
    LinearLayout llShare;
    List<VIDEO_MODEL> modelList;
    TextView tvTitle;

    public VIDEO_ADAPTER(Context context2, Activity activity2, List<VIDEO_MODEL> list) {
        this.context = context2;
        this.modelList = list;
        this.activity = activity2;
    }

    public MyFolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyFolder(LayoutInflater.from(this.context).inflate(R.layout.item_video_list, viewGroup, false));
    }

    public void onBindViewHolder(MyFolder myFolder, @SuppressLint("RecyclerView") final int i) {
        final VIDEO_MODEL video_model = this.modelList.get(i);
        ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load(new File(video_model.getData())).centerCrop()).placeholder(R.color.white)).into(myFolder.ivThumbnail);
        myFolder.tvName.setText(video_model.getTitle());
        myFolder.tvDuration.setText(video_model.getDuartion());
        myFolder.tvDate.setText(video_model.getDate());
        myFolder.tvSize.setText(video_model.getSize());
        myFolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(VIDEO_ADAPTER.this.context, VIDEO_PLAYER_ACTIVITY.class);
                intent.putExtra("list", (Serializable) VIDEO_ADAPTER.this.modelList);
                intent.putExtra("position", i);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                VIDEO_ADAPTER.this.context.startActivity(intent);
            }
        });
        myFolder.ivMore.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                VIDEO_ADAPTER video_adapter = VIDEO_ADAPTER.this;
                video_adapter.videoDetails(video_adapter.context, video_model, i);
            }
        });
    }

    public int getItemCount() {
        return this.modelList.size();
    }

    public class MyFolder extends RecyclerView.ViewHolder {
        ImageView ivMore;
        ImageView ivThumbnail;
        TextView tvDate;
        TextView tvDuration;
        TextView tvName;
        TextView tvSize;

        public MyFolder(View view) {
            super(view);
            this.ivThumbnail = (ImageView) view.findViewById(R.id.ivThumbnail);
            this.ivMore = (ImageView) view.findViewById(R.id.ivMore);
            this.tvName = (TextView) view.findViewById(R.id.tvName);
            this.tvDuration = (TextView) view.findViewById(R.id.tvDuration);
            this.tvDate = (TextView) view.findViewById(R.id.tvDate);
            this.tvSize = (TextView) view.findViewById(R.id.tvSize);
        }
    }

    /* access modifiers changed from: private */
    public void videoDetails(final Context context2, final VIDEO_MODEL video_model, int i) {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context2, R.style.BottomSheetDialog);
        bottomSheetDialog.requestWindowFeature(1);
        bottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        bottomSheetDialog.setCancelable(true);
        bottomSheetDialog.setContentView(R.layout.dialog_video_option);
        getId(bottomSheetDialog);
        this.tvTitle.setText(video_model.getTitle());
        this.llShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                GetMedia.shareVideo(context2, video_model.getDisplayName(), video_model.getData());
                bottomSheetDialog.dismiss();
            }
        });
        this.llProperties.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                VideoDetailsDialog.show(context2, video_model);
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.getWindow().setLayout(-1, -2);
        bottomSheetDialog.show();
    }

    private void getId(BottomSheetDialog bottomSheetDialog) {
        this.tvTitle = (TextView) bottomSheetDialog.findViewById(R.id.tvTitle);
        this.llShare = (LinearLayout) bottomSheetDialog.findViewById(R.id.llShare);
        this.llProperties = (LinearLayout) bottomSheetDialog.findViewById(R.id.llProperties);
    }

    private String videoDate(String str) {
        return new SimpleDateFormat("dd MMM").format(new Date(Long.parseLong(str) * 1000));
    }
}
