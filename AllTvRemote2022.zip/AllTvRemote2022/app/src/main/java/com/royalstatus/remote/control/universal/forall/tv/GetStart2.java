package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.androidstudy.networkmanager.Monitor;
import com.androidstudy.networkmanager.Tovuti;


public class GetStart2 extends AppCompatActivity {
    LinearLayout startapp;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_get_start2);
        Tovuti.from(this).monitor(new Monitor.ConnectivityListener() {
            public void onConnectivityChanged(int i, boolean z, boolean z2) {
                if (!z) {
                    Toast.makeText(GetStart2.this, "Internet Connection lost.", Toast.LENGTH_SHORT).show();
                    GetStart2.this.startActivity(new Intent(GetStart2.this, InternetNotAvailableActivity.class));
                }
            }
        });

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.start);
        this.startapp = linearLayout;
        linearLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                GetStart2.this.startActivity(new Intent(GetStart2.this, MainActivity.class));

            }
        });
    }

    public void onBackPressed() {
        GetStart2.this.startActivity(new Intent(GetStart2.this, StartActivity.class));

    }
}
