package com.royalstatus.remote.control.universal.forall.tv;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import androidx.appcompat.app.AppCompatActivity;
//import com.facebook.internal.logging.monitor.MonitorLogServerProtocol;
import com.royalstatus.remote.control.universal.forall.tv.databinding.ActivityRemoteControllerBinding;

public class RemoteControllerActivity extends AppCompatActivity implements View.OnClickListener {
    ActivityRemoteControllerBinding binding;
    String category;
    String final_remote;
    Database helper;
    private boolean isdirect;
    /* access modifiers changed from: private */
    public Animation slide_down;
    private Animation slide_up;
    /* access modifiers changed from: private */
    public Vibrator vibrator;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        ActivityRemoteControllerBinding inflate = ActivityRemoteControllerBinding.inflate(getLayoutInflater());
        binding = inflate;
        setContentView((View) inflate.getRoot());
        helper = new Database(this);
        isdirect = getIntent().getBooleanExtra("isdirect", false);
        final_remote = getIntent().getStringExtra("final_remote");
        if (isdirect) {
          //  String stringExtra = getIntent().getStringExtra(MonitorLogServerProtocol.PARAM_CATEGORY);
            String stringExtra = getIntent().getStringExtra(null);

            category = stringExtra;
            helper.insert_remote(final_remote, stringExtra);
        }
        slide_up = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_up);
        slide_down = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_down);
        binding.remoteName.setText(final_remote);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        binding.backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
              finish();
            }
        });
        binding.plugBtn.setOnClickListener(this);
        binding.homeBtn.setOnClickListener(this);
        binding.menuBtn.setOnClickListener(this);
        binding.soundBtn.setOnClickListener(this);
        binding.volPluseBtn.setOnClickListener(this);
        binding.volMiseBtn.setOnClickListener(this);
        binding.moerBtn.setOnClickListener(this);
        binding.keybordBtn.setOnClickListener(this);
        binding.chPluseBtn.setOnClickListener(this);
        binding.chMiseBtn.setOnClickListener(this);
        binding.btnLeft.setOnClickListener(this);
        binding.btnRight.setOnClickListener(this);
        binding.btnUp.setOnClickListener(this);
        binding.btnDown.setOnClickListener(this);
        binding.okBtn.setOnClickListener(this);
        binding.ivBackBtn.setOnClickListener(this);
        binding.powerBtn.setOnClickListener(this);
        binding.num0Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.num1Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.num2Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.num3Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.num4Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.num5Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.num6Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.num7Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.num8Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.num9Btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            public void onClick(View view) {
              vibrator.vibrate(150);
            }
        });
        binding.backBtn.setOnClickListener(new RemoteControllerActivity$$ExternalSyntheticLambda0(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$0$com-two-dgbmapp-hdvideoprojector-part3-Activity-RemoteControllerActivity  reason: not valid java name */
    public /* synthetic */ void m37lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart3ActivityRemoteControllerActivity(View view) {
        onBackPressed();
    }

    @SuppressLint("MissingPermission")
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.btn_down) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.btn_left) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.btn_right) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.btn_up) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.ch_mise_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.ch_pluse_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.home_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.iv_back_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.keybord_btn) {
            invisible();
            vibrator.vibrate(150);
            binding.numberkeypad.startAnimation(slide_up);
            binding.numberkeypad.setVisibility(View.VISIBLE);
        } else if (id == R.id.menu_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.moer_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.ok_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.plug_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.power_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.sound_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.vol_mise_btn) {
            invisible();
            vibrator.vibrate(150);
        } else if (id == R.id.vol_pluse_btn) {
            invisible();
            vibrator.vibrate(150);
        }
    }

    public void invisible() {
        if (binding.numberkeypad.getVisibility() == View.VISIBLE) {
            binding.numberkeypad.startAnimation(slide_down);
            binding.numberkeypad.setVisibility(View.GONE);
        }
    }

    public void onBackPressed() {
        if (binding.numberkeypad.getVisibility() == View.VISIBLE) {
          binding.numberkeypad.startAnimation(slide_down);
          binding.numberkeypad.setVisibility(View.GONE);
            return;
        }
      finish();
    }
}
