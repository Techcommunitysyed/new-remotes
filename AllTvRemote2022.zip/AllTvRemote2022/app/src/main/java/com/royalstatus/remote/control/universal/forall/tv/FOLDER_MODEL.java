package com.royalstatus.remote.control.universal.forall.tv;

import java.util.Comparator;
import java.util.concurrent.TimeUnit;

public class FOLDER_MODEL {
    public static Comparator<FOLDER_MODEL> sort_name = new Comparator<FOLDER_MODEL>() {
        public int compare(FOLDER_MODEL folder_model, FOLDER_MODEL folder_model2) {
            return folder_model.getBucket().compareTo(folder_model2.getBucket());
        }
    };
    public static Comparator<FOLDER_MODEL> sort_size = new Comparator<FOLDER_MODEL>() {
        public int compare(FOLDER_MODEL folder_model, FOLDER_MODEL folder_model2) {
            return folder_model.getSize().compareTo(folder_model2.getSize());
        }
    };
    String bid;
    String bucket;
    String data;
    String date;
    String size;
    String videoCount;

    public String getBid() {
        return this.bid;
    }

    public void setBid(String str) {
        this.bid = str;
    }

    public String getBucket() {
        return this.bucket;
    }

    public void setBucket(String str) {
        this.bucket = str;
    }

    public String getData() {
        return this.data;
    }

    public void setData(String str) {
        this.data = str;
    }

    public String getVideoCount() {
        return this.videoCount;
    }

    public void setVideoCount(String str) {
        this.videoCount = str;
    }

    public String getSize() {
        return this.size;
    }

    public void setSize(String str) {
        this.size = str;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String str) {
        this.date = str;
    }

    private static String duration(String str) {
        try {
            long parseInt = (long) Integer.parseInt(str);
            return String.format("%02d:%02d:%02d", new Object[]{Long.valueOf(TimeUnit.MILLISECONDS.toHours(parseInt)), Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(parseInt) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(parseInt))), Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(parseInt) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(parseInt)))});
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}
