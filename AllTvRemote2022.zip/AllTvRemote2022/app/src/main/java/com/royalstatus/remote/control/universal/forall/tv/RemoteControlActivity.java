package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class RemoteControlActivity extends AppCompatActivity {
    private String DeviceName;
    private ImageView imgBack;
    private TextView textAlert;
    private TextView textAppName;
    private TextView textTVBrand;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_remote_control);
        this.DeviceName = getIntent().hasExtra("itemName") ? getIntent().getStringExtra("itemName") : "";
        initViews();
    }

    private void initViews() {
        ImageView imageView = (ImageView) findViewById(R.id.imgBack);
        this.imgBack = imageView;
        imageView.setOnClickListener(new RemoteControlActivity$$ExternalSyntheticLambda0(this));
        TextView textView = (TextView) findViewById(R.id.textAppName);
        this.textAppName = textView;
        textView.setText(this.DeviceName);
        TextView textView2 = (TextView) findViewById(R.id.textTVBrand);
        this.textTVBrand = textView2;
        textView2.setText("Searching for " + this.DeviceName);
        TextView textView3 = (TextView) findViewById(R.id.textAlert);
        this.textAlert = textView3;
        textView3.setText("Please connect your " + this.DeviceName + " and your Mobile Phone to the same Wifi Network");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$initViews$0$com-royalstatus-remote-control-universal-forall-tv-RemoteControlActivity  reason: not valid java name */
    public /* synthetic */ void m26lambda$initViews$0$comroyalstatusremotecontroluniversalforalltvRemoteControlActivity(View view) {
        onBackPressed();
    }

    public void onBackPressed() {
        RemoteControlActivity.this.finish();
    }
}
