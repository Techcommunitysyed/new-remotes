package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class RemoteMainActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ RemoteMainActivity f$0;

    public /* synthetic */ RemoteMainActivity$$ExternalSyntheticLambda0(RemoteMainActivity remoteMainActivity) {
        this.f$0 = remoteMainActivity;
    }

    public final void onClick(View view) {
        this.f$0.m38lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart3ActivityRemoteMainActivity(view);
    }
}
