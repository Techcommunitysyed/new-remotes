package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
//import com.two.dgbmapp.hdvideoprojector.part2.AllMedia;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.webbrowserfrag;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.newnativeads.NativeHelper;

public class ScreenMirroringOptionActivity extends AppCompatActivity {
    ImageView smoption_1;
    ImageView smoption_2;
    ImageView smoption_3;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_screen_mirroring_option);
        getWindow().setFlags(1024, 1024);
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ScreenMirroringOptionActivity.this.onBackPressed();
            }
        });
        adsandnavigation();
        check();
        findview();
        clickdata();
    }

    public void check() {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            requestStoragePermission();
        }
    }

    private void requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 0);
            Toast.makeText(this, "Permission needed to save status images and videos", Toast.LENGTH_SHORT).show();
            return;
        }
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 0);
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 0) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        } else if (iArr.length == 1 && iArr[0] == 0) {
            Toast.makeText(this, "Storage Permission Granted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Storage permission required\nto save status images & videos", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void clickdata() {
        this.smoption_1.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScreenMirroringOptionActivity.this.lambda$clickdata$0$ScreenMirroringOptionActivity(view);
            }
        });
        this.smoption_2.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScreenMirroringOptionActivity.this.lambda$clickdata$1$ScreenMirroringOptionActivity(view);
            }
        });
    }

    public void lambda$clickdata$0$ScreenMirroringOptionActivity(View view) {
        ScreenMirroringOptionActivity.this.startActivity(new Intent(ScreenMirroringOptionActivity.this, SelectTvModelActivity.class));

    }

    public void lambda$clickdata$1$ScreenMirroringOptionActivity(View view) {
        ScreenMirroringOptionActivity.this.startActivity(new Intent(ScreenMirroringOptionActivity.this, AllMedia.class));

    }

    public void lambda$clickdata$2$ScreenMirroringOptionActivity(View view) {
        ScreenMirroringOptionActivity.this.startActivity(new Intent(ScreenMirroringOptionActivity.this, webbrowserfrag.class));

    }

    private void findview() {
        this.smoption_1 = (ImageView) findViewById(R.id.smoption_1);
        this.smoption_2 = (ImageView) findViewById(R.id.smoption_2);
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
    }

    public void onBackPressed() {
        ScreenMirroringOptionActivity.this.finish();

    }
}
