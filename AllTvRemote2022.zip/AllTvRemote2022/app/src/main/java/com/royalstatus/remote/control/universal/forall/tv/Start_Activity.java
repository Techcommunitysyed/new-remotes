package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;


public class Start_Activity extends AppCompatActivity {
    ImageView drawer;
    DrawerLayout drawer_layout;
    NavigationView nav_view;
    ImageView privacy;
    ImageView rate;
    ImageView share;
    ImageView start_iv;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.act_start_drawer);
        getWindow().setFlags(1024, 1024);
        adsandnavigation();
        findview();
        clickdata();
    }

    private void clickdata() {
        this.start_iv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Start_Activity.isStoragePermissionGranted(Start_Activity.this, 100)) {
                    Start_Activity.this.startActivity(new Intent(Start_Activity.this, ScreenMirroringActivity.class));
                }
            }
        });
        this.share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Common.ShareApp(Start_Activity.this);
            }
        });
        this.rate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Common.rateUs(Start_Activity.this);
            }
        });
        this.privacy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Common.privacypolicy(Start_Activity.this);
            }
        });
    }

    public static boolean isStoragePermissionGranted(Context context, int i) {
        if (Build.VERSION.SDK_INT < 23 || context.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED || context.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        ActivityCompat.requestPermissions((Activity) context, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, i);
        return false;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (iArr.length > 0 && iArr[0] == 0 && i == 100) {
            startActivity(new Intent(this, ScreenMirroringActivity.class));
        } else {
            Toast.makeText(this, "Allow storage permissions", Toast.LENGTH_SHORT).show();
        }
    }

    private void findview() {
        this.start_iv = (ImageView) findViewById(R.id.start);
        this.share = (ImageView) findViewById(R.id.share);
        this.rate = (ImageView) findViewById(R.id.rate);
        this.privacy = (ImageView) findViewById(R.id.privacy);
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
        this.drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        this.nav_view = (NavigationView) findViewById(R.id.nav_view);
        ImageView imageView = (ImageView) findViewById(R.id.drawer);
        this.drawer = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Start_Activity.this.drawer_layout.openDrawer((int) GravityCompat.START);
            }
        });
        this.nav_view.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                int itemId = menuItem.getItemId();
                if (itemId == R.id.home) {
                    Start_Activity.this.drawer_layout.closeDrawer((int) GravityCompat.START);
                    Intent intent = new Intent(Start_Activity.this.getApplicationContext(), Start_Activity.class);
                    intent.putExtra("my_boolean_key", true);
                    Start_Activity.this.startActivity(intent);
                    Start_Activity.this.finish();
                } else if (itemId == R.id.rate) {
                    Common.rateUs(Start_Activity.this);
                } else if (itemId == R.id.share) {
                    Common.ShareApp(Start_Activity.this);
                } else if (itemId == R.id.privacy) {
                    Common.privacypolicy(Start_Activity.this);
                } else if (itemId == R.id.more) {
                    Start_Activity.this.startActivity(new Intent(Start_Activity.this, More_Activity.class));
                }
                Start_Activity.this.drawer_layout.closeDrawer((int) GravityCompat.START);
                return true;
            }
        });
    }

    public void onBackPressed() {
        if (this.drawer_layout.isDrawerOpen((int) GravityCompat.START)) {
            this.drawer_layout.closeDrawer((int) GravityCompat.START);
            return;
        }
//        startActivity(new Intent(this, Exit_Activity.class));
//        finish();
    }
}
