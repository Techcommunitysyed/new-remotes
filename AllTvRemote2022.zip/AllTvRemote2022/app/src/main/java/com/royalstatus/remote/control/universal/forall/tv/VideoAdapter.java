package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.MyViewHolder> {
    private Activity mActivity;
    /* access modifiers changed from: private */
    public VideoClickListener mVideoClickListener;
    private ArrayList<String> videoArrayList;

    interface VideoClickListener {
        void onVideoClick(int i);
    }

    public VideoAdapter(ArrayList<String> arrayList, Activity activity, VideoClickListener videoClickListener) {
        this.videoArrayList = arrayList;
        this.mActivity = activity;
        this.mVideoClickListener = videoClickListener;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_video, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
        Glide.with(this.mActivity).load(this.videoArrayList.get(i)).into(myViewHolder.imgItem);
        myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                VideoAdapter.this.mVideoClickListener.onVideoClick(i);
            }
        });
    }

    public int getItemCount() {
        return this.videoArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        /* access modifiers changed from: private */
        public ImageView imgItem;
        private ImageView imgPlay;

        public MyViewHolder(View view) {
            super(view);
            this.imgItem = (ImageView) view.findViewById(R.id.imgItem);
            this.imgPlay = (ImageView) view.findViewById(R.id.imgPlay);
        }
    }
}
