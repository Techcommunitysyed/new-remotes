package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class RemoteControllerActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ RemoteControllerActivity f$0;

    public /* synthetic */ RemoteControllerActivity$$ExternalSyntheticLambda0(RemoteControllerActivity remoteControllerActivity) {
        this.f$0 = remoteControllerActivity;
    }

    public final void onClick(View view) {
        this.f$0.m37lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart3ActivityRemoteControllerActivity(view);
    }
}
