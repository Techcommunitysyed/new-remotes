package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.exifinterface.media.ExifInterface;


import com.facebook.appevents.AppEventsConstants;
import com.google.android.exoplayer2.upstream.DefaultLoadErrorHandlingPolicy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class Constant {
    protected static final String BASE_SELECTION = "is_music=1 AND title != ''";
    public static String[] strArr = {"10moons", "888", "Acer", "ACL", "Acme Acoustic Solutions", "Adiologic", "Adier Admiral", "Advent", "Adventura", "AEG", "Affinity", "Aftron", "Agazi", "Aiko", "Alwa", "Akal Akasyatv", "Akiba", "Akura", "Alba", "Albatron", "Alkos", "Alleron", "Allorgan", "Alphascan Amol", "Ampro", "Amstrad", "Anam", "Andersson Anhua", "Anitech", "Ansonic", "Aolingpu", "Aolinpiya Apex", "Arcelik", "Archar ARIO", "ASA Asberg", "Astor", "ASUS ATC", "Atec", "Atvio", "Audio Dynamics", "Audiola", "Audiosonic Audiovox", "Auidovox", "Auviol", "Aveis Avol", "AWA", "Axen", "BTV", "Bahun Baihehua", "Baihua", "Baile", "Baofeng", "Bachuashi Basic Line", "BOU Bauhn", "Bour", "Baysonic", "BBK", "Bec Beijing", "Beko", "Bell & Howell Beng", "Bestwell", "Beuamark", "BGH", "Blaupunkt BOE", "Boigle", "Bose", "Broksonic", "Bush", "Calling Caixun", "Calix", "Calypso", "Camellia Canca", "Candle", "Carrefour Casio", "CCE", "Ceicus", "Celestial", "Collo", "Centrum", "Challenger", "Changfel Changfeng", "Changhong CHIMEI", "Chunlan", "CIL", "cimline", "Cineral", "CITIZEN Clatronic", "Clear Max", "CMX", "Coby", "Colby", "Colortyme", "Combitech", "6:45", "Concerto", "Condor", "Conia", "Conic", "Conrowa", "Contect", "Contex", "Craig", "Crown", "Curtis", "Curtis Mathes", "Cybercom Cybermaxx", "Cytron", "D-Smart Daewoo Dantax", "Dare", "Daytron", "De graat", "Decca", "Dell", "Denver Devant", "Dgm Diamond", "Diboss Dicksmith", "Dicon", "Dicra", "Digiquest Digistor", "Digital Labs", "Digital Lifestyle", "Digitec", "Digitex Dikom", "Dion", "Disney", "Dm Tech", "Dora", "Drtron Dua", "Dual", "Durabrand", "DVB", "Dynex Dyon", "E_Motion", "Eastkit", "Ecco", "Ekea", "Electa", "Electrograph", "Electron Electrophonic", "Element", "Elenborg", "Elite", "Emerson", "Emprex Envision", "Epson", "Esa", "Etec", "Euro Fool", "Euroline", "Evotel", "Excellent lana_si Favi", "Failu", " Felyan", "Fenner", "Ferguson", "Fidelty", "Finlandia", "Finlux", "Firstline", "Fisher", "Flint Fluid", "Formenti Fortress", "Foxconn", "Frigidaire", "Frontech", "Fujicom Fujimaru", "Fujitsu", "Full", "Funal", "Furi", "Furrion", "Fusion", "Futeck", "Futronic Gangtal", "Ganxin", "Gateway", "Ge", "Gec", "Goricom", "Godrej", "Goldmaster", "Goldstar", "Goodmans Gosonic", "Govideo Gpm", "GPX", "New", "Gradiente", "Gran Prix Granada", "Grandin", "Great wall", "Grundig", "Grundy", "Haier", "Haihong", "Haile Haryan", "Hallmark Hannspree", "Heran", "Herosonic", "Hiplus", "Hisense", "Hitachi", "Hko", "Hong yav", "Hongmel", "HP", "Hpc", "Hpp", "Hua Tun", "Hua-Ri", "Huafa", "Huanghe", "Huanglong", "Huangshan Huanyu", "Huaqiang", "Huaxia", "Huijiaban", "Huipu", "Humax", "Hunghalmei", "Huoda", "iSymphony", "Janell", "Jcpenney", "Joc", "Jensen Jahua", "Jatical Jian", "Jinfeng", "Jinhai", "Jinlipu", "Jinpin Jinque", "Jinta", "Jinxinbon Jinxing", "Jmb Juhua", "Jwin", "Kaige Kaihong", "Kaisul", "Kang Hong", "Kang U", "Kanghua", "Kangtaike Kangxia", "Kongyl", "Karcher", "Kawa", "Kebi", "Kelang", "Kelishi", "Kendo", "Kenwood", "Kii Kmc", "Kogan", "Kolin", "Kongque", "Konka Konkal", "Konwe", "Korechi", "KTC", "Kulungi", "Kunlun", "Lanxing Leader", "Legend", "Lonco", "Lenovo", "Lesheng", "Letv", "Levelty", "Laxsor", "Leyco LG", "Lgm", "Life", "Lifemaxxx", "Lifetec", "Lihua Linn", "Linsar", "Listo", "Lloyd", "Loewe", "Logik", "Longjiang", "Luce", "Luma", "Lumatron", "Luxor", "LXI", "Magnavox", "Maintianxing", "Malata", "Marantz Mascom", "Matsui", "Matsushita", "Mediaset Premium", "Medion", "Megapower", "Melody", "Meng Mel", "Mongmei Mermaid", "Micromax", "Mitsal", "Mitsubishi", "Mitsubushi", "Mitsumaru Monivision", "Monix", "Multi TV", "My TV", "Mystery", "NAD", "Nakamichi", "Nansheng", "Naxa", "NEC", "Neckermann", "Nei", "Neo", "Neon", "Neop Nevir", "Newstar", "Next", "Nextstar", "Nexus Nikai", "Nikkai", "Nikkel", "Nikko", "Nikko2", "Niko", "Nikon", "Nintaus Nobel", "Noblex", "Nokia Norcent", "Nordmende", "Npg", "Nto", "Oboni OKI", "Olevia", "Olympic", "OnePlus", "OnePlus", "Onida Optoma", "Orion", "Others!", "Others2 Otto Versand", "Ouka", "Oulian", "Oulin", "Ouling", "Packard Bell", "Palladium", "Palsonic", "Panasonic", "Panavox", "Panda", "Panorama", "Pantel", "Parker", "Pathe Marconi", "Pai Communication Systems", "Peaq Perido", "Phillips Phocus", "Pilot", "Pioneer", "Pixel", "Playmates Polar", "Polaroid", "Polytron", "Precision", "Prima", "Princeton", "Prizmo Pro2", "Protex Profilo Proline", "Promac", "Proscon", "Prosonic protech", "Proton Protron", "Proview", "Pulsar", "Pye", "Pyle", "QBell", "Qonix Quantum View", "Quasar Quelle", "Questa", "Luxor", "LXI", "Magnavox", "Maintianxing", "Malata", "Marantz", "Mascom", "Matsul Matsushita Mediaset Premium Medion", "Megapower", "Melody Meng Mal", "Mengmel", "Mermaid Micromax", "Mitsal", "Mitsubishi", "Mitsubushi", "Mitsumaru", "Monivision", "Monix", "Multi TV", "My TV", "Mystery", "NAD", "Nakamichi", "Nansheng", "Naxo", "NEC", "Neckermann", "Nei", "Neo", "Neon", "Neoo", "Nevir", "Newstar", "Next", "Nextstor", "Nexus", "Nikai", "Nikkal Nikkei", "Nikko", "Nikko2", "Niko", "Nikon", "Nintaus", "Nobel", "Noblex", "Nokia Norcent", "Nordmende", "Npg", "Nto", "Oboni", "OKI", "Olevia", "Olympic", "OnePlus OnePlusl", "Onida", "Optoma", "Orion", "Others!", "Others2 Otto Versand", "Ouka Oulian", "Oulin", "Ouling Packard Bell", "Palladium", "Palsonic", "Panasonic", "Panavox", "Panda", "Panorama", "Pantel", "Parker Pathe Marconi Pdi Communication Systems", "Peac Perido", "Philco", "Philips Phocus", "Pilot", "Pioneer", "Pixel", "Playmates", "Polar", "Polaroid", "Polytron Precision", "Prima Princeton", "Prizmo", "Pro2", "Profex", "Profilo", "Proline Promac", "Proscon", "Prosonic", "protech", "Proton", "Protron", "Proview Pulsar", "Pya Pyle", "QBell", "Qonix", "Quantum View Quasar", "Quelle Questa", "RadioShack", "Rainbow", "RCA", "Relon", "Rihong", "Rinex", "Ripal", "Risun", "Rizhi", "Rowa", "Royalstor", "Rubin", "Ruyl Saba", "Sabre", "Sadstroms", "Sogem", "Saige", "Saisho", "Salvad", "Sakai Sio", "Salora", "Samsu", "Samsung", "Samsung Smart", "San Sul", "Sanjian Sanjian2", "Sonken", "Sanling", "Sansul", "Sonsumi", "Sanyo", "Sanyuan", "Sast", "Sayville SBR", "Sceptre", "Schneider", "Scott", "Sears", "SEG", "SEI", "Seiki Seleco", "Selectron", "Semp", "Sentra", "Senzu Seye", "SFR", "Shanghal Shooting", "Sharp", "Sharper Image", "Shencal", "Sheng Litv Shongdong", "Shenyang", "Sherwood", "Shida", "Shinelco", "Shivaki", "Shov", "Siemens", "Siera", "Siesta", "Sigmac", "Signature", "Silo", "Silver", "Silvercrest Simply", "Singer", "Sinotec", "Sinudyne", "Siragon Skantic", "Skyworth Sonic", "Soniq", "Sonitron", "Sonoko", "Sonolor Sontec", "Sony", "Sound & Vision", "Soyea Soyo", "Spectra", "Speler", "Standard Start Times", "Stenway", "Sumo", "Sunbrite", "Sungoo", "Sunkal", "Sunny Sunstech", "Suoying", "Super General", "Supersonic", "Supra Supratech", "Supre Macy", "SVA", "Swisstec Sylvania", "Symphonic", "Syntax", "Syntax Olevia T-Series", "Taishan", "Tanberg", "Tandberg", "Tandy", "Tashika", "Tatung", "TCL TCM", "Td Systems", "Teac", "Tec", "Techline", "Technical", "Technika", "Tochnosat", "Techwood Tedelex", "Tek", "Teknika", "Tele Systern", "Telefunken", "Teletech Teleton", "Televia", "Tonsai", "Torris", "Tevion", "Thes Thomson", "Thom", "Thuf", "Tian", "Tiankeban", "Tobo", "Tokal", "Tokyo", "Tomashi Tomico", "Tong Guang", "Tongguang", "Topcon", "Tornado Toshiba", "Total Play", "Transonic", "Trend", "Travi", "Triumph Trust", "Trutech", "Tsingtao", "Turbox TV MI", "U-Men", "Universal", "Upstar Ushida", "Vinctv", "Vd Tech", "Vector Research", "Venturer", "Venus Veon", "Vestel", "Vexa", "Viano", "Video Concepts", "Videocon Videon", "Videotex Vidikron", "Viewpia", "Viewsonic", "Viking", "Viore", "Vision Quest", "Visione", "Vistron", "Vivax", "Vivid", "Vizio", "Vortec", "Voxson", "Walker Waltham", "Walton", "Wansa", "Wards", "Warumala Watson", "Watt Radio", "WD Live", "Wealthy", "Wega", "Weipal Weltblick", "Westinghouse", "Weston", "Westpoint Westwood", "Wharfedale", "Winbook Woon", "Wynn", "X10 Xcanvas", "Xenius", "Xfinity", "Xiangyang", "Xiangyu", "Xiguan", "Xihu Xintu", "Xinghai", "Xinmengban", "Xinrisong", "Xion", "Xuelian", "Xvision Yamaha", "Yongbao"};
    public static String[] strArr1 = {"ACT Digital", "Airtel", "Arasu Cable", "Arris", "Asianet", "Atlanta", "Attuverse", "Bhima Riddhi", "Bhoomika Digital", "Bouygues Telecom", "Bright Way", "BT Vision", "Cablesat", "Canal Digital", "Cat Vision", "Challenger", "Cisco", "CiscoExplorer", "Claro", "Class9000 HD", "Comcast", "Cox", "D Smart", "Das Digital", "DD Free", "Dish Den", "Dhru Lucky Digital", "Digi Box", "Digi Digital", "Digi Global", "Digitronic", "Direc TV", "Direct TV", "Dish", "Dish TV", "DS TV", "DTH Solid", "E Digital", "Eir Vision", "Etb Fastway", "Fetch TV", "Focus", "Foxstel", "Goenkar Digital", "Gold Master", "GTPL", "Hathway", "Hathway HD", "HDS Digital", "Home Digital", "Honduras", "Horizon", "ICC Network", "IN Digital", "IRIS", "Jay Netset", "JPR Space Digital", "Kabel Deutschland", "Kaizen", "Kerala Vision", "Kt Olleh", "KT Sky Life", "LG U Plus", "Logic Eastern", "Medion", "Mona Digital", "Motorola", "Moviestar", "NC Plus", "NET Digital", "Net Vision", "Net Vision Digital", "Netgear Next", "Nfusion", "NXT Digital", "Oachira Cable Vision", "Orange", "Ortel", "Other", "Pace", "Panasonic", "Pcss Digital", "Premium Plus", "Radiant Digitek", "RCA", "Reliance", "Relience Digital", "Samsung Box", "Saorview", "SCV", "Sea TV", "Sekhawati Digital", "Seven Star Digital", "Shri Balaji Digital", "Siti Cable", "Siti Digital", "Sky DE", "Sky Mexico", "Sky Plus", "Sky Rev", "Spectrum", "SR Digital", "Starhub", "Starsat", "SunTV Direct", "T Bord", "Talk Talk", "Tata Sky", "TCCL", "Techni", "Telekom", "Telesystem", "TelStar", "Telstra", "Tigo", "Tigo Une", "Time Warner", "Toshiba", "Turksat", "UCN Digital", "Unity Media", "V4 Media", "Vectra", "Venkata Sai Digital", "Verizon Fios", "Viasat Nigeria", "Viasat Ukraine", "Videocon", "Virgin", "Volia", "Wind Telecom", "Wintal", "Xfinity", "Yamaha HTR", "You Scod", "Zgemma", "Zippy Tel"};
    public static String[] strArr2 = {"ACL", "Acsom", "Acson", "Acura", "Addison", "Admiral", "Aermec", "Aeronik", "Air Con", "Air-Con", "Airforce", "Airlux", "Airtecnia", "Airwell", "Airworks", "Akal", "Alhasawl", "AlpicAir", "Amana", "Amoor", "Amena", "Americcol", "Anfusheng", "AOC", "Apton", "Arctic King", "Arena", "Ariec", "Armcor", "Artic King", "Asami", "ATC", "Aucma", "Aux", "Azure", "Bali", "Balu", "Banshen", "Baxd", "Beaudin", "Beaumark", "Benwin", "BLUE SKY", "Blue Star", "Blueway", "Boerka", "Bosch", "Bosko", "Boss", "Both", "Bros", "Caloreclima", "Carrier", "Casarte", "Celestial", "Central Air", "Century", "Changfeng", "Changgu", "Changhong", "Changing", "Choblo", "Chengyuan", "CHIME", "Chofu", "Chofuz", "Chuanghua", "Chunghsin", "City", "Classic America", "Climamania", "Cobra", "Colonia", "Combine", "Condor", "Consul", "Cooline", "Cooper And Hunter", "Crosley", "Dacon", "Daikin", "Daizuki", "Danby", "Daytok", "DEI", "Deplus", "Darby", "DG", "Diamond Air", "Digi", "Ducasa", "Ductless Aire", "Dyson", "E-Chern Ecoaire", "Electra", "Electrolux", "Elchlor", "Emailair", "Ether", "Ewt", "Falanban", "Fantasia", "Fedders", "Folu", "First", "Fisher", "Friedrich", "Frigidaire", "FT", "FU-CHIN", "Fujimaru", "Fujita", "Fujitsu", "Funal", "Funiki", ExifInterface.TAG_GAMMA, "Garrison", "Geant", "General", "General Max", "GENEX", "Godrej", "Gold Star", "Good Weather", "Gree", "Guoji", "Guoling", "Guqiao", "Haas", "Haier", "Hampton", "Hansa", "Heat Controllerinc", "Heller", "Heran", "Hesstar", "Hicon", "Hisense", "Hitachi", "Hyundai", "IFB", "IG", "IGC", "Imarflex", "Inada", "Innovair", "Intec", "Intertherm", "Inyan", "Island", "Jangpon", "JOC", "Jensany", "Jiangcheng", "Jiangnan", "Jity", "Jinbeijing", "Jinda", "Jinlu", "Jinsong", "Joce", "Jotal", "Junting", "Justice", "Kadeh", "Kang", "Kaussmann", "Kelang", "Kelan", "KeMinator", "Kering", "Kenmore", "Kenso", "Kenstar", "Kinghome", "KL", "Klimare", "Komatsu", "Kompania", "Kosher", "Kraft", "Kris", "Ktalkin", "Lamborghini", "Lavanta", "LG", "LG", "Llangyu", "Likaler", "Liunc Feng", "Lloyd", "Lloyd", "Loben Sebo", "MIAC", "Marshel", "Maxwell", "Mazha", "MBO", "Maling", "Micom", "Midea", "Mingxiu", "Mingyi", "Mirage", "Misakao", "Mistral", "Mitsubishi Electric", "Mitsubishi Heavy Industries", "Morris", "Movincool", "Mrcool", "Multi Jocker", "Mundclina", "Mystery", "Nakatomy", "Nakatomy", "National", "Ncp", "Ncp", "NEC", "Neo Clima", "NeoClima", "Nikko", "Nikko", "Nisa", "Norca", "Nord", "Nord", "Noritz", "North Star", "NWT", "O General", "Oak", "Ojun", "OLMO", "Omni", "Onida", "Opal", "Osaka", "Other", "Pac", "Panasonic", "Panda", "Payne", "Pensonic", "Perep", "Perfect Air", "Phico", "PhilcoAir Cleaneron", "Philips", "Pinshang", "Pioneer", "Playmates", "Polaris", "Polarwind", "Polka", "Polo Cool", "Premier", "Premium", "Proma", "Proton", "QFLOW", "Qita", "Quietside", "Rabbit", "Reconnect", "Renova", "Rheem", "Rhoss", "Rica", "Rijiang", "Rlabs", "Rose", "Roda", "Rovex", "HOWA", "Royal Cool", "Royal Soverign", "Sajo Denki", "Saron", "Samsung", "Sanken", "Sansu", "Sanyo", "Sanzuan", "Satur", "Sensei", "Serville", "Serene", "Sharing", "Sharkare", "Sharp", "Shenbac", "Shengfeng", "Shenhua", "Shownic", "Shuaibao", "Shuengling", "Sinclair", "SKM", "Skyworth", "Smart Cool", "Snowlik", "Sophia", "Soyea", "Starway", "Sunburg", "Sury", "Super Air", "Suzuki", "Tadair", "Tango", "Tasaki", "TCL", "TECO", "Tecumseh", "Tempblue", "Thermo Comfort", "Thompson", "Tianjin", "Tianyuan", "Toba", "Tongyl", "Topaire", "Toshiba", "Toshiba", "Tosot", "Toyohuifeng", "Toyotomi", "Trane", "Transco", "Trondair", "Tristar", "Turbo Air", "Uchida", "Uni-Air", "Uni-Att", "Unica al", "United", "Vertex", "Vesser", "Vestel", "Videocon", "Viesta", "Vivax", "Voltas", "Vortex", "Vox", "Wanbao", "Well", "Weltell", "Westinghouse", "Whirlpool", "Whirlpool", "Whisen", "Whynter", "Winia", "Wufeng", "Xiayang", "Xinghe", "Xiongdi", "Yair", "Yamatsu", "Yaoma", "Yconon", "YMGI", "Yonan"};
    public static String[] strArr3 = {"Canon", "Fuji", "Minolta", "Nikon", "Olympus", "Pentax", "Sony"};
    public static String[] strArr4 = {"Acer HP", "Anthem", "BenQ", "Canon", "Casio", "Dell", "Dream Vision", "EIKI", "Epson", "Infocus", "Lenovo", "LG", "Mcintosh", "NEC", "Optoma EH", "Panasonic", "Philips", "Samsung", "Sanyo", "Sony", "ViewSonic PJD"};
    public static String[] strArr5 = {"Aiwa", "Arcam", "Bose", "Cambridge Audio", "Coby", "Denon", "Edifier", "Fisher", "Harman Kardon", "Insignia", "JBL", "Jensen", "Kenwood", "Krell", "Onkyo", "Panasonic", "Philips", "Pioneer", "RCA", "Samsung", "Sony", "Yamaha", "Zenith"};
    public static String[] strArr6 = {"A.O.Smith", "AAF", "Airmate", "Amos", "Atomberg", "Aucma", "Aux", "Baili", "Bairan.", "Camel", "Changhong", "Chigo", "Diamond", "Dyson", "Electrolux", "Eosn", "EuropAce", "Great Wall", "Haier", "Hyundai", "Japan", "JINSHIKANG", "Juhehongsheng", "Juhua", "Kelon", "Kolin", "Lianchuang", "Littleswan", "Longsheng", "Mali", "Medis", "Meiling", "Midea", "MILUX", "Mitsubishi", "Origo", "Philips", "Pioneer", "Royalsta", "Sampo", "Sampux", "Sharp", "Shifeng", "Siyu", "Suoer", "Tatung", "TCL", "Telefunken", "TERA", "Thomson", "Tianma", "Tkec", "Toshiba", "Wahson", "Walton", "Whirlpool", "Xiaoxiang", "Xiaoxingxing", "Xinde", "Yadu", "Yangzi", "Zolee"};
    public static String[] strArr7 = {"Aikerul", "Almond", "Amoi", "AOC", "Aomeiteng", "Asloma", "ASUS", "BaiBian MoHe", "Baidu", "BesTV", "Bevix", "Bianfeng", "Blue Times", "Boshimel", "Boxun", "BSW Bswee", "Changhong", "Coolux", "CskyTV", "DiyoMata", "Domy", "EAGET", "Egreat", "Egreat Mango", "Fengying", "Five", "FlintStone", "Gadmel", "Geeya", "GIEC", "Great Hopes", "HaiT", "Haojingcai", "HiMedia", "Hisense", "HOTS", "Hualu", "Huashi", "Huawei", "Hyundai", "Ice Master", "iDer", "Ineng", "Infocus", "Inphic", "Watch", "Juli", "Kalboer", "KL-Wicep", "Koxsni", "Langcent", "Leader", "Lebaishi LeBo", "Leguang", "LeTV", "Lingyun", "linkin.me", "M-BOX", "Maige TV", "MANGGUO ZU", "Mango hi q", "Manytel", "Mele", "MIGU", "Mikan", "MINIX", "MNATU", "Mobile Box", "MyGica", "Mysoto", "Nokade", "Olymdanton", "OpenBox", "Peasun", "Pisen", "PPBOX", "Pulier", "QVOD", "RCA", "RealPlay", "Routon", "Saikeda", "SAST", "SCX", "Shinco", "Skyworth", "Sling Media", "SOOALL", "Subor", "Sumavison", "Tangdou", "TCL", "Tmbox", "Togic", "TOPSAT", "TSHIFI", "Unismaison", "VideoStrong", "Voole", "Weide", "Wihome", "WoBo", "Yeeboo", "Youku", "Youku Mofang", "Ysten", "YueMe", "Zilerpollo", "ZTE"};

    public static ArrayList<String> TVBrandsList1() {
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("SONY Bravia TV - Android");
        arrayList.add("Samsung Smart TV - Tizen");
        arrayList.add("LG Smart TV - webOS");
        arrayList.add("Android TV Remote");
        arrayList.add("Amazon Fire TV + Fire Stick");
        arrayList.add("Roku TV Remote");
        arrayList.add("VIZIO SmartCast TV Remote");
        arrayList.add("TCL TV - Roku");
        arrayList.add("SHARP Aquos - Android");
        arrayList.add("SHARP Aquos - Roku");
        arrayList.add("AOC TV - Roku");
        arrayList.add("AOC TV - Roku");
        arrayList.add("Hisense TV - Roku");
        arrayList.add("Insignia TV - Roku");
        arrayList.add("Roku Express + Roku Media Player");
        arrayList.add("PHILIPS TV - Android");
        arrayList.add("Arcelik TV - Android");
        arrayList.add("Vestel TV - Android");
        arrayList.add("Sanyo TV - Roku");
        arrayList.add("Element TV - Roku");
        arrayList.add("JVC TV - Roku");
        arrayList.add("RCA TV - Roku");
        arrayList.add("Magnavox TV - Roku");
        arrayList.add("Haier TV - Roku");
        arrayList.add("PHILIPS TV - Roku");
        arrayList.add("PHILIPS TV - Roku");
        arrayList.add("RAZOR Forge TV - Android");
        arrayList.add("LeEco - Android");
        arrayList.add("Google Nexus - Android");
        arrayList.add("Xiaomi Mi Box - Android");
        arrayList.add("LMT TV iekarta - Android");
        arrayList.add("Nvidia Shield - Android");
        arrayList.add("LEONET LifeStick - Android");
        arrayList.add("Toshiba TV - Android");
        arrayList.add("Sanyo TV - Android");
        arrayList.add("SkyWorth TV - Android");
        arrayList.add("Westinghouse TV - Roku");
        arrayList.add("Westinghouse TV - Android");
        arrayList.add("Thomson TV - Android");
        arrayList.add("BAUHN TV - Android");
        arrayList.add("Infomir Magic Box - Android");
        arrayList.add("Vodafone TV - Android");
        arrayList.add("TCL TV - Android");
        arrayList.add("KAON 4K - Android");
        arrayList.add("FreeBox Mini 4K - Android");
        arrayList.add("Tsuyata Stick - Android");
        arrayList.add("1und1 - Android");
        arrayList.add("Aconatic - Android");
        arrayList.add("Aiwa TV - Android");
        arrayList.add("ANAM - Android");
        arrayList.add("Anker - Android");
        arrayList.add("ASANZO - Android");
        arrayList.add("Asus - Android");
        arrayList.add("Ayonz - Android");
        arrayList.add("BenQ - Android");
        arrayList.add("Blaupnkt - Android");
        arrayList.add("Casper - Android");
        arrayList.add("CG - Android");
        arrayList.add("Changhong - Android");
        arrayList.add("Chimei - Android");
        arrayList.add("CHiq - Android");
        arrayList.add("Condor - Android");
        arrayList.add("Dish TV - Android");
        arrayList.add("Eko - Android");
        arrayList.add("Elsys - Android");
        arrayList.add("Ematic - Android");
        arrayList.add("ENTV - Android");
        arrayList.add("EPSON - Android");
        arrayList.add("ESTLA - Android");
        arrayList.add("FOXCom - Android");
        arrayList.add("FPT Play - Android");
        arrayList.add("Funai - Android");
        arrayList.add("Globe Telecom - Android");
        arrayList.add("Haier - Android");
        arrayList.add("Hansung - Android");
        arrayList.add("Hisense - Android");
        arrayList.add("HORISON - Android");
        arrayList.add("IFFalcon - Android");
        arrayList.add("Infinix - Android");
        arrayList.add("Iriver - Android");
        arrayList.add("Itel - Android");
        arrayList.add("JBL - Android");
        arrayList.add("JVC - Android");
        arrayList.add("KIVI - Android");
        arrayList.add("KODAK - Android");
        arrayList.add("Kogan - Android");
        arrayList.add("KOODA - Android");
        arrayList.add("Linsar - Android");
        arrayList.add("Llyod - Android");
        arrayList.add("LUCOMS - Android");
        arrayList.add("Marcel - Android");
        arrayList.add("MarQ - Android");
        arrayList.add("Mediabox - Android");
        arrayList.add("Motorola - Android");
        arrayList.add("MyBox - Android");
        arrayList.add("Nokia - Android");
        arrayList.add("OnePlus - Android");
        arrayList.add("Orange - Android");
        arrayList.add("Panasonic - Android");
        arrayList.add("PIXELA - Android");
        arrayList.add("Polaroid - Android");
        arrayList.add("PRISM Korea - Android");
        arrayList.add("RCA - Android");
        arrayList.add("Robi Axiata - Android");
        arrayList.add("Sceptre - Android");
        arrayList.add("Seiki - Android");
        arrayList.add("SFR - Android");
        arrayList.add("SMARTEVER - Android");
        arrayList.add("SONIQ Australia - Android");
        arrayList.add("Syinix - Android");
        arrayList.add("Telekom Malaysia - Android");
        arrayList.add("Tempo - Android");
        arrayList.add("theham - Android");
        arrayList.add("TPV (Philips EMEA) - Android");
        arrayList.add("Truvii - Android");
        arrayList.add("Trubo - X - Android");
        arrayList.add("UMAX - Android");
        arrayList.add("VideoStrong - Android");
        arrayList.add("VinSmart - Android");
        arrayList.add("VU Television - Android");
        arrayList.add("Walton - Android");
        arrayList.add("Witooth - Android");
        arrayList.add("XGIMI Technology - Android");
        arrayList.add("ATVIO - Roku");
        arrayList.add("InFocus - Roku");
        arrayList.add("Hitachi - Roku");
        arrayList.add("Onn - Roku");
        arrayList.add("Polaroid - Roku");
        arrayList.add("Daewoo - Android");
        arrayList.add("Kalley - Android");
        arrayList.add("Ecostar - Android");
        arrayList.add("Coocaa - Android");
        arrayList.add("Hathway - Android");
        arrayList.add("HQ - Android");
        arrayList.add("Konka - Android");
        arrayList.add("Premier - Android");
        arrayList.add("Riviera - Android");
        arrayList.add("EON Smart Box - Android");
        arrayList.add("B UHD - Android");
        arrayList.add("Artel - Android");
        arrayList.add("Metz - Android");
        arrayList.add("Orient - Android");
        arrayList.add("MyStery - Android");
        arrayList.add("ELEBBERG - Android");
        arrayList.add("Prestigio - Android");
        arrayList.add("TIM Vision Box - Android");
        arrayList.add("Philco - Android");
        arrayList.add("Hi Level - Android");
        arrayList.add("Ghia - Android");
        arrayList.add("Iris - Android");
        arrayList.add("Sunny - Android");
        arrayList.add("Nasco - Android");
        arrayList.add("Caixun - Android");
        arrayList.add("Prestiz - Android");
        arrayList.add("Axen - Android");
        arrayList.add("Nobelx - Android");
        arrayList.add("Indurama - Android");
        arrayList.add("Sansui - Android");
        arrayList.add("Stream - Android");
        arrayList.add("Ondia - Android");
        arrayList.add("Sinotec - Android");
        arrayList.add("Polytron - Android");
        arrayList.add("RealMe - Android");
        arrayList.add("Vitron - Android");
        return arrayList;
    }

    public static List<String> TVBrandsList2() {
        return Arrays.asList(strArr);
    }

    public static List<String> TVBrandsList3() {
        return Arrays.asList(strArr1);
    }

    public static List<String> TVBrandsList4() {
        return Arrays.asList(strArr2);
    }

    public static List<String> TVBrandsList5() {
        return Arrays.asList(strArr3);
    }

    public static List<String> TVBrandsList6() {
        return Arrays.asList(strArr4);
    }

    public static List<String> TVBrandsList7() {
        return Arrays.asList(strArr5);
    }

    public static List<String> TVBrandsList8() {
        return Arrays.asList(strArr6);
    }

    public static List<String> TVBrandsList9() {
        return Arrays.asList(strArr7);
    }

    public static ArrayList<String> getAllShownImagesPath(Activity activity) {
        ArrayList<String> arrayList = new ArrayList<>();
        Cursor query = activity.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{"_data", "bucket_display_name"}, (String) null, (String[]) null, (String) null);
        int columnIndexOrThrow = query.getColumnIndexOrThrow("_data");
        query.getColumnIndexOrThrow("bucket_display_name");
        while (query.moveToNext()) {
            arrayList.add(query.getString(columnIndexOrThrow));
        }
        return arrayList;
    }

    public static ArrayList<String> getAllShownVideoPath(Activity activity) {
        HashSet hashSet = new HashSet();
        Cursor query = activity.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, new String[]{"_data", "_display_name"}, (String) null, (String[]) null, (String) null);
        try {
            query.moveToFirst();
            do {
                hashSet.add(query.getString(query.getColumnIndexOrThrow("_data")));
            } while (query.moveToNext());
            query.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ArrayList<>(hashSet);
    }

    public static ArrayList<Song> getAllSongs(Context context) {
        return getSongs(makeSongCursor(context, (String) null, (String[]) null));
    }

    public static ArrayList<Song> getSongs(Context context, String str) {
        return getSongs(makeSongCursor(context, "title LIKE ?", new String[]{"%" + str + "%"}));
    }

    public static Song getSong(Context context, int i) {
        return getSong(makeSongCursor(context, "_id=?", new String[]{String.valueOf(i)}));
    }

    /* JADX WARNING: Removed duplicated region for block: B:7:0x001c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static ArrayList<Song> getSongs(Cursor r2) {
        /*
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            if (r2 == 0) goto L_0x001a
            boolean r1 = r2.moveToFirst()
            if (r1 == 0) goto L_0x001a
        L_0x000d:
            com.royalstatus.remote.control.universal.forall.tv.Song r1 = getSongFromCursorImpl(r2)
            r0.add(r1)
            boolean r1 = r2.moveToNext()
            if (r1 != 0) goto L_0x000d
        L_0x001a:
            if (r2 == 0) goto L_0x001f
            r2.close()
        L_0x001f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.royalstatus.remote.control.universal.forall.tv.Constant.getSongs(android.database.Cursor):java.util.ArrayList");
    }

    public static Song getSong(Cursor cursor) {
        Song song;
        if (cursor == null || !cursor.moveToFirst()) {
            song = Song.EMPTY_SONG;
        } else {
            song = getSongFromCursorImpl(cursor);
        }
        if (cursor != null) {
            cursor.close();
        }
        return song;
    }

    private static Song getSongFromCursorImpl(Cursor cursor) {
        return new Song(cursor.getInt(0), cursor.getString(1), cursor.getInt(2), cursor.getInt(3), cursor.getLong(4), cursor.getString(5), cursor.getLong(6), cursor.getInt(7), cursor.getString(8), cursor.getInt(9), cursor.getString(10));
    }

    public static Cursor makeSongCursor(Context context, String str, String[] strArr8) {
        return makeSongCursor(context, str, strArr8, (String) null);
    }

    public static Cursor makeSongCursor(Context context, String str, String[] strArr8, String str2) {
        String str3 = str;
        String str4 = BASE_SELECTION;
        if (str3 != null && !str.trim().equals("")) {
            str4 = str4 + " AND " + str3;
        }
        try {
            return context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "title", "track", "year", TypedValues.TransitionType.S_DURATION, "_data", "date_modified", "album_id", "album", "artist_id", "artist"}, str4, strArr8, str2);
        } catch (SecurityException unused) {
            return null;
        }
    }

    public static String formateMilliSeccond(long j) {
        String str;
        String str2;
        int i = (int) (j / 3600000);
        long j2 = j % 3600000;
        int i2 = ((int) j2) / 60000;
        int i3 = (int) ((j2 % DefaultLoadErrorHandlingPolicy.DEFAULT_TRACK_BLACKLIST_MS) / 1000);
        if (i > 0) {
            str = i + ":";
        } else {
            str = "";
        }
        if (i3 < 10) {
            str2 = "" + i3;
         str2 = AppEventsConstants.EVENT_PARAM_VALUE_NO + i3;
        } else {
            str2 = "" + i3;
        }
        return str + i2 + ":" + str2;
    }
}
