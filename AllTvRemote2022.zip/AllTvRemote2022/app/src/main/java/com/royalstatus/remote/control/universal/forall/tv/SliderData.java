package com.royalstatus.remote.control.universal.forall.tv;

public class SliderData {
    private String imgUrl;

    public SliderData(String str) {
        this.imgUrl = str;
    }

    public String getImgUrl() {
        return this.imgUrl;
    }

    public void setImgUrl(String str) {
        this.imgUrl = str;
    }
}
