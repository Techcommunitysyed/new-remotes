package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
//import androidx.media2.exoplayer.external.DefaultRenderersFactory;
//import androidx.media2.exoplayer.external.trackselection.AdaptiveTrackSelection;
//import com.two.dgbmapp.hdvideoprojector.part2.MainActivity1;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import vocsy.google.ads.AllInOneAds;

public class ProgressActivity extends AppCompatActivity {
    LinearLayout complete;
    ImageView firstdot;
    ImageView firstmark;
    ImageView fourdot;
    ImageView fourmark;
    Button next;
    LinearLayout running;
    ImageView seconddot;
    ImageView secondmark;
    ImageView thirddot;
    ImageView thirdmark;
    TextView tv_1;
    TextView tv_2;
    TextView tv_3;
    TextView tv_4;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_progress);
        ((ImageView) findViewById(R.id.imgBack)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ProgressActivity.this.onBackPressed();
            }
        });
        this.running = (LinearLayout) findViewById(R.id.running);
        this.complete = (LinearLayout) findViewById(R.id.complete);
        this.next = (Button) findViewById(R.id.next);
        this.firstdot = (ImageView) findViewById(R.id.firstdot);
        this.seconddot = (ImageView) findViewById(R.id.seconddot);
        this.thirddot = (ImageView) findViewById(R.id.thirddot);
        this.fourdot = (ImageView) findViewById(R.id.fourdot);
        this.firstmark = (ImageView) findViewById(R.id.firstmark);
        this.secondmark = (ImageView) findViewById(R.id.secondmark);
        this.thirdmark = (ImageView) findViewById(R.id.thirdmark);
        this.fourmark = (ImageView) findViewById(R.id.fourmark);
        this.tv_1 = (TextView) findViewById(R.id.tv_1);
        this.tv_2 = (TextView) findViewById(R.id.tv_2);
        this.tv_3 = (TextView) findViewById(R.id.tv_3);
        this.tv_4 = (TextView) findViewById(R.id.tv_4);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                ProgressActivity.this.running.setVisibility(View.GONE);
                ProgressActivity.this.complete.setVisibility(View.VISIBLE);
            }
        }, 7000);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                ProgressActivity.this.firstdot.setVisibility(View.GONE);
                ProgressActivity.this.firstmark.setVisibility(View.VISIBLE);
                ProgressActivity.this.tv_1.setTextColor(ProgressActivity.this.getResources().getColor(R.color.white));
            }
//            AdaptiveTrackSelection.DEFAULT_MIN_TIME_BETWEEN_BUFFER_REEVALUTATION_MS);
        }, AdaptiveTrackSelection.DEFAULT_MIN_DURATION_FOR_QUALITY_INCREASE_MS);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                ProgressActivity.this.seconddot.setVisibility(View.GONE);
                ProgressActivity.this.secondmark.setVisibility(View.VISIBLE);
                ProgressActivity.this.tv_2.setTextColor(ProgressActivity.this.getResources().getColor(R.color.white));
            }
        }, 4000);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                ProgressActivity.this.thirddot.setVisibility(View.GONE);
                ProgressActivity.this.tv_3.setTextColor(ProgressActivity.this.getResources().getColor(R.color.white));
                ProgressActivity.this.thirdmark.setVisibility(View.VISIBLE);
            }
           // DefaultRenderersFactory.DEFAULT_ALLOWED_VIDEO_JOINING_TIME_MS);
        }, DefaultRenderersFactory.DEFAULT_ALLOWED_VIDEO_JOINING_TIME_MS);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                ProgressActivity.this.fourdot.setVisibility(View.GONE);
                ProgressActivity.this.fourmark.setVisibility(View.VISIBLE);
                ProgressActivity.this.tv_4.setTextColor(ProgressActivity.this.getResources().getColor(R.color.white));
            }
        }, 7000);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                ProgressActivity.this.next.setVisibility(View.VISIBLE);
            }
        }, 7000);
        this.next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ProgressActivity.this.startActivity(new Intent(ProgressActivity.this.getApplicationContext(), MainActivity1.class));

            }
        });
    }

    public void onBackPressed() {
        ProgressActivity.this.finish();

    }
}
