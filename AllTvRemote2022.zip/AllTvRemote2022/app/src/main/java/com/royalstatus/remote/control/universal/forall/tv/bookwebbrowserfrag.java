package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
import java.io.PrintStream;

public class bookwebbrowserfrag extends AppCompatActivity {
    ImageButton back;
    ImageView backs;
    ImageView drawer;
    DrawerLayout drawer_layout;
    EditText editText;
    ImageButton forward;
    RelativeLayout gift;
    ImageButton homeButton;
    ImageView imgcast;
    ImageView imgclosed;
    ImageView imgmore;
    NavigationView nav_view;
    ProgressBar progressBar;
    ImageButton refresh;
    ImageButton stop;
    String str;
    String strval;
    LinearLayout toolbar2;
    RelativeLayout toolbar3;
    TextView txtlink;
    WebView webView;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.browserfra);
        adsandnavigation();
        Intent intent = getIntent();
        ((WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE)).setWifiEnabled(true);
        this.str = intent.getStringExtra("linkk");
        this.strval = intent.getStringExtra("nn");
        this.editText = (EditText) findViewById(R.id.web_address_edit_text);
        this.back = (ImageButton) findViewById(R.id.back_arrow);
        this.forward = (ImageButton) findViewById(R.id.forward_arrow);
        this.stop = (ImageButton) findViewById(R.id.stop);
        this.imgclosed = (ImageView) findViewById(R.id.imgclosed);
        this.backs = (ImageView) findViewById(R.id.back);
        this.imgmore = (ImageView) findViewById(R.id.imgmore);
        ImageView imageView = (ImageView) findViewById(R.id.imgcast);
        this.imgcast = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                bookwebbrowserfrag.this.lambda$onCreate$0$bookwebbrowserfrag(view);
            }
        });
        this.refresh = (ImageButton) findViewById(R.id.refresh);
        this.toolbar2 = (LinearLayout) findViewById(R.id.toolbar2);
        this.toolbar3 = (RelativeLayout) findViewById(R.id.toolbar3);
        this.homeButton = (ImageButton) findViewById(R.id.home);
        this.txtlink = (TextView) findViewById(R.id.txtlink);
        Glide.with((FragmentActivity) this).asGif().load(Integer.valueOf(R.drawable.cast)).into(this.imgcast);
        this.backs.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                bookwebbrowserfrag.this.lambda$onCreate$1$bookwebbrowserfrag(view);
            }
        });
        this.imgmore.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                bookwebbrowserfrag.this.lambda$onCreate$2$bookwebbrowserfrag(view);
            }
        });
        ProgressBar progressBar2 = (ProgressBar) findViewById(R.id.progress_bar);
        this.progressBar = progressBar2;
        progressBar2.setMax(100);
        this.progressBar.setVisibility(View.VISIBLE);
        this.imgclosed.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(bookwebbrowserfrag.this, R.style.traparentdialog);
                ViewGroup viewGroup = null;
                View inflate = LayoutInflater.from(bookwebbrowserfrag.this).inflate(R.layout.exitdialog, (ViewGroup) null);
                builder.setView(inflate);
                final AlertDialog create = builder.create();
                create.show();
                ((TextView) inflate.findViewById(R.id.yes)).setOnClickListener(new View.OnClickListener() {
                    public final void onClick(View view) {
                     lambda$onClick$0$bookwebbrowserfrag$2(view);
                    }
                });
                ((TextView) inflate.findViewById(R.id.no)).setOnClickListener(new View.OnClickListener() {
                    public final void onClick(View view) {
                        create.dismiss();
                    }
                });
            }

            public void lambda$onClick$0$bookwebbrowserfrag$2(View view) {
                bookwebbrowserfrag.this.finish();
            }
        });
        this.editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                return bookwebbrowserfrag.this.lambda$onCreate$3$bookwebbrowserfrag(textView, i, keyEvent);
            }
        });
        WebView webView2 = (WebView) findViewById(R.id.web_view);
        this.webView = webView2;
        if (bundle != null) {
            webView2.restoreState(bundle);
        } else {
            if (this.strval.contains("val")) {
                this.txtlink.setText(this.str);
                this.webView.loadUrl(this.str);
            }
            this.webView.getSettings().setJavaScriptEnabled(true);
            this.webView.getSettings().setUseWideViewPort(true);
            this.webView.getSettings().setLoadWithOverviewMode(true);
            this.webView.getSettings().setSupportZoom(true);
            this.webView.getSettings().setSupportMultipleWindows(true);
            this.webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
            this.webView.setBackgroundColor(-1);
            this.webView.setWebChromeClient(new WebChromeClient() {
                public void onProgressChanged(WebView webView, int i) {
                    super.onProgressChanged(webView, i);
                    bookwebbrowserfrag.this.progressBar.setProgress(i);
                    if (i < 100 && bookwebbrowserfrag.this.progressBar.getVisibility() == View.GONE) {
                        bookwebbrowserfrag.this.progressBar.setVisibility(View.VISIBLE);
                    }
                    if (i == 100) {
                        bookwebbrowserfrag.this.progressBar.setVisibility(View.GONE);
                    } else {
                        bookwebbrowserfrag.this.progressBar.setVisibility(View.VISIBLE);
                    }
                }
            });
        }
        this.txtlink.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                bookwebbrowserfrag.this.lambda$onCreate$4$bookwebbrowserfrag(view);
            }
        });
        this.webView.setWebViewClient(new MyWebViewClient());
        this.back.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                bookwebbrowserfrag.this.lambda$onCreate$5$bookwebbrowserfrag(view);
            }
        });
        this.forward.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                bookwebbrowserfrag.this.lambda$onCreate$6$bookwebbrowserfrag(view);
            }
        });
        this.stop.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                bookwebbrowserfrag.this.lambda$onCreate$7$bookwebbrowserfrag(view);
            }
        });
        this.refresh.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                bookwebbrowserfrag.this.lambda$onCreate$8$bookwebbrowserfrag(view);
            }
        });
        this.homeButton.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                bookwebbrowserfrag.this.lambda$onCreate$9$bookwebbrowserfrag(view);
            }
        });
    }

    public void lambda$onCreate$0$bookwebbrowserfrag(View view) {
        try {
            startActivity(new Intent("android.settings.CAST_SETTINGS"));
        } catch (Exception unused) {
            Toast.makeText(getApplicationContext(), "Device not supported", Toast.LENGTH_LONG).show();
        }
    }

    public void lambda$onCreate$1$bookwebbrowserfrag(View view) {
        this.toolbar3.setVisibility(View.VISIBLE);
        this.toolbar2.setVisibility(View.GONE);
    }

    public void lambda$onCreate$2$bookwebbrowserfrag(View view) {
        PopupMenu popupMenu = new PopupMenu(this, this.imgmore);
        popupMenu.inflate(R.menu.weboption);
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem menuItem) {
                int itemId = menuItem.getItemId();
                if (itemId == R.id.menu1) {
                    bookwebbrowserfrag.this.startActivity(new Intent(bookwebbrowserfrag.this, HistoryActivity.class));
                    return false;
                } else if (itemId == R.id.menu2) {
                    bookwebbrowserfrag.this.startActivity(new Intent(bookwebbrowserfrag.this, Bookmarkactivity.class));
                    return false;
                } else {
                    if (itemId == R.id.menu3) {
                        UsersDatabaseAdapter.insertEntry(bookwebbrowserfrag.this.txtlink.getText().toString().trim(), "sachin", "sachinnnn");
                    }
                    return false;
                }
            }
        });
        popupMenu.show();
    }

    public boolean lambda$onCreate$3$bookwebbrowserfrag(TextView textView, int i, KeyEvent keyEvent) {
        if (i == 2) {
            try {
                if (!NetworkState.connectionAvailable(this)) {
                    Toast.makeText(this, "check connection", Toast.LENGTH_SHORT).show();
                } else {
                    System.out.println(">>>>>> simple");
                    ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(this.editText.getWindowToken(), 0);
                    this.webView.setWebViewClient(new CustomWebClient());
                    this.webView.loadUrl(this.editText.getText().toString());
                    this.toolbar3.setVisibility(View.VISIBLE);
                    this.toolbar2.setVisibility(View.GONE);
                    this.txtlink.setText(this.editText.getText().toString());
                    PrintStream printStream = System.out;
                    printStream.println(">>>>>>>>>" + this.webView.getUrl());
                    Log.e("Error Found ", ">>>>>>>>>>" + this.webView.getOriginalUrl());
                    UsersDatabaseAdapter.inserthistoryEntry(this.editText.getText().toString().trim(), "Patel", "Patidar");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public void lambda$onCreate$4$bookwebbrowserfrag(View view) {
        this.toolbar2.setVisibility(View.VISIBLE);
        this.toolbar3.setVisibility(View.GONE);
    }

    public void lambda$onCreate$5$bookwebbrowserfrag(View view) {
        if (this.webView.canGoBack()) {
            this.webView.goBack();
        }
    }

    public void lambda$onCreate$6$bookwebbrowserfrag(View view) {
        if (this.webView.canGoForward()) {
            this.webView.goForward();
        }
    }

    public void lambda$onCreate$7$bookwebbrowserfrag(View view) {
        this.webView.stopLoading();
    }

    public void lambda$onCreate$8$bookwebbrowserfrag(View view) {
        this.webView.reload();
    }

    public void lambda$onCreate$9$bookwebbrowserfrag(View view) {
        this.webView.loadUrl("http://google.com");
    }

    public static class CustomWebClient extends WebViewClient {
        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            webView.loadUrl(str);
            return true;
        }
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
        this.gift = (RelativeLayout) findViewById(R.id.gift);
        this.drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        this.nav_view = (NavigationView) findViewById(R.id.nav_view);
    }

    public void onBackPressed() {
      finish();
    }
}
