package com.royalstatus.remote.control.universal.forall.tv;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ExitActivity extends AppCompatActivity {
    ImageView back;
    TextView btn_no;
    TextView btn_yes;
    RatingBar ratingBar;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.ff_activity_exit);
        ImageView imageView = (ImageView) findViewById(R.id.back);
        this.back = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ExitActivity.this.finish();
            }
        });
        this.btn_no = (TextView) findViewById(R.id.notnow);
        this.btn_yes = (TextView) findViewById(R.id.exit);
        this.ratingBar = (RatingBar) findViewById(R.id.ratestar);
        this.btn_yes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ExitActivity.this.finishAffinity();
            }
        });
        this.btn_no.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ExitActivity.this.finish();
            }
        });
        this.ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            public void onRatingChanged(RatingBar ratingBar, float f, boolean z) {
                try {
                    ExitActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + ExitActivity.this.getPackageName())));
                } catch (ActivityNotFoundException unused) {
                }
            }
        });
    }
}
