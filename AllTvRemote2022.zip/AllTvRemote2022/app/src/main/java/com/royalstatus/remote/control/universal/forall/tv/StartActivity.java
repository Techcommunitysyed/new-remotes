package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class StartActivity extends AppCompatActivity {

    RelativeLayout rateapp;
    RelativeLayout share_app;
    TextView start;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_start);
        this.share_app = (RelativeLayout) findViewById(R.id.share_app);

        this.rateapp = (RelativeLayout) findViewById(R.id.rateapp);
        TextView textView = (TextView) findViewById(R.id.start);
        this.start = textView;
        textView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                StartActivity.this.startActivity(new Intent(StartActivity.this, GetStart2.class));
            }
        });


    }

    public void onBackPressed() {
        StartActivity.this.startActivity(new Intent(StartActivity.this, ExitScreen.class));

    }
}
