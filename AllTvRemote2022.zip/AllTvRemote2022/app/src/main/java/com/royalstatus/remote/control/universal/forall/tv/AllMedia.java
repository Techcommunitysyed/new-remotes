package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;


public class AllMedia extends AppCompatActivity {
    ImageView audio;
    ImageView image;
    ImageView video;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_all_media);
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AllMedia.this.onBackPressed();
            }
        });
        adsandnavigation();
        this.video = (ImageView) findViewById(R.id.video);
        this.image = (ImageView) findViewById(R.id.image);
        this.video.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AllMedia.this.startActivity(new Intent(AllMedia.this, ALL_FOLDER_FRAGMENT.class));

            }
        });
        this.image.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AllMedia.this.startActivity(new Intent(AllMedia.this, IMG_FOLDER_FRAGMENT.class));

            }
        });
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
    }

    public void onBackPressed() {
        AllMedia.this.finish();
    }
}
