package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class More_Activity extends AppCompatActivity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView((int) R.layout.act_more);
    }

    public void onBackPressed() {
        finish();
    }
}
