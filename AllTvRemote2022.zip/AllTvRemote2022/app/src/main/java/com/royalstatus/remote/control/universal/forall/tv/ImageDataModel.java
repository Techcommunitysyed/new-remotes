package com.royalstatus.remote.control.universal.forall.tv;

public class ImageDataModel {
    private String imagePath;
    private String imageTitle;

    public String getImageTitle() {
        return this.imageTitle;
    }

    public void setImageTitle(String str) {
        this.imageTitle = str;
    }

    public String getImagePath() {
        return this.imagePath;
    }

    public void setImagePath(String str) {
        this.imagePath = str;
    }

    public ImageDataModel(String str, String str2) {
        this.imageTitle = str;
        this.imagePath = str2;
    }
}
