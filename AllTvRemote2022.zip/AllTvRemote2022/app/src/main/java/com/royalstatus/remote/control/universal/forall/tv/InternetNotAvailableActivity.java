package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import com.androidstudy.networkmanager.Monitor;
import com.androidstudy.networkmanager.Tovuti;
import com.bumptech.glide.Glide;


public class InternetNotAvailableActivity extends AppCompatActivity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_internet_not_available);
        Glide.with((FragmentActivity) this).asGif().load(Integer.valueOf(R.drawable.no_interner_error_gif1)).into((ImageView) findViewById(R.id.gifView));
        Tovuti.from(this).monitor(new Monitor.ConnectivityListener() {
            public void onConnectivityChanged(int i, boolean z, boolean z2) {
                if (!z) {
                    return;
                }
//                if (AdsUtils.nativeId.length() < 1) {
//                    AdsUtils.getInstance(InternetNotAvailableActivity.this);
//                    new GetSmartAdmob(InternetNotAvailableActivity.this, new GetSmartAdmob.SmartListener() {
//                        public void onComplete() {
//                            Toast.makeText(InternetNotAvailableActivity.this, "Back to online.", Toast.LENGTH_SHORT).show();
//                            InternetNotAvailableActivity.this.finish();
//                        }
//                    }).execute(new Void[0]);
//                    return;
//                }
                Toast.makeText(InternetNotAvailableActivity.this, "Back to online.", Toast.LENGTH_SHORT).show();
                InternetNotAvailableActivity.this.finish();
            }
        });
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        findViewById(R.id.exit_app_bt).setOnClickListener(new InternetNotAvailableActivity$$ExternalSyntheticLambda0(this));
//        findViewById(R.id.retry_bt).setOnClickListener(new InternetNotAvailableActivity$$ExternalSyntheticLambda1(this, progressBar, new Random().nextInt(AdError.AD_PRESENTATION_ERROR_CODE) + 1000));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$0$vocsy-google-ads-InternetNotAvailableActivity  reason: not valid java name */
    public /* synthetic */ void m1551lambda$onCreate$0$vocsygoogleadsInternetNotAvailableActivity(View view) {
        startActivity(new Intent(this, ExitScreen.class));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$1$vocsy-google-ads-InternetNotAvailableActivity  reason: not valid java name */
    public /* synthetic */ void m1552lambda$onCreate$1$vocsygoogleadsInternetNotAvailableActivity(final ProgressBar progressBar, int i, View view) {
        progressBar.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(InternetNotAvailableActivity.this, "Internet not found.", Toast.LENGTH_SHORT).show();
            }
        }, (long) i);
    }

    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
}
