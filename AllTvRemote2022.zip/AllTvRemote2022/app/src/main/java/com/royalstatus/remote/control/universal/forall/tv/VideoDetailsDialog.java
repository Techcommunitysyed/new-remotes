package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.widget.TextView;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.VIDEO_MODEL;

public class VideoDetailsDialog {
    /* access modifiers changed from: private */
    public static Dialog dialog;
    private static TextView tvDate;
    private static TextView tvDone;
    private static TextView tvFile;
    private static TextView tvLength;
    private static TextView tvLocation;
    private static TextView tvResolution;
    private static TextView tvSize;
    private static TextView tvTitle;

    private static void getId() {
        tvTitle = (TextView) dialog.findViewById(R.id.tvTitle);
        tvFile = (TextView) dialog.findViewById(R.id.tvFile);
        tvLocation = (TextView) dialog.findViewById(R.id.tvLocation);
        tvSize = (TextView) dialog.findViewById(R.id.tvSize);
        tvDate = (TextView) dialog.findViewById(R.id.tvDate);
        tvResolution = (TextView) dialog.findViewById(R.id.tvResolution);
        tvLength = (TextView) dialog.findViewById(R.id.tvLength);
        tvDone = (TextView) dialog.findViewById(R.id.tvDone);
    }

    public static void show(Context context, VIDEO_MODEL video_model) {
        Dialog dialog2 = new Dialog(context);
        dialog = dialog2;
        dialog2.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_video_details);
        getId();
        tvTitle.setText(video_model.getTitle());
        tvFile.setText(video_model.getDisplayName());
        tvLocation.setText(video_model.getData());
        tvSize.setText(video_model.getSize());
        tvDate.setText(video_model.getDate());
        tvResolution.setText(video_model.getResolution());
        tvLength.setText(video_model.getDuartion());
        tvDone.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                VideoDetailsDialog.dialog.dismiss();
            }
        });
        dialog.show();
    }
}
