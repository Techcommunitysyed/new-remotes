package com.royalstatus.remote.control.universal.forall.tv;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaRouter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.Objects;


public class MainActivity1 extends AppCompatActivity {
    int B = 0;
    Button screenCasting;
    Button screenCastingStop;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main1);
        findViewById(R.id.imgBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MainActivity1.this.onBackPressed();
            }
        });
        this.screenCasting = (Button) findViewById(R.id.screen_casting_start);
        this.screenCastingStop = (Button) findViewById(R.id.screen_casting_stop);
        this.screenCasting.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (MainActivity1.c(MainActivity1.this).booleanValue()) {
                    int i = MainActivity1.this.B + 1;
                    MainActivity1.this.B = i;
                    MainActivity1.a(MainActivity1.this, Integer.valueOf(i));
                    if (MainActivity1.this.getSharedPreferences("SHARED_DATABASE_NAME", 0).getInt("count_how2Use", 0) > 0) {
                        MainActivity1.this.w();
                    } else if (MainActivity1.this.getSharedPreferences("SHARED_DATABASE_NAME", 0).getBoolean("isChecked_how2Use", false)) {
                        MainActivity1.this.w();
                    }
                } else {
                    Toast.makeText(MainActivity1.this, "Required wifi network", Toast.LENGTH_SHORT).show();
                    try {
                        WifiManager wifiManager = (WifiManager) MainActivity1.this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                        if (Build.VERSION.SDK_INT < 29) {
                            wifiManager.setWifiEnabled(true);
                        } else {
                            MainActivity1.this.startActivityForResult(new Intent("android.settings.panel.action.WIFI"), 1);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        this.screenCastingStop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (MainActivity1.c(MainActivity1.this).booleanValue()) {
                    int i = MainActivity1.this.B + 1;
                    MainActivity1.this.B = i;
                    MainActivity1.a(MainActivity1.this, Integer.valueOf(i));
                    if (MainActivity1.this.getSharedPreferences("SHARED_DATABASE_NAME", 0).getInt("count_how2Use", 0) > 0) {
                        MainActivity1.this.w();
                    } else if (MainActivity1.this.getSharedPreferences("SHARED_DATABASE_NAME", 0).getBoolean("isChecked_how2Use", false)) {
                        MainActivity1.this.w();
                    }
                } else {
                    Toast.makeText(MainActivity1.this, "Required wifi network", Toast.LENGTH_SHORT).show();
                    try {
                        WifiManager wifiManager = (WifiManager) MainActivity1.this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                        if (Build.VERSION.SDK_INT < 29) {
                            wifiManager.setWifiEnabled(true);
                        } else {
                            MainActivity1.this.startActivityForResult(new Intent("android.settings.panel.action.WIFI"), 1);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    public static boolean isStoragePermissionGranted(Context context, int i) {
        if (Build.VERSION.SDK_INT < 23 || context.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED || context.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        ActivityCompat.requestPermissions((Activity) context, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"}, i);
        return false;
    }

    public void x() {
        try {
            MediaRouter mediaRouter = (MediaRouter) getApplicationContext().getSystemService(Context.MEDIA_ROUTER_SERVICE);
            mediaRouter.selectRoute(2, mediaRouter.getDefaultRoute());
        } catch (Exception e) {
            Toast.makeText(this, "" + e, Toast.LENGTH_LONG).show();
        }
    }

    public static Boolean c(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        Objects.requireNonNull(connectivityManager);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return Boolean.valueOf(activeNetworkInfo != null && activeNetworkInfo.isConnected());
    }

    public static void a(Context context, Integer num) {
        context.getSharedPreferences("SHARED_DATABASE_NAME", 0).edit().putInt("count_how2Use", num.intValue()).apply();
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (iArr.length > 0 && iArr[0] == 0 && i == 100) {
            startActivity(new Intent(this, AllMedia.class));
        } else {
            Toast.makeText(this, "Allow storage permissions", Toast.LENGTH_SHORT).show();
        }
    }

    public static StringBuilder s(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        return sb;
    }

    public static String o(Context context, int i) {
        try {
            return context.getResources().getString(i);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public void w() {
        try {
            if (Integer.valueOf(getSharedPreferences("SHARED_DATABASE_NAME", 0).getInt("count_how2Use", 0)).intValue() > 0) {
                this.B = 0;
                a(this, 0);
            }
            startActivity(new Intent("android.settings.CAST_SETTINGS"));
        } catch (ActivityNotFoundException unused) {
            StringBuilder s = s("");
            s.append(o(this, R.string.deviceNotSupported));
            Toast.makeText(this, s.toString(), Toast.LENGTH_LONG).show();
        }
    }

    public void onBackPressed() {
        MainActivity1.this.finish();
    }
}
