package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
//import com.two.dgbmapp.hdvideoprojector.Ads_class.Common;
//import com.two.dgbmapp.hdvideoprojector.Basic.More_Activity;
//import com.two.dgbmapp.hdvideoprojector.Basic.Start_Activity;
//import com.two.dgbmapp.hdvideoprojector.part2.ALL_FOLDER_FRAGMENT;
//import com.two.dgbmapp.hdvideoprojector.part3.Activity.RemoteMainActivity;
//import com.two.dgbmapp.hdvideoprojector.statussaver.StatusHD_Video_Status_Activity;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.AdInterGD;
//import com.two.dgbmapp.hdvideoprojector.statussaver.statushd_video_adss.newnativeads.NativeHelper;
//import com.two.dgbmapp.hdvideoprojector.wastatus.activity.MainActivity;

public class ScreenMirroringActivity extends AppCompatActivity {
    ImageView back;
    DrawerLayout drawer_layout;
    NavigationView nav_view;
    ImageView sm_1;
    ImageView sm_2;
    ImageView sm_3;
    ImageView sm_4;
    ImageView sm_5;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_screen_mirroring);
        getWindow().setFlags(1024, 1024);
        adsandnavigation();
        findview();
        clickdata();
        ((ImageView) findViewById(R.id.back)).setOnClickListener(new ScreenMirroringActivity$$ExternalSyntheticLambda0(this));
        check();
    }

    public /* synthetic */ void m28lambda$onCreate$0$comtwodgbmapphdvideoprojectorScreenMirroringActivity(View view) {
        onBackPressed();
    }

    public void check() {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            requestStoragePermission();
        }
    }

    private void requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE")) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 0);
            Toast.makeText(this, "Permission needed to save status images and videos", Toast.LENGTH_SHORT).show();
            return;
        }
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 0);
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 0) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        } else if (iArr.length == 1 && iArr[0] == 0) {
            Toast.makeText(this, "Storage Permission Granted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Storage permission required\nto save status images & videos", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void clickdata() {
        this.sm_1.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScreenMirroringActivity.this.lambda$clickdata$0$ScreenMirroringActivity(view);
            }
        });
        this.sm_2.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScreenMirroringActivity.this.lambda$clickdata$1$ScreenMirroringActivity(view);
            }
        });
        this.sm_3.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScreenMirroringActivity.this.lambda$clickdata$2$ScreenMirroringActivity(view);
            }
        });
        this.sm_4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ScreenMirroringActivity.this.startActivity(new Intent(ScreenMirroringActivity.this, StatusHD_Video_Status_Activity.class));

            }
        });
        this.sm_5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ScreenMirroringActivity.this.startActivity(new Intent(ScreenMirroringActivity.this, MainActivity.class));

            }
        });
    }

    public void lambda$clickdata$0$ScreenMirroringActivity(View view) {
        ScreenMirroringActivity.this.startActivity(new Intent(ScreenMirroringActivity.this, ScreenMirroringOptionActivity.class));

    }

    public void lambda$clickdata$1$ScreenMirroringActivity(View view) {
        ScreenMirroringActivity.this.startActivity(new Intent(ScreenMirroringActivity.this, RemoteMainActivity.class));

    }

    public void lambda$clickdata$2$ScreenMirroringActivity(View view) {
        ScreenMirroringActivity.this.startActivity(new Intent(ScreenMirroringActivity.this, ALL_FOLDER_FRAGMENT.class));

    }

    private void findview() {
        this.sm_1 = (ImageView) findViewById(R.id.sm_1);
        this.sm_2 = (ImageView) findViewById(R.id.sm_2);
        this.sm_3 = (ImageView) findViewById(R.id.sm_3);
        this.sm_4 = (ImageView) findViewById(R.id.sm_4);
        this.sm_5 = (ImageView) findViewById(R.id.sm_5);
    }

    private void adsandnavigation() {
        findViewById(R.id.tx_nm).setSelected(true);
        if (getIntent().hasExtra("my_boolean_key")) {
            getIntent().getBooleanExtra("my_boolean_key", false);
        }
        this.drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        this.nav_view = (NavigationView) findViewById(R.id.nav_view);
        ImageView imageView = (ImageView) findViewById(R.id.drawer);
        this.nav_view.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                int itemId = menuItem.getItemId();
                if (itemId == R.id.home) {
                    ScreenMirroringActivity.this.drawer_layout.closeDrawer((int) GravityCompat.START);
                    Intent intent = new Intent(ScreenMirroringActivity.this.getApplicationContext(), Start_Activity.class);
                    intent.putExtra("my_boolean_key", true);
                    ScreenMirroringActivity.this.startActivity(intent);
                    ScreenMirroringActivity.this.finish();
                } else if (itemId == R.id.rate) {
                    Common.rateUs(ScreenMirroringActivity.this);
                } else if (itemId == R.id.share) {
                    Common.ShareApp(ScreenMirroringActivity.this);
                } else if (itemId == R.id.privacy) {
                    Common.privacypolicy(ScreenMirroringActivity.this);
                } else if (itemId == R.id.more) {
                    ScreenMirroringActivity.this.startActivity(new Intent(ScreenMirroringActivity.this, More_Activity.class));
                }
                ScreenMirroringActivity.this.drawer_layout.closeDrawer((int) GravityCompat.START);
                return true;
            }
        });
    }

    public void onBackPressed() {
        ScreenMirroringActivity.this.finish();

    }
}
