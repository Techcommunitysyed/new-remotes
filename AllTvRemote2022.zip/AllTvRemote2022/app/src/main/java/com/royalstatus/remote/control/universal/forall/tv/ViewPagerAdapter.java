package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.viewpager.widget.PagerAdapter;
import java.util.Objects;

class ViewPagerAdapter extends PagerAdapter {
    Context context;
    int[] images;
    LayoutInflater mLayoutInflater;
    String[] subtitle;

    public ViewPagerAdapter(Context context2, int[] iArr, String[] strArr) {
        this.context = context2;
        this.images = iArr;
        this.subtitle = strArr;
        this.mLayoutInflater = (LayoutInflater) context2.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return this.images.length;
    }

    public boolean isViewFromObject(View view, Object obj) {
        return view == ((RelativeLayout) obj);
    }

    public Object instantiateItem(ViewGroup viewGroup, int i) {
        View inflate = this.mLayoutInflater.inflate(R.layout.help_pager, viewGroup, false);
        ((ImageView) inflate.findViewById(R.id.imageViewMain)).setImageResource(this.images[i]);
        ((TextView) inflate.findViewById(R.id.subtitlexml)).setText(this.subtitle[i]);
        Objects.requireNonNull(viewGroup);
        ViewGroup viewGroup2 = viewGroup;
        viewGroup.addView(inflate);
        return inflate;
    }

    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((RelativeLayout) obj);
    }
}
