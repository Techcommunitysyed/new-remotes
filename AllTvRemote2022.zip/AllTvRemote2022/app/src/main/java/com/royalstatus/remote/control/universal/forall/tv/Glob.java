package com.royalstatus.remote.control.universal.forall.tv;

import java.util.ArrayList;

public class Glob {
    public static ArrayList<String> remotelist = new ArrayList<>();
    public static String str;
}
