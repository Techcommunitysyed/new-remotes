package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;


public class SelectTvModelActivity extends AppCompatActivity {
    Button model_lg;
    Button model_mi;
    Button model_oneplustcl;
    Button model_other;
    Button model_panasonic;
    Button model_samsung;
    Button model_sony;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_select_tv_model);
        findview();
        clickdata();

        ((ImageView) findViewById(R.id.imgBack)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SelectTvModelActivity.this.onBackPressed();
            }
        });
    }

    private void clickdata() {
        this.model_sony.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectTvModelActivity.this.lambda$clickdata$0$SelectTvModelActivity(view);
            }
        });
        this.model_samsung.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectTvModelActivity.this.lambda$clickdata$1$SelectTvModelActivity(view);
            }
        });
        this.model_lg.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectTvModelActivity.this.lambda$clickdata$2$SelectTvModelActivity(view);
            }
        });
        this.model_panasonic.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectTvModelActivity.this.lambda$clickdata$3$SelectTvModelActivity(view);
            }
        });
        this.model_mi.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectTvModelActivity.this.lambda$clickdata$4$SelectTvModelActivity(view);
            }
        });
        this.model_oneplustcl.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectTvModelActivity.this.lambda$clickdata$5$SelectTvModelActivity(view);
            }
        });
        this.model_other.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectTvModelActivity.this.lambda$clickdata$6$SelectTvModelActivity(view);
            }
        });
    }

    public void lambda$clickdata$0$SelectTvModelActivity(View view) {
        SelectTvModelActivity.this.startActivity(new Intent(SelectTvModelActivity.this, SelectYearActivity.class));

    }

    public void lambda$clickdata$1$SelectTvModelActivity(View view) {
        SelectTvModelActivity.this.startActivity(new Intent(SelectTvModelActivity.this, SelectYearActivity.class));

    }

    public void lambda$clickdata$2$SelectTvModelActivity(View view) {
        SelectTvModelActivity.this.startActivity(new Intent(SelectTvModelActivity.this, SelectYearActivity.class));

    }

    public void lambda$clickdata$3$SelectTvModelActivity(View view) {
        SelectTvModelActivity.this.startActivity(new Intent(SelectTvModelActivity.this, SelectYearActivity.class));

    }

    public void lambda$clickdata$4$SelectTvModelActivity(View view) {
        SelectTvModelActivity.this.startActivity(new Intent(SelectTvModelActivity.this, SelectYearActivity.class));

    }

    public void lambda$clickdata$5$SelectTvModelActivity(View view) {
        SelectTvModelActivity.this.startActivity(new Intent(SelectTvModelActivity.this, SelectYearActivity.class));

    }

    public void lambda$clickdata$6$SelectTvModelActivity(View view) {
        SelectTvModelActivity.this.startActivity(new Intent(SelectTvModelActivity.this, SelectYearActivity.class));

    }

    private void findview() {
        this.model_sony = (Button) findViewById(R.id.model_sony);
        this.model_samsung = (Button) findViewById(R.id.model_samsung);
        this.model_lg = (Button) findViewById(R.id.model_lg);
        this.model_panasonic = (Button) findViewById(R.id.model_panasonic);
        this.model_mi = (Button) findViewById(R.id.model_mi);
        this.model_oneplustcl = (Button) findViewById(R.id.model_oneplustcl);
        this.model_other = (Button) findViewById(R.id.model_other);
    }

    public void onBackPressed() {
       finish();
    }
}
