package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.net.ConnectivityManager;

public class NetworkState {
    public static boolean connectionAvailable(Context context) {
        return ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo() != null;
    }
}
