package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class VIDEO_LIST_ACTIVITY$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ VIDEO_LIST_ACTIVITY f$0;

    public /* synthetic */ VIDEO_LIST_ACTIVITY$$ExternalSyntheticLambda0(VIDEO_LIST_ACTIVITY video_list_activity) {
        this.f$0 = video_list_activity;
    }

    public final void onClick(View view) {
        this.f$0.m32lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart2ActivityVIDEO_LIST_ACTIVITY(view);
    }
}
