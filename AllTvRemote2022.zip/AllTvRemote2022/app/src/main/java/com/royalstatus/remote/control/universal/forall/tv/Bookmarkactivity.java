package com.royalstatus.remote.control.universal.forall.tv;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.Adapter.CustomListAdapterDeleteRows;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.Model.UserModel;
import java.util.ArrayList;
import org.json.JSONException;

public class Bookmarkactivity extends AppCompatActivity {
    static CustomListAdapterDeleteRows deleteAdapter;
    LinearLayout datahis;
    ListView listView;
    ImageView sss;
    ArrayList<UserModel> users = new ArrayList<>();
    LinearLayout xtxt;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_bookmarkactivity);
        ((ImageView) findViewById(R.id.clocc)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Bookmarkactivity.this.finish();
            }
        });
        this.listView = (ListView) findViewById(R.id.listviewdeleteID);
        this.xtxt = (LinearLayout) findViewById(R.id.xtxt);
        this.datahis = (LinearLayout) findViewById(R.id.datahis);
        this.sss = (ImageView) findViewById(R.id.sss);
        ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.setDisplayHomeAsUpEnabled(true);
            supportActionBar.setTitle((CharSequence) "Bookmarks");
        }
        datafatch();
        this.sss.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                UsersDatabaseAdapter.truncatehisTable();
                Bookmarkactivity.this.datafatch();
            }
        });
    }

    /* access modifiers changed from: private */
    public void datafatch() {
        try {
            new UsersDatabaseAdapter(this);
            this.users = UsersDatabaseAdapter.getRows();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (this.users.isEmpty()) {
            this.xtxt.setVisibility(View.VISIBLE);
            this.datahis.setVisibility(View.GONE);
            return;
        }
        this.xtxt.setVisibility(View.GONE);
        this.datahis.setVisibility(View.VISIBLE);
        CustomListAdapterDeleteRows customListAdapterDeleteRows = new CustomListAdapterDeleteRows(this, this.users);
        deleteAdapter = customListAdapterDeleteRows;
        this.listView.setAdapter(customListAdapterDeleteRows);
    }

    public void onResume() {
        try {
            this.users = UsersDatabaseAdapter.getRows();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        deleteAdapter = new CustomListAdapterDeleteRows(this, this.users);
        ListView listView2 = (ListView) findViewById(R.id.listviewdeleteID);
        this.listView = listView2;
        listView2.setAdapter(deleteAdapter);
        super.onResume();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        finish();
        return true;
    }
}
