package com.royalstatus.remote.control.universal.forall.tv;

import java.io.Serializable;

public class AUDIO_MODEL implements Serializable {
    String aAlbum;
    String aArtist;
    String aName;
    String aPath;

    public String getaPath() {
        return this.aPath;
    }

    public void setaPath(String str) {
        this.aPath = str;
    }

    public String getaName() {
        return this.aName;
    }

    public void setaName(String str) {
        this.aName = str;
    }

    public String getaAlbum() {
        return this.aAlbum;
    }

    public void setaAlbum(String str) {
        this.aAlbum = str;
    }

    public String getaArtist() {
        return this.aArtist;
    }

    public void setaArtist(String str) {
        this.aArtist = str;
    }
}
