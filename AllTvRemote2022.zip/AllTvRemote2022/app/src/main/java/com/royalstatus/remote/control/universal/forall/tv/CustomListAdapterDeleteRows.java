package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.Model.UserModel;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.UsersDatabaseAdapter;
//import com.two.dgbmapp.hdvideoprojector.part2.Web.bookwebbrowserfrag;
import java.util.ArrayList;

public class CustomListAdapterDeleteRows extends BaseAdapter {
    Context co;
    UserModel user;
    ArrayList<UserModel> users;

    public long getItemId(int i) {
        return (long) i;
    }

    public CustomListAdapterDeleteRows(Context context, ArrayList<UserModel> arrayList) {
        this.co = context;
        this.users = arrayList;
    }

    public int getCount() {
        return this.users.size();
    }

    public Object getItem(int i) {
        return this.users.get(i);
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(this.co).inflate(R.layout.listviewdelete_row, viewGroup, false);
        }
        UserModel userModel = (UserModel) getItem(i);
        this.user = userModel;
        ((TextView) view.findViewById(R.id.textView1)).setText(userModel.getUsername());
        ((ImageView) view.findViewById(R.id.button1)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                UsersDatabaseAdapter.deleteEntry(CustomListAdapterDeleteRows.this.user.getID());
                CustomListAdapterDeleteRows.this.users.remove(i);
                CustomListAdapterDeleteRows.this.notifyDataSetChanged();
            }
        });
        ((RelativeLayout) view.findViewById(R.id.rel)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                CustomListAdapterDeleteRows.this.next();
            }
        });
        return view;
    }

    /* access modifiers changed from: private */
    public void next() {
        Intent intent = new Intent(this.co, bookwebbrowserfrag.class);
        intent.putExtra("linkk", this.user.getUsername());
        intent.putExtra("nn", "val");
        this.co.startActivity(intent);
    }
}
