package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class MyRemoteSaveActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ MyRemoteSaveActivity f$0;

    public /* synthetic */ MyRemoteSaveActivity$$ExternalSyntheticLambda0(MyRemoteSaveActivity myRemoteSaveActivity) {
        this.f$0 = myRemoteSaveActivity;
    }

    public final void onClick(View view) {
        this.f$0.m36lambda$adsandnavigation$0$comtwodgbmapphdvideoprojectorpart3ActivityMyRemoteSaveActivity(view);
    }
}
