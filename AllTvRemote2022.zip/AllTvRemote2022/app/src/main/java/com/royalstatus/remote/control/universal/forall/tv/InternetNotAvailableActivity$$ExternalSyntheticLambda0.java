package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class InternetNotAvailableActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ InternetNotAvailableActivity f$0;

    public /* synthetic */ InternetNotAvailableActivity$$ExternalSyntheticLambda0(InternetNotAvailableActivity internetNotAvailableActivity) {
        this.f$0 = internetNotAvailableActivity;
    }

    public final void onClick(View view) {
        this.f$0.m1551lambda$onCreate$0$vocsygoogleadsInternetNotAvailableActivity(view);
    }
}
