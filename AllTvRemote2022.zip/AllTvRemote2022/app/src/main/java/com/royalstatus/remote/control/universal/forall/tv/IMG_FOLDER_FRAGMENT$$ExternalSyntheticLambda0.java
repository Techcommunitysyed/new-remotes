package com.royalstatus.remote.control.universal.forall.tv;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class IMG_FOLDER_FRAGMENT$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ IMG_FOLDER_FRAGMENT f$0;

    public /* synthetic */ IMG_FOLDER_FRAGMENT$$ExternalSyntheticLambda0(IMG_FOLDER_FRAGMENT img_folder_fragment) {
        this.f$0 = img_folder_fragment;
    }

    public final void onClick(View view) {
        this.f$0.m33lambda$onCreate$0$comtwodgbmapphdvideoprojectorpart2IMG_FOLDER_FRAGMENT(view);
    }
}
