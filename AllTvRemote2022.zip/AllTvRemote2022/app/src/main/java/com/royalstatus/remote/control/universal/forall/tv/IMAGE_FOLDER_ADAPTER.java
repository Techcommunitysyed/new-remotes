package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
//import com.two.dgbmapp.hdvideoprojector.R;
//import com.two.dgbmapp.hdvideoprojector.part2.Activity.IMAGE_LIST_ACTIVITY;
//import com.two.dgbmapp.hdvideoprojector.part2.Model.MODEL_GALLERY_ALBUM_MODEL;
import java.util.List;

public class IMAGE_FOLDER_ADAPTER extends RecyclerView.Adapter<IMAGE_FOLDER_ADAPTER.MyImage> {
    Context context;
    List<MODEL_GALLERY_ALBUM_MODEL> listGalleryAlbums;

    public IMAGE_FOLDER_ADAPTER(Context context2, List<MODEL_GALLERY_ALBUM_MODEL> list) {
        this.context = context2;
        this.listGalleryAlbums = list;
    }

    public MyImage onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyImage(LayoutInflater.from(this.context).inflate(R.layout.item_folder_list, viewGroup, false));
    }

    public void onBindViewHolder(MyImage myImage, final int i) {
        final MODEL_GALLERY_ALBUM_MODEL model_gallery_album_model = this.listGalleryAlbums.get(i);
        myImage.folder.setImageResource(R.drawable.ic_folder);
        TextView textView = myImage.tvCount;
        textView.setText(model_gallery_album_model.getAlbumPhotos().size() + " Media");
        myImage.tvTitle.setText(model_gallery_album_model.getName());
        myImage.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
//                IMAGE_FOLDER_ADAPTER.this.context.startActivity(new Intent(IMAGE_FOLDER_ADAPTER.this.context, IMAGE_LIST_ACTIVITY.class).setFlags(67108864).putExtra("pos", i).putExtra("name", model_gallery_album_model.getName()));
            }
        });
    }

    public int getItemCount() {
        return this.listGalleryAlbums.size();
    }

    public class MyImage extends RecyclerView.ViewHolder {
        ImageView folder;
        TextView tvCount;
        TextView tvTitle;

        public MyImage(View view) {
            super(view);
            this.tvCount = (TextView) view.findViewById(R.id.tvCount);
            this.tvTitle = (TextView) view.findViewById(R.id.tvName);
            this.folder = (ImageView) view.findViewById(R.id.folder);
        }
    }
}
