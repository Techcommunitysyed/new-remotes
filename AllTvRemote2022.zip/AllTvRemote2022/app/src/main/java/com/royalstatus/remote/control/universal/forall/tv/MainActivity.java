package com.royalstatus.remote.control.universal.forall.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private LinearLayout btnChromeCast;
    private LinearLayout btnIRRemotes;
    private LinearLayout btnScreenMirroring;
    private LinearLayout btnSmartRemote;
    private LinearLayout btn_help;
    String url1 = "https://play-lh.googleusercontent.com/PeZdz7URpPdHc6B852wzOQGyfBsl9T-cHlVmXE5htXsA9W4-Qz_rUdTHtDU6PAN7ug=w526-h296-rw";
    String url2 = "https://play-lh.googleusercontent.com/qp7saLFiFbxzcEe5T-cFv9Rr-ACCA5dUIMrK6aFOh5NTjHfPbxMIVF2PlMIt7x_T0Q=h310";
    String url3 = "https://www.istreamer.com/wp-content/uploads/2020/02/mirorchrome.jpg";

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_main);
        initViews();
        ArrayList arrayList = new ArrayList();
        SliderView sliderView = (SliderView) findViewById(R.id.slider);
        arrayList.add(new SliderData(this.url1));
        arrayList.add(new SliderData(this.url2));
        arrayList.add(new SliderData(this.url3));
        SliderAdapter sliderAdapter = new SliderAdapter(this, arrayList);
        sliderView.setAutoCycleDirection(0);
        sliderView.setSliderAdapter(sliderAdapter);
        sliderView.setScrollTimeInSec(3);
        sliderView.setAutoCycle(true);
        sliderView.startAutoCycle();
    }

    private void initViews() {
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.btnSmartRemote);
        this.btnSmartRemote = linearLayout;
        linearLayout.setOnClickListener(this);
        LinearLayout linearLayout2 = (LinearLayout) findViewById(R.id.btnIRRemotes);
        this.btnIRRemotes = linearLayout2;
        linearLayout2.setOnClickListener(this);
        LinearLayout linearLayout3 = (LinearLayout) findViewById(R.id.btnChromeCast);
        this.btnChromeCast = linearLayout3;
        linearLayout3.setOnClickListener(this);
        LinearLayout linearLayout4 = (LinearLayout) findViewById(R.id.btn_help);
        this.btn_help = linearLayout4;
        linearLayout4.setOnClickListener(this);
        LinearLayout linearLayout5 = (LinearLayout) findViewById(R.id.btnScreenMirroring);
        this.btnScreenMirroring = linearLayout5;
        linearLayout5.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnChromeCast :
                MainActivity.this.startActivity(new Intent(MainActivity.this, ChromeCastActivity.class));

                return;
            case R.id.btnIRRemotes :
                MainActivity.this.startActivity(new Intent(MainActivity.this, IRRemotesActivity.class));

                return;
            case R.id.btnScreenMirroring :
                MainActivity.this.startActivity(new Intent(MainActivity.this, SelectTvModelActivity.class));

                return;
            case R.id.btnSmartRemote :
                MainActivity.this.startActivity(new Intent(MainActivity.this, DevicesActivity.class));

                return;
            case R.id.btn_help :
                MainActivity.this.startActivity(new Intent(MainActivity.this, Help_Activity.class));

                return;
            default:
                return;
        }
    }

    public void onBackPressed() {
        MainActivity.this.startActivity(new Intent(MainActivity.this, GetStart2.class));

    }
}
